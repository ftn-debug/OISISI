package studentska.sluzba.controller;

import studentska.sluzba.gui.MainFrame;
import studentska.sluzba.model.BazaStudenata;
import studentska.sluzba.model.Ocena;
import studentska.sluzba.model.Predmet;
import studentska.sluzba.model.Student;
import studentska.sluzba.pop.dialogs.EditStudentDialog;
/**
 * Klasa koja poziva na promjene u Bazi Studeta.Ona sluzi kao posrednik izmedju Baze i Main Frame-a.
 * @author Maja Blagic
 *
 */
public class StudentiController {

	
private static StudentiController instance=null;
	/**
	 * Klasa je Singleton 
	 * @return - vraca instancu Kontrolera Studenata
	 */
	public static StudentiController getInstance() {
		
		if(instance == null ) {
			instance= new StudentiController();
		}
		return instance;
		
	}
	private StudentiController() {}
	/**
	 * Metoda kontrolera dalje prosljedjuje entitet studenta koji treba biti dodat u Bazi Studenta.
	 * Nakon izmjene u bazi potrebno iz izmijeniti i view u Main Frame-u.
	 * @param entity - Student koji se dodaje
	 */
	public void dodajStudenta(Student entity) {
		BazaStudenata.getInstance().dodajStudenta(entity);
		MainFrame.getInstance().azurirajPrikazStudenta("DODAT", -1);
	}
	/**
	 * Metoda kontolera koja poziva metodu za provjeravanje jedinstvenosti kljuca entiteta u BaziStudenta.
	 * 
	 * @param student - selektovani student za koga se vrsi provjera jedinstvenosti kljuca
	 * @return - vraca true ako je kljuc jedinstven , false ako nije 
	 */
	public Boolean uniqueBrIndex(Student student) {
		return BazaStudenata.getInstance().uniqueBrIndexa(student.getBrIndeksa());
		
	}
	/**
	 * Metoda kontrolera poziva metodu za izmjenu entiteta u Bazi Studenata.
	 * Nakon izmjene u Bazi potrebno je apdejtovati izgled MainFrame-a
	 * @param index - indeks/kljuc studenta nad kojim se vrsi izmjena
	 * @param s - izmjenjene informacije o tom studentu 
	 */
	public void updateStudenta(String index, Student s) {

		BazaStudenata.getInstance().izmeniStudenta(index,s.getPrezime(),s.getIme(),s.getDatumRodjenja(),s.getAdresa(),s.getKontaktTelefon(),s.geteMail(),s.getBrIndeksa(),s.getGodinaUpisa(),s.getTrenutnaGodinaStudija(),s.getStatus(),s.getProsecnaOcenaO());
		MainFrame.getInstance().azurirajPrikazStudenta(null,-1);
	}
	/**
	 * Metoda za ponistavanje ocjene. Uzimajuci u obzir referencijalnu zavisnost ovog entiteta moramo azurirati vise prikaza tabela.
	 * @param s - student kome brisemo ocjenu
	 * @param selectedRow - izabrani red predstavlja ocjenu koju zelimo da ibrisemo iz liste .
	 * @param eds - referenca na dijalog u kome se nalaze tabele koje cemo azurirati nakon izmjene Baze.
	 */
	public void ponistiOcenu(Student s, int selectedRow, EditStudentDialog eds) {

				//moram pozvati bazu
				BazaStudenata.getInstance().ponistiOcenu(s,selectedRow);
				//azuriram prikaz,prosljedjujem eds jer nije singleton
				eds.azurirajPrikazPolozeni("PONISTENA OCJENA", -1);
				//tre ba da azuriram i prikaze nepolozenih
				eds.azurirajPrikazNepolozenih("PONISTENA OCJENA", -1);
	}		
	/**
	 * Metoda poziva brisanje predmeta i azuriranje prikaza listi koje ga sadrze
	 * @param p - predmet koji je potrebno izbrisati
	 */
	public void izbristiPredmet(Predmet p) {

		BazaStudenata.getInstance().izbrisiPredmet(p);
		MainFrame.getInstance().azurirajPrikazStudenta(null, 0);
	}
	/**
	 * Metoda poziva dodavanje ocjene nekome studentu i azuriranje tabela vezanih za ocjene tog studenta.
	 * @param s - student kome se dodaje ocjena
	 * @param o - ocjena koja se dodaje
	 * @param p - predmet na kome je ta cojena
	 * @param eds - referenca na dijalog iz koga je metoda pozvana da bismo mogli azurirati tabele na koje utice izmjena.
	 */
	public void dodajOcenuStudentu(Student s,Ocena o,Predmet p,EditStudentDialog eds) {
		//ovo mora u bazi 
		BazaStudenata.getInstance().dodajOcenu(s,o,p);
		
		
		eds.azurirajPrikazNepolozenih("UKLONJEN PREDMET", -1);
		eds.azurirajPrikazPolozeni("DODATA OCENA", -1);
		
	}
	/**
	 * Metoda koja brise studenta , obraca paznju na referencijalnu zavisnost tog studenta, i azurira prikaz tabela saglasno sa tim.
	 * @param s - student koji se brise
	 */
	public void obrisiStudenta(Student s) {
		
		BazaStudenata.getInstance().izbrisiStudenta(s.getBrIndeksa());
		MainFrame.getInstance().azurirajPrikazStudenta("OBRISAN STUDENT", -1);
	}
	/**
	 * Metoda koja azurira listu Nepolzenih predmeta
	 * @param s - 
	 * @param selectedRow - 
	 * @param eds - 
	 */
	public void azurirajListuNepolozenihPredmeta(Student s, int selectedRow, EditStudentDialog eds) {
		//u bazi napravim metodu koja stavlja ovaj predmet u listu predmeta da polozi
				BazaStudenata.getInstance().azurirajListuNepolozenihPredmeta(s,selectedRow);
				//onda azuriram par stvari
				eds.azurirajPrikazNepolozenih(null, 0);
				eds.azurirajPrikazPredmetaDaPolozi(null, 0);
			}
	/**
	 * Metoda koja azurira listu predmeta za studente kada se doda novi predmet.
	 * Na kraju treba azurirati Studente zbog izmjene u Bazi.
	 * @param predmet - novi predmet koji je potrebno dodati.
	 * 
	 */
	public void azurirajListuPredmeta(Predmet predmet) {
		BazaStudenata.getInstance().azurirajListuPredmeta(predmet);
		MainFrame.getInstance().azurirajPrikazStudenta(null, -1);
	}
	/**
	 * Metoda koja prosljedjuje predmet za dodavanje na listu predmeta u Bazi.
	 * @param p predmet
	 */
	public void updatePredmete(Predmet p) {
		BazaStudenata.getInstance().azurirajListuPredmeta(p);
		
	}
	/**
	 * Metoda koja poziva uklanjanje predmeta sa studenta u Bazi Studenta a zatim azurira prikaz tabela na koje je uticala promjena stanja Baze Studenata.
	 * @param s - student kome se uklanja predmet
	 * @param selectedRow - izabrani predmet
	 * @param eds - referenca na dijalog iz koga je pozvana metoda kontrolera radi azuriranje njegovog prikaza.
	 */
	public void uklanjanjePredmetaSaStudenta(Student s, int selectedRow, EditStudentDialog eds) {
		//vrati na listu predmeta da polaze
				BazaStudenata.getInstance().uklanjanjePredmetaSaStudenta( s, selectedRow);
				//updatuje obe tabele
				eds.azurirajPrikazNepolozenih(null, 0);
				eds.azurirajPrikazPredmetaDaPolozi(null, 0);
		
	}
}
