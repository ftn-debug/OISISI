package gui;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

import model.BazaStudenata;
import model.Ocena;
import model.Predmet;

public class AbstractTableModelPolozeniPredmet extends AbstractTableModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<Ocena> ocenaList;
	private String[] columns;
	
	public AbstractTableModelPolozeniPredmet(ArrayList<Ocena> arrayList) {
		 super();
		 this.ocenaList=arrayList;
		columns = new String[]{"SIFRA PREDMETA","NAZIV PREDMETA", "BROJ ESP BODOVA",
		"GODINA NA KOJOJ SE PREDMET IZVODI","SEMESTAR"};
	  }
	public String getColumnName(int column) {
		return columns[column];
	}
	

	@Override
	public int getColumnCount() {
		return columns.length;
		
	}

	@Override
	public int getRowCount() {
		return ocenaList.size();
	}

	@Override
	public Object getValueAt(int row, int col) {
		//return BazaPredmeta.getInstance().getValueAt(rowIndex, columnIndex);
	
			Ocena ocena=ocenaList.get(row);
			Predmet predmet = ocena.getPredmet();
			/*String sifraPredmeta = ocena.getPredmet().getSifraPredmeta();
			List<Predmet> sviPredmeti= BazaPredmeta.getInstance().getPredmeti();
			Predmet predmet =new Predmet();
			
			
			for(Predmet p: sviPredmeti) {
				if(p.getSifraPredmeta().equals(sifraPredmeta))
				{
					predmet =p;
					break;
				}
				predmet=null;
				System.out.println("Nema tog predmeta u bazi predmeta");
			}
			*/
		switch(col) {
		case 0: 
			return predmet.getSifraPredmeta();
		case 1:
			return predmet.getNazivPredmeta();
		case 2:
			return Integer.toString(predmet.getBrESPBbodova());
		case 3:
			return ocena.getVijrednostOcene()+ "";
			
		case 4:
			return Integer.toString(predmet.getGodinaStudija());
		default:
				return null;	
		
	
		}
		//TableModel model = new FootballClubTableModel(clubs);
	}

	

}
