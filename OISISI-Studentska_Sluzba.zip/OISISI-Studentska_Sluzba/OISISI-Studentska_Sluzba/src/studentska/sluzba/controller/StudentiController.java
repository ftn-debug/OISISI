package studentska.sluzba.controller;

import studentska.sluzba.gui.MainFrame;
import studentska.sluzba.model.BazaStudenata;
import studentska.sluzba.model.Ocena;
import studentska.sluzba.model.Predmet;
import studentska.sluzba.model.Student;
import studentska.sluzba.pop.dialogs.EditStudentDialog;

public class StudentiController {

	
private static StudentiController instance=null;
	
	public static StudentiController getInstance() {
		
		if(instance == null ) {
			instance= new StudentiController();
		}
		return instance;
		
	}
	private StudentiController() {}
	public void dodajStudenta(Student entity) {
		BazaStudenata.getInstance().dodajStudenta(entity);
		MainFrame.getInstance().azurirajPrikazStudenta("DODAT", -1);
	}
	public Boolean uniqueBrIndex(Student student) {
		return BazaStudenata.getInstance().uniqueBrIndexa(student.getBrIndeksa());
		
	}
	public void updateStudenta(String index, Student s) {

		BazaStudenata.getInstance().izmeniStudenta(index,s.getPrezime(),s.getIme(),s.getDatumRodjenja(),s.getAdresa(),s.getKontaktTelefon(),s.geteMail(),s.getBrIndeksa(),s.getGodinaUpisa(),s.getTrenutnaGodinaStudija(),s.getStatus(),s.getProsecnaOcenaO());
		MainFrame.getInstance().azurirajPrikazStudenta(null,-1);
	}
	public void ponistiOcenu(Student s, int selectedRow, EditStudentDialog eds) {

				//moram pozvati bazu
				BazaStudenata.getInstance().ponistiOcenu(s,selectedRow);
				//azuriram prikaz,prosljedjujem eds jer nije singleton
				eds.azurirajPrikazPolozeni("PONISTENA OCJENA", -1);
				//tre ba da azuriram i prikaze nepolozenih
				eds.azurirajPrikazNepolozenih("PONISTENA OCJENA", -1);
	}		
	
	public void izbristiPredmet(Predmet p) {

		BazaStudenata.getInstance().izbrisiPredmet(p);
		MainFrame.getInstance().azurirajPrikazStudenta(null, 0);
	}
	
	public void dodajOcenuStudentu(Student s,Ocena o,Predmet p,EditStudentDialog eds) {
		//ovo mora u bazi 
		BazaStudenata.getInstance().dodajOcenu(s,o,p);
		
		
		eds.azurirajPrikazNepolozenih("UKLONJEN PREDMET", -1);
		eds.azurirajPrikazPolozeni("DODATA OCENA", -1);
		
	}
	public void obrisiStudenta(Student s) {
		
		BazaStudenata.getInstance().izbrisiStudenta(s.getBrIndeksa());
		MainFrame.getInstance().azurirajPrikazStudenta("OBRISAN STUDENT", -1);
	}
	public void azurirajListuNepolozenihPredmeta(Student s, int selectedRow, EditStudentDialog eds) {
		//u bazi napravim metodu koja stavlja ovaj predmet u listu predmeta da polozi
				BazaStudenata.getInstance().azurirajListuNepolozenihPredmeta(s,selectedRow);
				//onda azuriram par stvari
				eds.azurirajPrikazNepolozenih(null, 0);
				eds.azurirajPrikazPredmetaDaPolozi(null, 0);
			}
	public void azurirajListuPredmeta(Predmet predmet) {
		BazaStudenata.getInstance().azurirajListuPredmeta(predmet);
		MainFrame.getInstance().azurirajPrikazStudenta(null, -1);
	}
	public void updatePredmete(Predmet p) {
		BazaStudenata.getInstance().azurirajListuPredmeta(p);
		
	}
	public void uklanjanjePredmetaSaStudenta(Student s, int selectedRow, EditStudentDialog eds) {
		//vrati na listu predmeta da polaze
				BazaStudenata.getInstance().uklanjanjePredmetaSaStudenta( s, selectedRow);
				//updatuje obe tabele
				eds.azurirajPrikazNepolozenih(null, 0);
				eds.azurirajPrikazPredmetaDaPolozi(null, 0);
		
	}
}
