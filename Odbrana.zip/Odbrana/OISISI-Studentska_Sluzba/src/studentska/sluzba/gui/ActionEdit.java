package studentska.sluzba.gui;


import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

import studentska.sluzba.model.Predmet;
import studentska.sluzba.model.Profesor;
import studentska.sluzba.model.Student;
import studentska.sluzba.pop.dialogs.EditProfesorDialog;
import studentska.sluzba.pop.dialogs.EditStudentDialog;
/**
 * Klasa koja poziva odgovarajuci dijalog za izmjenu Entiteta. Prosljedjuje selektovani entitet i poziva dijalog za Editovanje tog entiteta.
 *  Nasljedjuje klasu AbstractAction.
 * @author Maja Blagic 
 *
 */
public class ActionEdit extends AbstractAction {

	private static final long serialVersionUID = 1583426086994634757L;

	public ActionEdit() {
		
		putValue(MNEMONIC_KEY, KeyEvent.VK_U);
		putValue(SHORT_DESCRIPTION, "Edit");
		putValue(SMALL_ICON, new ImageIcon("Images"+ File.separator +"pencil (1).png"));
		putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_U, KeyEvent.CTRL_MASK));
	}

	@Override 
	/**
	 * Akcija se izvrsava nad entiteton koji prikazuje selektovani tab iz Main Frame-a.
	 */
	public void actionPerformed(ActionEvent arg0) {
	switch(MainFrame.getInstance().selectedTab()) {
		//ovdje se selektovan tab
		case 0:
			//selektovan student
			Student s= MainFrame.getInstance().selectedStudent();
			if(s == null) {

				JOptionPane.showMessageDialog(null, "Morate selektovati Studenta");;
			}else {
				
				@SuppressWarnings("unused")
				EditStudentDialog  dialog = new EditStudentDialog(s);
			}
		break;
		
			
		case 1:
			Profesor p = MainFrame.getInstance().selektovaniProfesor();
			if(p == null) {
				JOptionPane.showMessageDialog(null, "Morate selektovati profesora");
			}
			else {
				EditProfesorDialog  b = new EditProfesorDialog(p);
			
				//b.setVisible(true);
			}
			
			break;
		case 2:
			Predmet pr = MainFrame.getInstance().selectedPredmet();
			if(pr==null) {
				JOptionPane.showMessageDialog(null,"Morate selektovati predmet");
			}else {
				EditPredmetDialog dialog= new EditPredmetDialog(pr);
			}
			
			break;
		default:
				break;
				
		}

	}

}
