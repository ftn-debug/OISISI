package studentska.sluzba.view;



import javax.swing.table.AbstractTableModel;

import studentska.sluzba.model.BazaPredmeta;
/**
 * Metoda nasljedjuje klasu AbstractTable model i omogucava nam da napravimo izgled/model nase tabele.
 * @author majab
 *
 */

public class AbstractTableModelPredmet extends AbstractTableModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public AbstractTableModelPredmet() {
		
		
	}

	@Override
	/**
	 * @return broj redova
	 */
	public int getRowCount() {
		return BazaPredmeta.getInstance().getPredmeti().size();
				
	}

	@Override
	/**
	 *@return  broj kolona
	 */
	public int getColumnCount() {
		return BazaPredmeta.getInstance().getColumnCount();
	}

	@Override
	/**
	 *@return vrijednost celije
	 */
	public Object getValueAt(int rowIndex, int columnIndex) {
		return BazaPredmeta.getInstance().getValueAt(rowIndex, columnIndex);
	}
	@Override
	/**
	 *@return  naziv kolone 
	 */
	public String getColumnName(int index) {
		return BazaPredmeta.getInstance().getColumnName(index);
	}
	
}
