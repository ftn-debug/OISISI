package studentska.sluzba.gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTextArea;
/**
 * Prikaz verzije aplikacije,i njen opis. Nakon sledi biografija svakog autora.
 */
public class AboutDialog  extends JDialog{

	/**
	 * Prikaz verzije aplikacije,i njen opis. Nakon sledi biografija svakog autora.
	 */
	private static final long serialVersionUID = 1L;
/**
 * Sadrzaj se nalazi u JTextArea , dodato je dugme Close za izlazak iz Dijaloga.
 */
	public AboutDialog() {

		setSize(750,550);
        setLocationRelativeTo(null);
        setTitle("About");
        ImageIcon aboutIcon=new ImageIcon("Images"+File.separator+"about.png");
        setIconImage(aboutIcon.getImage());
        
        
        JPanel panel=new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton closebutton=new JButton("Close");
        
        
        panel.add(closebutton);
        getContentPane().add(panel,BorderLayout.SOUTH);
        
        closebutton.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                
            }
        });
       
        JTextArea aboutDialog=new JTextArea(20,20);
        aboutDialog.setEditable(false);
        aboutDialog.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 15));
        aboutDialog.setText("\n"+"About us:                                "+"\r"+"\n"
        +"	Verzija applikacije : 1.0 "+"\n"
        +"	Aplikaciju radile Maja Blagic i Jelena Stajic. "+"\n"
        +"	Maja i Jelena su iz Bijeljine i drugarice su jos od osnovne skole. "+"\n"		
        +"	Jelena je zavrsila srednju Tehnicku skolu Mihajlo Pupin u Bijeljini,  "+"\n"  
        +"	dok je Maja zavrsila Gimnaziju Filip Visnjic u Bijeljini. "+"\n" 
        +"	Pored toga sto je (skromno)izvrstan programer Jelenin specijalan talenat je u plesu."+"\n"		
        +"	Majin specijalan talenat je da moze pojesti mnogo slatkisa. "+"\n"		
        +"	Njoj apsolutno nije jasno kako Jelena ne pojede Snickers u menzi "+"\n"		
        
      		
        		);
        getContentPane().add(aboutDialog);
		
        
	
	
	}
}
