package studentska.sluzba.model;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import studentska.sluzba.controller.PredmetiController;
import studentska.sluzba.gui.MainFrame;
import studentska.sluzba.model.Predmet.Semestar;
import studentska.sluzba.model.Profesor.Titula;
import studentska.sluzba.model.Profesor.Zvanje;

/**
 * Klasa koja cini Bazu Profesora i implementira metode nad tom bazom.
 * @author Maja Blagic
 *
 *
 */

public class BazaProfesora  {

		
		private static BazaProfesora instance = null;
		/**
		 * 
		 * @return - vraca instancu Baze Profesora
		 */
		public static BazaProfesora getInstance() {
			if(instance == null) {
				instance = new BazaProfesora();
			}
			return instance;
		}
		
		private List<Profesor> profesori;
		private List<String> kolone;
	/**
	 * Konstruktor inicijalizeuje listu profesora i kolona.
	 */
		private BazaProfesora() {
				
				profesori = new ArrayList<Profesor>();		
				initProfesore();
				
				this.kolone = new ArrayList<>();
				this.kolone.add("IME");
				this.kolone.add("PREZIME");				
				this.kolone.add("TITULA");
				this.kolone.add("ZVANJE");
				
			}
		
		
	/**
	 * Metoda koja poziva deserijalizaciju i puni bazu podacima
	 */
		private void initProfesore()  {
			
		deserijalizacijaProfesora();
			
			
			//this.profesori = new ArrayList<Profesor>();		
			
			//profesori.add(new Profesor("Markovic", "Marko","Narodnog fronta 4", "021/222-333", "markomarkovic@gmail.com", "Bulevar Oslobodjenja 16", "7T1577", Titula.dr, Zvanje.Redovni_profesor));
			//profesori.add(new Profesor("Peric", "Pera","Narodnog fronta 4", "021/222-333", "peraperic@gmail.com", "Bulevar Oslobodjenja 16", "7T1567", Titula.dr, Zvanje.Redovni_profesor));


			/*
		/*	
			profesori.add(new Profesor("Markovic", "Marko","Narodnog fronta 4", "021/222-333", "markomarkovic@gmail.com", "Bulevar Oslobodjenja 16", "7T1577", Titula.dr, Zvanje.Redovni_profesor));
			profesori.add(new Profesor("Peric", "Pera","Narodnog fronta 4", "021/222-333", "peraperic@gmail.com", "Bulevar Oslobodjenja 16", "7T1567", Titula.dr, Zvanje.Redovni_profesor));

			profesori.add(new Profesor("Markovic", "Luka","Narodnog fronta 4", "021/222-333", "markomarkovic@gmail.com", "Bulevar Oslobodjenja 16", "T1577", Titula.dr, Zvanje.Redovni_profesor));
			profesori.add(new Profesor("Peric", "Stefan","Narodnog fronta 4", "021/222-333", "peraperic@gmail.com", "Bulevar Oslobodjenja 16", "T1567", Titula.dr, Zvanje.Redovni_profesor));
		    
			//provjera da li dbr ispisuje tabelu predmeti profesora
			Profesor p1 = new Profesor("lukic", "Luka","Narodnog fronta 4", "021/222-333", "markomarkovic@gmail.com", "Bulevar Oslobodjenja 16", "T15000", Titula.dr, Zvanje.Redovni_profesor);
			ArrayList<Predmet> lp1 = new ArrayList<Predmet>();
			lp1.add(new Predmet("pom1", "nazivPOM1", Semestar.LETNJI, 2, 5));
			ArrayList<Predmet> lp2 = new ArrayList<Predmet>();
			lp2.add(new Predmet("pomMoguci1", "nazivPOM1moguci", Semestar.LETNJI, 2, 5));
			
			p1.setPredmetiNaKojimJeProfesor(lp1);

			Profesor p2 = new Profesor("Jovic", "Jovan","Narodnog fronta 4", "021/222-333", "markomarkovic@gmail.com", "Bulevar Oslobodjenja 16", "T15000", Titula.dr, Zvanje.Redovni_profesor);
			ArrayList<Predmet> lp3 = new ArrayList<Predmet>();
			lp3.add(new Predmet("sau11", "sau", Semestar.LETNJI, 2, 5));
			
			p2.setPredmetiNaKojimJeProfesor(lp3);
			//p1.setMoguciPredmeti(lp2);
			//profesori.add(p1);
			profesori.add(p2);
			//valjda ovo radi 
			 * */
			 
			napuniMoguceZaDodati();
			
			
		}
		
		public List<Profesor> getProfesori() {
			return profesori;
		}
		
		public void setProfesori(List<Profesor> profesori) {
			this.profesori = profesori;
		}
		
		public int getColumnCount() {
			return 4;
		}
	
		public String getColumnName(int index) {
			return this.kolone.get(index);
		}
		
		public Profesor getRow(int rowIndex) {
			return this.profesori.get(rowIndex);
		}
		
		public String getValueAt(int row,int column) {
			Profesor profesor = this.profesori.get(row);
			switch (column) {
			case 0: 
				return profesor.getIme();
			case 1:
				return profesor.getPrezime();
			case 2:
				return  profesor.getTitula().toString();
			case 3:
				return profesor.getZvanje().toString();
			default:
					return null;		
			}
		}
		
		public void dodajProfesora(String ime,String prezime,Date datumRodjenja,
									String adresaStanovanja,String telefon,String mail,
									String adresaKancelarije,String brLicneKarte,
									Titula titula,Zvanje zvanje){
		this.profesori.add(new Profesor(ime,prezime,datumRodjenja,adresaStanovanja,telefon,
										mail,adresaKancelarije,brLicneKarte,titula,zvanje));
}
		
		public void dodajProfesora(Profesor profesor) {
			profesori.add(profesor);
		}
		
		@SuppressWarnings("unlikely-arg-type") //PITATI DA LI SIFRA PREDMETA MORA BITI STRING ILI MOZE BITI INT
		/**
		 * Metoda koje brise profesora po proslijedjenom kljucu/broju licne karte profeosra
		 * @param brLicneKarte - proslijedjeni kljuc
		 */
		public void izbrisiProfesora(String brLicneKarte)
		{
			for(Profesor p : profesori) {
				if(p.getBrLicneKarte() == brLicneKarte) {
					profesori.remove(p);
					break;
				}
			}
		}
		/**
		 * Metoda koja koristi prosliedjene parametre da bi izmijenila atribute entiteta Profesor
		 * Nakon toga azurita prikaz MainFrame-a;
		 * @param brLicneKarte - broj licne karte Profesora
		 * @param ime - ime profesora
		 * @param prezime - prezime profesora
		 * @param datumRodjenja - datum rodjenja profesora
		 * @param adresaStanovanja - adresa stanovanja profesora
		 * @param telefon - telefon profesora
		 * @param mail - mail profesora
		 * @param adresaKancelarije - adresa kancelarije profesora
		 * @param titula - titula profesora
		 * @param zvanje - zvanje profesora
		 */
		public void izmjeniProfesora(String brLicneKarte,String ime,String prezime,Date datumRodjenja,
									String adresaStanovanja,String telefon,String mail,
									String adresaKancelarije,
									Titula titula,Zvanje zvanje) {
			Profesor prof = profesori.get(MainFrame.getInstance().selectedProfesorRow());
			
		
				//if(p.getBrLicneKarte().equals(brLicneKarte)) {
					prof.setBrLicneKarte(brLicneKarte);
					prof.setIme(ime);
					prof.setPrezime(prezime);
					prof.setDatumRodj(datumRodjenja);
					prof.setAdresaStanovanja(adresaStanovanja);
					prof.setTelefon(telefon);
					prof.setMail(mail);
					prof.setAdresaKancelarije(adresaKancelarije);
					prof.setTitula(titula);
					prof.setZvanje(zvanje);
				//}
			//}
			MainFrame.getInstance().azurirajPrikazProfesora(null, -1);
		}
		
		/**
		 * Metoda koja provjerava jedinstvenost proslijedjenog kljuca/brLisneKarte profesora
		 * @param brLicneKarte - kljuc 
		 * @return true ako je kljuc jedinstven
		 */
		public Boolean uniqueBrLicneKarte(String brLicneKarte) {
			
			for(Profesor p: profesori) {
				if(p.getBrLicneKarte().equals(brLicneKarte)) {
					return false;
				}
			}
			return true;
		}
/**
 * Metoda koje dodaje predmet na listu predmeta koje profesor predaje i uklanja sa liste predmeta koje profesor moze predavati
 * @param p - profesor
 * @param predmet  - predmet koji mu dodajemo
 */
		public void dodajPredmetProfesoru(Profesor p,Predmet predmet) {
			
			p.getPredmetiNaKojimJeProfesor().add(predmet);
			p.getMoguciPredmeti().remove(predmet);
		}
/**
 * Metoda koja uklanja predmet na kome profesor predaje, i vraca ga na listu predmeta koje profesor moze pradavati.
 * @param p - profesor
 * @param predmet - predmet
 */
		
public void ukloniPredmetProfesoru(Profesor p,Predmet predmet) {
		
			
			p.getPredmetiNaKojimJeProfesor().remove(predmet);
			p.getMoguciPredmeti().add(predmet);
		}







//ne znam da li ova funkcija valjda
public void napuniMoguceZaDodati() {
	ArrayList<Predmet> predm = PredmetiController.getInstance().vratiSvePredmete();
//iteriram kroz sve predmete iz baze 
	for(Predmet p : predm)
	{
		//za svaki predmet iteriram kroz sve profesore i gledam za svakog
		//profesora da li predaje na tom predmetu i ako ne predaje dodam ga na listu mogucih predmeta za dodavanje profesoru 
		for(Profesor prof  :  profesori ) {
			
			for(Predmet p2 : prof.getPredmetiNaKojimJeProfesor()) {
				if(!p.equals(p2))
				{
					prof.getMoguciPredmeti().add(p);
				}
			}
		}
	}
	
}



public void serijalizacijaProfesora() {
	
	ObjectOutputStream out  = null ;
	try {
		out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("profesori.txt")));
		out.writeObject(profesori);
	}catch (IOException e) {
		e.printStackTrace();
	}finally {
		if(out != null) {
			try {
				out.close();
			}catch (IOException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}
	
}
/**
 * Metoda deserijalizacij koja cita podatke iz proslijedjenje datoteke. Ti podaci se ucitavaju 
 * u aplikaciju .
 */
public void deserijalizacijaProfesora() {
	ObjectInputStream in;
	try {
		in= new ObjectInputStream(new BufferedInputStream(new FileInputStream("profesori.txt")));
		try {
			profesori = (ArrayList<Profesor>) in.readObject();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	//MainFrame.getInstance().azurirajPrikazProfesora(null, 0);
	
}

	
}



