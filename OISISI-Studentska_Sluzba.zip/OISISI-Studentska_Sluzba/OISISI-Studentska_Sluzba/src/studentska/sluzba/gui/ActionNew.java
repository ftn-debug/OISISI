package studentska.sluzba.gui;



import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

import studentska.sluzba.pop.dialogs.AddPredmetDialog;
import studentska.sluzba.pop.dialogs.AddProfesorDialog;
import studentska.sluzba.pop.dialogs.AddStudentDialog;

public class ActionNew extends AbstractAction {

	private static final long serialVersionUID = 1583426086994634757L;

	public ActionNew() {
		//putValue(NAME, "New");
		putValue(MNEMONIC_KEY, KeyEvent.VK_K);
		putValue(SHORT_DESCRIPTION, "New");
		putValue(SMALL_ICON, new ImageIcon("Images"+ File.separator +"add.png"));
		putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_K, KeyEvent.CTRL_MASK));
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		switch(MainFrame.getInstance().selectedTab()) {
		
		case 0:
			AddStudentDialog a = new AddStudentDialog();
			//a.setVisible(true);
			break;
		case 1:
			AddProfesorDialog  b = new AddProfesorDialog();
			//b.setVisible(true);
			break;
		case 2:
			AddPredmetDialog c = new AddPredmetDialog();
			break;
		default:
				break;
				
		}
		
	}

}
