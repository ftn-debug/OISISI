package studentska.sluzba.pop.dialogs;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.ParseException;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import studentska.sluzba.controller.PredmetiController;
import studentska.sluzba.gui.MainFrame;
import studentska.sluzba.model.Predmet;
import studentska.sluzba.model.Predmet.Semestar;

/**
 * Klasa koja predstavlja JDialog za dodavanje Predmeta.
 * Sadrzi formu za unos informacija o predmetu.
 * @author Maja Blagic
 *
 */
public class AddPredmetDialog extends JDialog implements ActionListener{
	
	private static final long serialVersionUID = 1L;
	static JLabel sifraPredmeta;
	static JLabel nazivPredmeta;
	static JLabel semestar;
	static JLabel godinaNaKojojSeIzvodi;
	static JLabel brESPBbodova;
	
	static JTextField poljeSifraPredmeta;
	static JTextField poljeNazivPredmeta;
	static JComboBox<Semestar> comboBoxSemestar;
	static JTextField poljeGodinaNaKojojSeIzvodi;
	static JTextField poljeBrESPBbodova;
	
	
	/**
	 * Konstruktor sadrzi JLabele za i JTextFieldove za unos i prijem podataka od korisnika.
	 */
 public AddPredmetDialog() {

 
	 	JDialog parent= this;
 
	 setTitle("Dodavanje predmeta");
		sifraPredmeta = new JLabel("Sifra predmeta*");
		nazivPredmeta = new JLabel("Naziv predmeta*");
		semestar = new JLabel("Semestar*");
		godinaNaKojojSeIzvodi = new JLabel("Godina na kojoj se izvodi*");
		brESPBbodova = new JLabel("Broj ESPB bodova*");
		
		poljeSifraPredmeta = new JTextField(15);
		poljeSifraPredmeta.setName("Sifra predmeta*");
		
		poljeNazivPredmeta = new JTextField(15);
		poljeNazivPredmeta.setName("Naziv predmeta*");
		
		poljeGodinaNaKojojSeIzvodi = new JTextField(15);
		poljeGodinaNaKojojSeIzvodi.setName("Godina na kojoj se izvodi*");
		
		poljeBrESPBbodova = new JTextField(15);
		poljeBrESPBbodova.setName("Broj ESPB bodova*");
		
		comboBoxSemestar = new JComboBox<>();
		comboBoxSemestar.setName("Semestar*");
		DefaultComboBoxModel<Semestar> t = new DefaultComboBoxModel<Semestar>();
		t.addElement(Semestar.LETNJI);
		t.addElement(Semestar.ZIMSKI);
		comboBoxSemestar.setModel(t);
		comboBoxSemestar.setSelectedIndex(0);
		comboBoxSemestar.setEditable(false);
		
		
		JButton okButton = new JButton("Potvrdi");
		JButton cancelButton = new JButton("Odustani");
		
		
	
		okButton.setEnabled(false);
		FocusListener fl1 = new FocusListener() {

			@Override
			public void focusLost(FocusEvent e) {
				if( (poljeSifraPredmeta.getText().isEmpty() || poljeNazivPredmeta.getText().isEmpty() 
						| poljeGodinaNaKojojSeIzvodi.getText().isEmpty() || poljeBrESPBbodova.getText().isEmpty() 
						) ) {
					okButton.setEnabled(false);
				}

			}

			@Override
			public void focusGained(FocusEvent e) {
				if(!(poljeSifraPredmeta.getText().isEmpty() || poljeNazivPredmeta.getText().isEmpty() 
						| poljeGodinaNaKojojSeIzvodi.getText().isEmpty() || poljeBrESPBbodova.getText().isEmpty() 
						)) {
					okButton.setEnabled(true);
				}

			}
		};
		
		
		poljeSifraPredmeta.addFocusListener(fl1);
		poljeNazivPredmeta.addFocusListener(fl1);
		poljeGodinaNaKojojSeIzvodi.addFocusListener(fl1);
		poljeBrESPBbodova.addFocusListener(fl1);
		
		
		okButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Predmet predmet;
				try {
					predmet = collectData();
					
					if(predmet == null) {
						//Neki JOIprionPane dijalozi ce biti zakomentarisani jer onemogucavaju rad aplikacje!
						//
					
						JOptionPane.showMessageDialog(parent, "Morate validno popuniti sva polja!", "Pogresan unos", JOptionPane.ERROR_MESSAGE);
						okButton.setToolTipText("Morate uneti sva polja!");
						
						
					}else {
						if(PredmetiController.getInstance().uniqueSifraPredmeta(predmet))
						{
							PredmetiController.getInstance().dodajPredmet(predmet);
							//dispose();
						}else {
							JOptionPane.showMessageDialog(parent, "Sifra predmeta nije jedinstvena!");
							okButton.setToolTipText(" Broj licne karte nije jedinstven!");
							
						}
						
					}
				}catch(ParseException pe) {
					pe.printStackTrace();
				}				
			}
		});
		
		cancelButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				
			}
		});
		
		
		setLayout(okButton,cancelButton);
		
		setLocationRelativeTo(null);
		setSize(new Dimension(500,500));
		setResizable(false);
		setModal(true);
		setLocationRelativeTo(MainFrame.getInstance());
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
		
		setVisible(true); 
 
 } 
 /**
  * Osnovni layout Dijaloga za dodavanje predmeta. Sadrzi polja koja treba popuniti i 
  * dugmad za potvrdu ili odustajanje od akcije.
  * @param okButton - potvrda unosa novog studenta
  * @param cancelButton- odustanak od dodavanja studenta
  */
 private void setLayout(JButton okButton, JButton cancelButton) {
		setLayout(new GridBagLayout());
		
		GridBagConstraints gc=new GridBagConstraints();
		
		gc.weightx=0.01;
		gc.weighty=0.01;
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(20, 20, 0, 0);
		gc.fill=GridBagConstraints.NONE;
		gc.anchor=GridBagConstraints.LINE_START;
		
		add(sifraPredmeta,gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.anchor=GridBagConstraints.LINE_START;

		add(poljeSifraPredmeta,gc);
		//--------------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		
		gc.gridy = 1;
		gc.gridx = 0;
		gc.insets = new Insets(20, 20, 0, 0);
		gc.anchor=GridBagConstraints.LINE_START;
		add(nazivPredmeta,gc);
		

		gc.gridy = 1;
		gc.gridx = 1;
		gc.anchor=GridBagConstraints.LINE_START;
		add(poljeNazivPredmeta,gc);
		//----------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		
		gc.gridy = 2;
		gc.gridx = 0;
		gc.insets = new Insets(20, 20, 0, 0);

		gc.anchor=GridBagConstraints.LINE_START;
		add(semestar,gc);
		

		gc.gridy = 2;
		gc.gridx = 1;
		gc.anchor=GridBagConstraints.LINE_START;

		add(comboBoxSemestar,gc);
		//---------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		
		gc.gridy = 3;
		gc.gridx = 0;
		gc.anchor=GridBagConstraints.LINE_START;
		add(godinaNaKojojSeIzvodi,gc);
				
		gc.gridy = 3;
		gc.gridx = 1;
		gc.anchor=GridBagConstraints.LINE_START;
		add(poljeGodinaNaKojojSeIzvodi,gc);
		
		//PROVERITI
		gc.gridy = 4;
		gc.gridx = 0;
		gc.anchor=GridBagConstraints.LINE_START;
		add(brESPBbodova,gc);
				
		gc.gridy = 4;
		gc.gridx = 1;
		gc.anchor=GridBagConstraints.LINE_START;
		add(poljeBrESPBbodova,gc);
		

		gc.gridy = 5;
		gc.gridx = 1;
		gc.anchor=GridBagConstraints.LINE_START;
		add(okButton,gc);
				
		gc.gridy = 5;
		gc.gridx = 2;
		gc.anchor=GridBagConstraints.LINE_START;
		add(cancelButton,gc);
	}
	

	
 /**
  * Metoda koja prima korisnicki unesene podatke i od njih pravi novi entitet Predmet.
  * Predmet ce naknadno biti dodan u Bazu Predmeta. 
  * @return novi uneseni Predmet
  * @throws ParseException ako nije moguce parsirati neki od podataka pri obradi korisnicki unesenih podataka
  */
	private Predmet collectData() throws ParseException {
			
			Predmet pred;
			pred = null;
			try {
			String sifra = poljeSifraPredmeta.getText();
			String naziv = poljeNazivPredmeta.getText();
			int godina = Integer.parseInt(poljeGodinaNaKojojSeIzvodi.getText());
			int espb = Integer.parseInt(poljeBrESPBbodova.getText());
			
			Semestar seme = (Semestar) comboBoxSemestar.getSelectedItem() ;
			//vrati objekat i onda ga kastujem u semestar
			
			if(sifra.equals("") || naziv.equals("") || 
					seme.equals(null) || poljeGodinaNaKojojSeIzvodi.getText().equals("") 
					|| poljeBrESPBbodova.getText().equals("")) {
				System.out.println("Error imput");
				return null;	
			}
			
			pred = new Predmet(sifra,naziv,seme,godina,espb);
			
					
			}catch (Exception e) {
				e.printStackTrace();
			}
			return pred;
		}


@Override
public void actionPerformed(ActionEvent arg0) {
	// TODO Auto-generated method stub
	
}

}
