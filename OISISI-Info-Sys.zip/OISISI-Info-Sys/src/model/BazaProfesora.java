package model;

import java.util.ArrayList;
import java.util.List;



public class BazaProfesora {

		private static BazaProfesora instance = null;
		
		public static BazaProfesora getInstance() {
			if(instance == null) {
				instance = new BazaProfesora();
			}
			return instance;
		}
		
		private List<Profesor> profesori;
		private List<String> kolone;
	
		private BazaProfesora() {
				
				
				initProfesore();
				
				this.kolone = new ArrayList<>();
				this.kolone.add("IME");
				this.kolone.add("PREZIME");
				this.kolone.add("TITULA");
				this.kolone.add("ZVANJE");
				
			}
			
		private void initProfesore() {
			
			this.profesori = new ArrayList<Profesor>();		
			
		}
		
		public List<Profesor> getProfesori() {
			return profesori;
		}
		
		public void setProfesori(List<Profesor> profesori) {
			this.profesori = profesori;
		}
		
		public int getColumnCount() {
			return 4;
		}
	
		public String getColumnName(int index) {
			return this.kolone.get(index);
		}
		
		public Profesor getRow(int rowIndex) {
			return this.profesori.get(rowIndex);
		}
		
		public String getValueAt(int row,int column) {
			Profesor profesor = this.profesori.get(row);
			switch (column) {
			case 0: 
				return profesor.getIme();
			case 1:
				return profesor.getPrezime();
			case 2:
				return profesor.getTitula();
			case 3:
				return profesor.getZvanje();
			default:
					return null;		
			}
		}
		
		public void dodajProfesora(String ime,String prezime,String datumRodjenja,
									String adresaStanovanja,String telefon,String mail,
									String adresaKancelarije,String brLicneKarte,
									String titula,String zvanje){
		this.profesori.add(new Profesor(ime,prezime,datumRodjenja,adresaStanovanja,telefon,
										mail,adresaKancelarije,brLicneKarte,titula,zvanje));
}
		
		public void dodajProfesora(Profesor profesor) {
			profesori.add(profesor);
		}
		
		@SuppressWarnings("unlikely-arg-type") //PITATI DA LI SIFRA PREDMETA MORA BITI STRING ILI MOZE BITI INT
		public void izbrisProfesora(String brLicneKarte)
		{
			for(Profesor p : profesori) {
				if(p.getBrLicneKarte() == brLicneKarte) {
					profesori.remove(brLicneKarte);
					break;
				}
			}
		}
		
		public void izmeniPredmet(String brLicneKarte,String ime,String prezime,String datumRodjenja,
									String adresaStanovanja,String telefon,String mail,
									String adresaKancelarije,
									String titula,String zvanje) {
			for(Profesor p : profesori) {
				if(p.getBrLicneKarte() == brLicneKarte) {
					p.setIme(ime);
					p.setPrezime(prezime);
					p.setDatumRodj(datumRodjenja);
					p.setAdresaStanovanja(adresaStanovanja);
					p.setTelefon(telefon);
					p.setMail(mail);
					p.setAdresaKancelarije(adresaKancelarije);
					p.setTitula(titula);
					p.setZvanje(zvanje);
				}
			}
			
		}
		
}
