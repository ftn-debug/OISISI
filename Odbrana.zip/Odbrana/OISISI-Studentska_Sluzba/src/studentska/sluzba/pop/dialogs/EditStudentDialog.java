package studentska.sluzba.pop.dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;

import studentska.sluzba.controller.StudentiController;
import studentska.sluzba.gui.AbstractTableModelNepolozeniPredmeti;
import studentska.sluzba.gui.AbstractTableModelPolozeniPredmet;
import studentska.sluzba.gui.AbstractTableModelSpisakPredmetaDaPolaze;
import studentska.sluzba.gui.InformacijeStudent;
import studentska.sluzba.gui.MainFrame;
import studentska.sluzba.gui.NepolozeniPredmetiTable;
import studentska.sluzba.gui.PolozeniPredmetiPanel;
import studentska.sluzba.gui.PolozeniPredmetiTable;
import studentska.sluzba.gui.SpisakPredmetaDaPolazeTable;
import studentska.sluzba.model.Predmet;
import studentska.sluzba.model.Student;

/**
 * Klasa koja predstavlja dijalog za izmjenu entiteta Student.
 * Dijalog sadrzi 3 Taba:
 * Informacije - sa detaljnim podacima o studentu.
 * Položeni - sa spiskom položenih predmeta.
 * Nepoloženi - sa spiskom nepoloženih predmeta.
 * 
 * 
 * 
 * @author Maja Blagic
 *
 */
public class EditStudentDialog extends JDialog{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	
	
	public JDialog master ;
	/**
	 * 
	 * @param s - proslijedjen Student koji je selektovan u Instanci MainFrame-a.
	 */
	public EditStudentDialog( Student s) {

		super();
		master=this;


		setTitle("Editovanje Studenta");
		setSize(new Dimension(700,500));
		setResizable(false);
		//setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(MainFrame.getInstance());
		setVisible(true);
		setLayout(new BorderLayout());
		
		setModal(true);
		getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
		createTabbedPane(s,this);
		setVisible(true);
	}
	
	
	private JPanel Informacije; //klasa sa TableTab metodama
	private JTable Polozeni;
	private JTable spisakNepolozenih;
	private JTable spisakDaPolozi;
	private JPanel Nepolozeni;
	private JTabbedPane tabbedPane;
	/**
	 * 
	 * @return - vraca instancu TabbedPane-a
	 */
	public JTabbedPane getTabbedPane() {
		return tabbedPane;
	}	
	/**
	 * 
	 * @return - vraca selektovani Tab
	 */
	public int selectedTab() {
		return tabbedPane.getSelectedIndex();
	}


	//------------Tabela Nepolozenih---------------------------------------------------------------------------------------------------------
	
	/**
	 * U ovoj metodi se nalaze implementirane akcije za Dodavanje , Brisanje i Polagane ispita za selektovvanog studenta
	 * @param s selektovani student
	 * @param eds dijalog iz koga je pozvata klasa
	 * @return vraca JPanel koji sadrzi komponente (dudmadi i tabelu) i njihove funkcionalnosti
	 */
	private JPanel prikaziTabeluNepolozenihPredmeta(Student s,EditStudentDialog eds) {
				//ovaj prosledjeni student se moze zakomentarisati valjda
				Student prosledjenStudent = s;
				//setLayout(new BorderLayout());
				GridBagLayout gb = new GridBagLayout();
				JPanel panel = new JPanel(gb);
				//panel.setSize(new Dimension(700,500));
				//add(panel,BorderLayout.CENTER);
				//////////////////////////////////////////////////////////////
				
				
			
				/////////////////////////////////////////////////////////////// staticko popunjavanje tabele radi provjere
				
				//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
				
				
				spisakNepolozenih = new NepolozeniPredmetiTable(MainFrame.getInstance().selectedStudent());
				//PRAVLJENJE VIZUELNOG PRIKAZA
				//KOMPONENTE
				JScrollPane scrollPane = new JScrollPane(spisakNepolozenih);
				scrollPane.setVisible(true);
				this.azurirajPrikazNepolozenih(null, -1);
						
				//BUTTONS
				JButton dodaj = new JButton();
				dodaj.setText("Dodaj");
				JButton ukloni = new JButton();
				ukloni.setText("Obrisi");
				JButton polaganje = new JButton();
				polaganje.setText("Polaganje");
				
				
				//GRIDBAGLAYOUT 
				GridBagConstraints gc = new GridBagConstraints(0, 0, 1,
						1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(0, 30, 0, 10), 0, 0);
				panel.add(dodaj,gc);
				
				GridBagConstraints gc3 = new GridBagConstraints(1, 0, 1,
						1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(0, 10, 0, 10), 0, 0);
				panel.add(ukloni,gc3);
				
				GridBagConstraints gc4 = new GridBagConstraints(2, 0, 1,
						1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(0, 10, 0, 10), 0, 0);
				panel.add(polaganje,gc4);
				
				
				GridBagConstraints gc1 = new GridBagConstraints(0, 1, 5,
						5, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(15, 30, 30, 30), 600, 270);
				panel.add(scrollPane,gc1);
				Window parent = SwingUtilities.getWindowAncestor(this);
				
					//-----------------------------------------------------------------
				ActionListener listenerPolaganje = new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						if(spisakNepolozenih.getSelectedRow() <0)
						{
							//ovo zna da napravi problem,da zamrzne aplikaciju ,ne znam zasto
							//JOptionPane.showMessageDialog(parent, "Morate  selektovati nepoloženi predmet!");
							
						
						}else {
							//selektovani predmet
							
							Predmet predmet = prosledjenStudent.getSpisakNepolozenihIspita().get(spisakNepolozenih.getSelectedRow());
							UpisOceneDialog u = new UpisOceneDialog(predmet,prosledjenStudent,eds);
							
						}
						
					}
				};
				polaganje.addActionListener(listenerPolaganje);
			//-------------------------------------------------------------------------------------------------------------------------------------------------
				ActionListener listenerDodaj = new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						//treba mi ovdje da otvori listu predmeta koji se mogu dodati
						JButton dodaj1 = new JButton();
						dodaj1.setText("Dodaj");
						JButton odustani1 = new JButton();
						odustani1.setText("Odustani");
						
						GridBagLayout gb = new GridBagLayout();
						JPanel panel1 = new JPanel(gb);
						
						JDialog x= new JDialog();
						
						JScrollPane polaganje= prikaziTabeluPredmetaDaPolozi(s);
						
						

						ActionListener listenerDodaj1 = new ActionListener() {
							
							@Override
							public void actionPerformed(ActionEvent e) {
								if(spisakDaPolozi.getSelectedRow() <0)
								{
									//Ali mi zatvori dijalog
									//JOptionPane.showMessageDialog(x, "Morate  selektovati nepoloženi predmet!");
									
								
								
								}else {
									StudentiController.getInstance().azurirajListuNepolozenihPredmeta(s, spisakDaPolozi.getSelectedRow(), eds);
								}
								
							}
						};
						dodaj1.addActionListener(listenerDodaj1);
						
						ActionListener listenerOdustani1 = new ActionListener() {
							
							@Override
							public void actionPerformed(ActionEvent e) {
								
							//	dispose(); ovo mi ukine editovanje studenta
								x.dispose();
							}
						};
						odustani1.addActionListener(listenerOdustani1);
						
						
						x.setTitle("Editovanje Studenta");
						x.setSize(new Dimension(400,400));
						x.setLocationRelativeTo(parent);
						x.getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
						
						GridBagConstraints gc = new GridBagConstraints(0, 0, 1,
								1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(0, 30, 0, 10), 0, 0);
						panel1.add(dodaj1,gc);
						GridBagConstraints gc1 = new GridBagConstraints(2, 0, 1,
								1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(0, 10, 0, 10), 0, 0);
						panel1.add(odustani1,gc1);
						
						
						GridBagConstraints gc2 = new GridBagConstraints(0, 1, 5,
								5, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(15, 30, 30, 30), 300, 270);
						panel1.add(polaganje,gc2);
					
						x.add(panel1);
						
						
						
						x.setVisible(true);
						
						
					}
				};
				dodaj.addActionListener(listenerDodaj);
				ActionListener listenerUkloni = new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						if(spisakNepolozenih.getSelectedRow() <0)
						{
							//JOptionPane.showMessageDialog(parent, "Morate izabrati predmet!");
							
						
						
						}else {
							
							Object[] options = {"Da",
		                    "Ne"};
							int n = JOptionPane.showOptionDialog(master,
							    "Da li ste stigrni da zelite da uklonite predmeta?",
							    "Uklanjanje predmeta",
							    JOptionPane.YES_NO_OPTION,
							    JOptionPane.QUESTION_MESSAGE,
							    null,     //do not use a custom Icon
							    options,  //the titles of buttons
							    options[0]); //default button title
							
							if(n == JOptionPane.YES_OPTION) {
								StudentiController.getInstance().uklanjanjePredmetaSaStudenta(s,spisakNepolozenih.getSelectedRow(),eds);
							}else {
							    
							}
							
							
						}
						
					}
				};
				ukloni.addActionListener(listenerUkloni);
				
				
				
				
			
			return panel;
		}
			
			
/**
 * Metoda koja poziva klasu JTable SpisakPredmetaDaPolozi i smijesta je u scroll pane 
 * @param s  student koji je koriscen za kreiranje tabele
 * @return scrollPane koji sadrzi Tabelu predmeta koje student moze da polozi
 */
protected JScrollPane prikaziTabeluPredmetaDaPolozi(Student s) {

	spisakDaPolozi= new SpisakPredmetaDaPolazeTable(s);
	JScrollPane scrollPane3 = new JScrollPane(spisakDaPolozi);
	//pa od nje napravi scrollpane
	this.azurirajPrikazPredmetaDaPolozi(null, -1);
	
	return scrollPane3;



}
/**
 * Metoda koja azurira prikaz tabele predmeta koje student moze da polaze
 * @param object - unused
 * @param i - unsused
 */
			public void azurirajPrikazPredmetaDaPolozi(Object object, int i) {
				AbstractTableModelSpisakPredmetaDaPolaze model = (AbstractTableModelSpisakPredmetaDaPolaze) spisakDaPolozi.getModel();
				model.fireTableDataChanged();
				validate();
	
}
			public void azurirajPrikazNepolozenih(Object object, int i) {
						AbstractTableModelNepolozeniPredmeti model = (AbstractTableModelNepolozeniPredmeti) spisakNepolozenih.getModel();
						model.fireTableDataChanged();
						validate();
						
					}
/**
 * Ova klasa sadrzi Tabbed Pane sa 3 taba koji su kontejneri za Informacije o Studentu, Polozene i Nepolozene predmete tog Studenta.
 * @param s Student selektovan u instanci MainFrame-a
 * @param eds Referenca na ovaj dijalog, da bismo mogli apdejtovati tabele koje on sadrzi.
 */
private void createTabbedPane(Student s,EditStudentDialog eds) {
	tabbedPane = new JTabbedPane();
	
	//informacije
	Informacije =  new InformacijeStudent(s,eds);
	//polozeni panel
	JScrollPane Polozeni= prikaziTabeluPolozenihPredmeta(s);
	JPanel PolozeniFinal= new PolozeniPredmetiPanel(Polozeni,s , eds);
	Nepolozeni = prikaziTabeluNepolozenihPredmeta(s, eds);	
	
	//dodajem tabove
	tabbedPane.addTab("Informacije", Informacije);
	tabbedPane.addTab("Polozeni", PolozeniFinal);
	tabbedPane.addTab("Nepolozeni",Nepolozeni);
	
	this.setLocationRelativeTo(rootPane);
	add(tabbedPane,BorderLayout.CENTER);
			
}
/**
 * Metoda koja smijesta  poziva kreiranje Tabela polozenh predmeta za proslijedjenog Studenta.
 * Zatom tu tabelu smijesta u JScrollPane.
 * @param s - porosljedjen student za koga se kreira tabela polozenih predmeta
 * @return - vraca JScrollPane koji sadrzi Tabelu Polozenih Ispita za izabranog studenta
 */
private JScrollPane prikaziTabeluPolozenihPredmeta(Student s) {

	Polozeni = new PolozeniPredmetiTable(s);
	JScrollPane scrollPane3 = new JScrollPane(Polozeni);


	this.azurirajPrikazPolozeni(null, -1);
	
	return scrollPane3;

}
/**
 * Metoda koja se pozica da apdejtuje prikaz Tabele pri nekoj izmjeni u Bazi.
 * @param string unused
 * @param i unused
 */
public void azurirajPrikazPolozeni(String string, int i) {

	AbstractTableModelPolozeniPredmet model = (AbstractTableModelPolozeniPredmet) Polozeni.getModel();
	model.fireTableDataChanged();
	validate();
}

}

