package pop.dialogs;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

import gui.MainFrame;

public class PonistiOcenuDialog extends JDialog  implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
public PonistiOcenuDialog() {
	// TODO Auto-generated constructor stub
	Object[] options = { "Da", "Ne" };
	//JOptionPane optionPane = new JOptionPane();
	int opcija = JOptionPane.showOptionDialog(null,"Da li ste sigurni da želite da \n "
		    + "ponistite predmet?", "Brisanje predmeta.",
	    JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
	    null, options, options[1]);
	
	if(opcija == JOptionPane.YES_OPTION) {
		System.out.println("Brisanje predmeta");
	}
	
	
	setLocationRelativeTo(null);
	setSize(new Dimension(250,150));
	setResizable(false);
	setModal(true);
	setLocationRelativeTo(MainFrame.getInstance());
	//setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
	getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
	
}	
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
