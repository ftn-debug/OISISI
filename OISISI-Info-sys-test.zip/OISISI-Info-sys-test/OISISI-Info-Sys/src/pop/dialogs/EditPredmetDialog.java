package pop.dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;

import gui.InformacijePredmet;
import model.Predmet;
import view.ProfesoriJTable;

public class EditPredmetDialog extends JDialog/* implements ActionListener*/ {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	
	//treba mi tu neki JFrame=JDialog
	//private JPanel Informacije; 
	//private JPanel Polozeni;
	//private JPanel Nepolozeni;
	//private JTabbedPane tabbedPane;
	//Valjda tabbedPane nema neke metode kao JTabbedPaneCloseButton
	//dobar primjer za layout i MouseListenere
	
	public EditPredmetDialog(Predmet pr) {
		
		super();
		//
		Toolkit kit = Toolkit.getDefaultToolkit();
		setTitle("Editovanje Predmeta");
		setSize(new Dimension(400,450));
		setResizable(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
		setLayout(new BorderLayout());	
		setModal(true);
        getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
		 
        createTabbedPane(pr);
		 setResizable(true);
		 setVisible(true);		
	}
	private JPanel Informacije; //klasa sa TableTab metodama
	private JPanel Polozeni;
	private JPanel Nepolozeni;
	private JTabbedPane tabbedPane;
	
	public JTabbedPane getTabbedPane() {
		return tabbedPane;
	}	
	public int selectedTab() {
		return tabbedPane.getSelectedIndex();
	}
	private void createTabbedPane(Predmet pr) {
		tabbedPane = new JTabbedPane();
		Informacije =  new InformacijePredmet(pr,this); 
		//Polozeni= new JPanel(); //sad ovo mijenjam ,prvo treba mi 
		//Nepolozeni= new JPanel();
		

		tabbedPane.addTab("Izmeni predmet", Informacije);

		tabbedPane.addTab("Informacije", Informacije);

		//tabbedPane.addTab("Student koji su polozili", Polozeni);
		//tabbedPane.addTab("Studenti koji nisu polozeni", Nepolozeni);
		
		this.setLocationRelativeTo(rootPane);
		add(tabbedPane,BorderLayout.CENTER);
		
	}

}
