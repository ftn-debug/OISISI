package studentska.sluzba.gui;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

import studentska.sluzba.model.Ocena;
import studentska.sluzba.model.Predmet;
/**
 * Klasa koja predstavlja tabelu polozenih predmeta za entitet Studenta
 * @author Maja Blagic
 *
 */
public class AbstractTableModelPolozeniPredmet extends AbstractTableModel {

	private static final long serialVersionUID = 1L;
	private ArrayList<Ocena> ocenaList;
	private String[] columns;
	
	public AbstractTableModelPolozeniPredmet(ArrayList<Ocena> arrayList) {
		 super();
		 this.ocenaList=arrayList;
		columns = new String[]{"SIFRA PREDMETA","NAZIV PREDMETA", "BROJ ESP BODOVA",
		"GODINA NA KOJOJ SE PREDMET IZVODI","SEMESTAR"};
	  }
	public String getColumnName(int column) {
		return columns[column];
	}
	

	@Override
	public int getColumnCount() {
		return columns.length;
		
	}

	@Override
	public int getRowCount() {
		return ocenaList.size();
	}

	@Override
	public Object getValueAt(int row, int col) {
	
			Ocena ocena=ocenaList.get(row);
			Predmet predmet = ocena.getPredmet();
			
		switch(col) {
		case 0: 
			return predmet.getSifraPredmeta();
		case 1:
			return predmet.getNazivPredmeta();
		case 2:
			return Integer.toString(predmet.getBrESPBbodova());
		case 3:
			return ocena.getVijrednostOcene()+ "";
			
		case 4:
			return Integer.toString(predmet.getGodinaStudija());
		default:
				return null;	
		
	
		}
	
	}

	

}
