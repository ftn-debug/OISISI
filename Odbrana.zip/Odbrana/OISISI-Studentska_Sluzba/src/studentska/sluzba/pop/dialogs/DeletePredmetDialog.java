package studentska.sluzba.pop.dialogs;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

import studentska.sluzba.controller.PredmetiController;
import studentska.sluzba.gui.MainFrame;
import studentska.sluzba.model.Predmet;
/**
 * Klasa koja se koristi za brisanje profesora
 * @author Maja Blagic
 *
 */
public class DeletePredmetDialog extends JDialog implements ActionListener{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public DeletePredmetDialog(Predmet p) {
		Object[] options = { "Da", "Ne" };
		//JOptionPane optionPane = new JOptionPane();
		int opcija = JOptionPane.showOptionDialog(null,"Da li ste sigurni da želite da \n "
			    + "obrišete predmet?", "Brisanje predmeta",
		    JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
		    null, options, options[1]);
		
		if(opcija == JOptionPane.YES_OPTION) {
			PredmetiController.getInstance().izbrisiPredmet(p);
		}
		
		
		
		
		setLocationRelativeTo(null);
		setSize(new Dimension(250,150));
		setResizable(false);
		setModal(true);
		setLocationRelativeTo(MainFrame.getInstance());
		//setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
		
		//setVisible(true);
		
	
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
}
