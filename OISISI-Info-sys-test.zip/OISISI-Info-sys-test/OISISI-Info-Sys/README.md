# OISISI-Info-Sys
#Prvi student -Maja Blagic
#Drugi student- Jelena Stajic
# JDK 15.0.1
# Eclipse IDE for Java Developers 2020-09