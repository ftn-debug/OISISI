package model;


import java.util.List;

import model.Predmet.Semestar;


import java.util.ArrayList;
public class BazaPredmeta {
	
	private static BazaPredmeta instance = null;
	
	public static BazaPredmeta getInstance() {
		if(instance == null) {
			instance = new BazaPredmeta();
		}
		return instance;
	}
	
	
	private List<Predmet> predmeti;
	private List<String> kolone;
	
	
	private BazaPredmeta() {
		
		
		initPredmete();
		
		this.kolone = new ArrayList<>();
		this.kolone.add("SIFRA PREDMETA");
		this.kolone.add("NAZIV PREDMETA");
		this.kolone.add("BROJ ESPB BODOVA");
		this.kolone.add("GODINA NA KOJOJ SE PREDMET IZVODI");
		this.kolone.add("SEMESTAR");
		this.kolone.add("PREDMETNI PROFESOR");
	}
	
	private void initPredmete() {
		
		this.predmeti = new ArrayList<Predmet>();		
		
	}
	
	public List<Predmet> getPredmeti() {
		return predmeti;
	}


	public void setPredmeti(List<Predmet> predmeti) {
		this.predmeti = predmeti;
	}
	
	
	public int getColumnCount() {
		return 6;
	}
	
	public String getColumnName(int index) {
		return this.kolone.get(index);
	}
	
	public Predmet getRow(int rowIndex) {
		return this.predmeti.get(rowIndex);
	}
	
	public String getValueAt(int row,int column) {
		Predmet predmet = this.predmeti.get(row);
		switch (column) {
		case 0: 
			return predmet.getSifraPredmeta();
		case 1:
			return predmet.getNazivPredmeta();
		case 2:
			return Integer.toString(predmet.getBrESPBbodova());
		case 3:
			return Integer.toString(predmet.getGodinaStudija());
		case 4:
			return predmet.getSemestar() + "";
		default:
				return null;		
		}
	}
	
	public void dodajPredmet(String sifra,String naziv,Semestar semestar,
							int godinaStudija,Profesor predmetniProfesor,int brESPB) {
		this.predmeti.add(new Predmet(sifra,naziv,semestar,godinaStudija,
									predmetniProfesor,brESPB));
	}
	
	public void dodajPredmet(Predmet predmet) {
		predmeti.add(predmet);
	}
	
	@SuppressWarnings("unlikely-arg-type") //PITATI DA LI SIFRA PREDMETA MORA BITI STRING ILI MOZE BITI INT
	public void izbrisPredmet(String id)
	{
		for(Predmet p : predmeti) {
			if(p.getSifraPredmeta() == id) {
				predmeti.remove(id);
				break;
			}
		}
	}
	
	public void izmeniPredmet(String sifra,String naziv,Semestar semestar,
			int godinaStudija,Profesor predmetniProfesor,int brESPB) {
		for(Predmet p : predmeti) {
			if(p.getSifraPredmeta() == sifra) {
				p.setNazivPredmeta(naziv);
				p.setSemestar(semestar);
				p.setGodinaStudija(godinaStudija);
				p.setPredmetniProfesor(predmetniProfesor);
				p.setBrESPBbodova(brESPB);
			}
		}
		
	}
	
	
	
}
