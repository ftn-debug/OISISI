package studentska.sluzba.view;

import javax.swing.table.AbstractTableModel;

import studentska.sluzba.model.BazaStudenata;
/**
 * Metoda nasljedjuje klasu AbstractTable model i omogucava nam da napravimo izgled/model nase tabele.
 * @author majab
 *
 */
public class AbstractTableModelStudent extends AbstractTableModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * @return broj redova
	 */
	@Override
	public int getRowCount() {
		return BazaStudenata.getInstance().getStudenti().size();
	}
		/**
		 *@return  broj kolona
		 */
	@Override
	public int getColumnCount() {
		return BazaStudenata.getInstance().getColumnCount();
	}
		/**
		 *@return  naziv kolone 
		 */
	@Override
	public String getColumnName(int column) {
		return BazaStudenata.getInstance().getColumnName(column);
	}
		/**
		 *@return vrijednost celije
		 */
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return	BazaStudenata.getInstance().getValueAt(rowIndex, columnIndex);
	}

}
