package studentska.sluzba.gui;


import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
/**
 * @deprecated ne koristi se klasa
 * @author majab
 *
 */
public class TextFieldListener implements KeyListener{

	
	//metoda zaduzena za tekstualnu komponentu:
	
	
	@Override
	public void keyPressed(KeyEvent arg0) {
		
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		

	}

	@Override
	public void keyTyped(KeyEvent arg0) {

	}
}
