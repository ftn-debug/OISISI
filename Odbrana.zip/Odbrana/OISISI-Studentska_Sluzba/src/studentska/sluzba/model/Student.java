package studentska.sluzba.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

/**
 * Klasa koja opisuje entitet Student
 * @author Maja Blagic
 */
public class Student implements Serializable {

	

	private static final long serialVersionUID = 1L;
/**
 * Enumeracija za status studenta
 * B-budzet
 * S-samofinansiranje
 * @author Maja Blagic
 *
 */
	public enum Status{/**budzet*/ B,/**samofinansiranje*/ S};
	
	private String prezime;
	private String ime;
	private Date datumRodjenja;
	private String adresa;
	private String kontaktTelefon;
	private String eMail;
	private String brIndeksa;
	private int godinaUpisa;
	private int trenutnaGodinaStudija;
	private Status status;
	private double prosecnaOcena;
	private ArrayList<Ocena> spisakPolozenihIspita;
	private ArrayList<Predmet> spisakNepolozenihIspita;
	//Spisak nepolozenih ispita
	//Novo obiljezje
		//lista predmeta koje moze da polaze
	private ArrayList<Predmet> spisakPredmetaDaPolaze;
	
	/**
	 * Atributi entiteta Student
	 * @param ime  - ime studenta
	 * @param prezime  - prezime studenta 
	 * @param datumRodjenja - datum rodjenja studenta
	 * @param adresa - adresa stanovanja studenta
	 * @param kontaktTelefon - kontakt telefon studenta
	 * @param eMail - e mail studenta
	 * @param brIndeksa - br indeksa studenta
	 * @param godinaUpisa - godina upisa studenta na fakultet
	 * @param trenutnaGodinaStudija - trenutna godina studija studenta
	 * @param status - status studenta
	 * @param prosecnaOcena - prosjecna ocjena studenta 
	 */
	public Student(String ime, String prezime, Date datumRodjenja, String adresa, String kontaktTelefon, String eMail,
			String brIndeksa, int godinaUpisa, int trenutnaGodinaStudija, Status status, double prosecnaOcena) {
		super();
		this.prezime = prezime;
		this.ime = ime;
		this.datumRodjenja = datumRodjenja;
		this.adresa = adresa;
		this.kontaktTelefon = kontaktTelefon;
		this.eMail = eMail;
		this.brIndeksa = brIndeksa;
		this.godinaUpisa = godinaUpisa;
		this.trenutnaGodinaStudija = trenutnaGodinaStudija;
		this.status = status;
		this.prosecnaOcena = prosecnaOcena;
		this.spisakPolozenihIspita = new ArrayList<Ocena>(); 
		this.spisakNepolozenihIspita = new ArrayList<Predmet>(); 
		this.spisakPredmetaDaPolaze = new ArrayList<Predmet>();
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * Konstruktor za entitet Student
	 * @param entity - entitet Studenta
	 */
	public Student(Student entity) {
		
		this.prezime = entity.prezime;
		this.ime =  entity.ime;
		this.datumRodjenja =  entity.datumRodjenja;
		this.adresa =  entity.adresa;
		this.kontaktTelefon =  entity.kontaktTelefon;
		this.eMail =  entity.eMail;
		this.brIndeksa =  entity.brIndeksa;
		this.godinaUpisa =  entity.godinaUpisa;
		this.trenutnaGodinaStudija =  entity.trenutnaGodinaStudija;
		this.status =  entity.status;
		this.prosecnaOcena =  entity.prosecnaOcena;
		this.spisakPolozenihIspita = new ArrayList<Ocena>(); 
		this.spisakNepolozenihIspita = new ArrayList<Predmet>(); 
		this.spisakPredmetaDaPolaze = new ArrayList<Predmet>();
		
		
	}

	/**
	 * 
	 * @return prezime studenta
	 */
	public String getPrezime() {
		return prezime;
	}
	/**
	 * metoda koja postavlja vrijednost atributa entiteta na vrijednost parametra 
	 * 
	 *  @param prezime prezime studenta
	 */
	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}
	/**
	 * 
	 * @return ime ime studenta
	 */
	public String getIme() {
		return ime;
	}
	/**
	 * metoda koja postavlja vrijednost atributa entiteta na vrijednost parametra 
	 * @param ime ime studenta
	 */
	public void setIme(String ime) {
		this.ime = ime;
	}
	/**
	 * 
	 * @return datum rodjenja studenta
	 */
	public Date getDatumRodjenja() {
		return datumRodjenja;
	}
	/**
	 *  * metoda koja postavlja vrijednost atributa entiteta na vrijednost parametra 
	 * @param datumRodjenja datum rodjenhja studenta
	 */
	public void setDatumRodjenja(Date datumRodjenja) {
		this.datumRodjenja = datumRodjenja;
	}
	/**
	 * 
	 * @return adresu studenta
	 */
	public String getAdresa() {
		return adresa;
	}
	/**
	 *  metoda koja postavlja vrijednost atributa entiteta na vrijednost parametra 
	 * @param adresa adresa studenta
	 */
	public void setAdresa(String adresa) {
		this.adresa = adresa;
	}
	/**
	 * 
	 * @return kontakt telefon studenta
	 */
	public String getKontaktTelefon() {
		return kontaktTelefon;
	}
	/**
	 * metoda koja postavlja vrijednost atributa entiteta na vrijednost parametra 
	 * @param kontaktTelefon  kontakt telefon studenta
	 */
	public void setKontaktTelefon(String kontaktTelefon) {
		this.kontaktTelefon = kontaktTelefon;
	}
	/**
	 * 
	 * @return mail studenta
	 */
	public String geteMail() {
		return eMail;
	}
	/**
	 * metoda koja postavlja vrijednost atributa entiteta na vrijednost parametra 
	 * @param eMail mail studenta
	 */
	public void seteMail(String eMail) {
		this.eMail = eMail;
	}
	/**
	 * 
	 * @return broj indeksa studenta
	 */
	public String getBrIndeksa() {
		return brIndeksa;
	}
	/**
	 * metoda koja postavlja vrijednost atributa entiteta na vrijednost parametra 
	 * @param brIndeksa broj indeksa studenta
	 */
	public void setBrIndeksa(String brIndeksa) {
		this.brIndeksa = brIndeksa;
	}
	/**
	 * 
	 * @return godinu upisa studenta
	 */
	public int getGodinaUpisa() {
		return godinaUpisa;
	}
	/**
	 * metoda koja postavlja vrijednost atributa entiteta na vrijednost parametra 
	 * @param godinaUpisa  godinu upisa studenta
	 */
	public void setGodinaUpisa(int godinaUpisa) {
		this.godinaUpisa = godinaUpisa;
	}
	/**
	 * 
	 * @return trenutnu godinu studija studenta
	 */
	public int getTrenutnaGodinaStudija() {
		return trenutnaGodinaStudija;
	}
	/**
	 * metoda koja postavlja vrijednost atributa entiteta na vrijednost parametra 
	 * @param trenutnaGodinaStudija trenutnu godinu studija studenta
	 */
	public void setTrenutnaGodinaStudija(int trenutnaGodinaStudija) {
		this.trenutnaGodinaStudija = trenutnaGodinaStudija;
	}
	/**
	 * 
	 * @return enum status studenta
	 */
	public Status getStatus() {
		return status;
	}
	/**
	 * metoda koja postavlja vrijednost atributa entiteta na vrijednost parametra 
	 * @param status enum status studenta
	 */
	public void setStatus(Status status) {
		this.status = status;
	}
	/**
	 * 
	 * @return prosjecnu ocjenu studenta
	 */
	public double getProsecnaOcena() {
		return this.prosecnaOcena;
	}
	/**
	 * Metoda koje provjerava da li je student polozio predmete i 
	 * na osnovu toga poziva metodu za racunanje prosjeka tog studenta.
	 * @param s tip entiteta Student
	 * @return Vraca prosjecnu ocjenu (double) studenta
	 */
	public double getProsecnaOcena(Student s) {
		if(s.spisakPolozenihIspita == null) {
			return 0;
		}else {
		return setProsecnaOcenaFunction(s.spisakPolozenihIspita);
	}}
	/**
	 * Metoda koje postavlja poslje prosecna ocena na vrijednost proslijedjenog parametra.
	 * @param prosecnaOcena dodjeljujemo polju prosjecna ocjena
	 */
	public void setProsecnaOcena(double prosecnaOcena) {
		this.prosecnaOcena = prosecnaOcena;
	}
	/**
	 *
	 * @return  Metoda koja vraca listu polozenih ispita Studenta
	 */
	public ArrayList<Ocena> getSpisakPolozenihIspita() {
		
		return spisakPolozenihIspita;
	}
	public void setSpisakPolozenihIspita(ArrayList<Ocena> spisakPolozenihIspita) {
		
		this.spisakPolozenihIspita = spisakPolozenihIspita;
	}
	/**
	 * Motoda koja izracunava prosjecnu ocjenu studenta na osnovu spisku polozenih
	 * ispita tog studenta
	 * @param spisakPolozenihIspita - spisak ispita koje je student polozio
	 * @return prosjecnu ocjenu 
	 */
	private double setProsecnaOcenaFunction(ArrayList<Ocena> spisakPolozenihIspita) {
		double s=0;
		double br=0;
		double avg=0;
		for(Ocena o: spisakPolozenihIspita) {
			s+=o.getVijrednostOceneToInt(o.getVijrednostOcene());
			br++;
		}
		if(br>0) {
		avg=s/br;
		
		this.prosecnaOcena=avg;
		return avg;
		}
		return 0;
	}

	public ArrayList<Predmet> getSpisakNepolozenihIspita() {
		return spisakNepolozenihIspita;
	}
	public void setSpisakNepolozenihIspita(ArrayList<Predmet> spisakNepolozenihIspita) {
		
		this.spisakNepolozenihIspita = spisakNepolozenihIspita;
	}

	@Override
	public String toString() {
		return "Student [prezime=" + prezime + ", ime=" + ime + ", datumRodjenja=" + datumRodjenja + ", adresa="
				+ adresa + ", kontaktTelefon=" + kontaktTelefon + ", eMail=" + eMail + ", brIndeksa=" + brIndeksa
				+ ", godinaUpisa=" + godinaUpisa + ", trenutnaGodinaStudija=" + trenutnaGodinaStudija + ", status="
				+ status + ", prosecnaOcena=" + prosecnaOcena + "]";
		}
	/**
	 * Metoda koja racuna broj espb bodova na osnovu liste
	 * polozenih ispita
	 * @param s entitet Student
	 * @return espb bodova
	 */
	public int getEspb(Student s) {
		ArrayList<Ocena> polozeni= s.getSpisakPolozenihIspita();
		int espb=0;
		for(Ocena o: polozeni ) {
			espb+=o.getPredmet().getBrESPBbodova();
		}
		
		return espb;
	}
	/**
	 * 
	 * @param spisakPredmetaDaPolaze spisak predmeta koje student moze da polaze
	 */
	public void setSpisakPredmetaDaPolaze(ArrayList<Predmet> spisakPredmetaDaPolaze) {
		
		this.spisakPredmetaDaPolaze = spisakPredmetaDaPolaze;
	}

	public ArrayList<Predmet> getSpisakPredmetaDaPolaze() {
		
	
			return spisakPredmetaDaPolaze;	
		
		
	}
	
	public double getProsecnaOcenaO() {
		return this.prosecnaOcena;
	}
	
	
	
}
