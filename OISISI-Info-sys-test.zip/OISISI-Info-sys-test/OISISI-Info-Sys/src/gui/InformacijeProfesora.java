package gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.management.remote.TargetedNotification;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import controller.ProfesoriController;
import model.Profesor;
import model.Profesor.Titula;
import model.Profesor.Zvanje;
import pop.dialogs.EditProfesorDialog;

public class InformacijeProfesora extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	JLabel labelaIme;
	JLabel labelaPrezime;
	JLabel labelaDatumRodjenja;
	JLabel labelaAdresaStanovanja;
	JLabel labelaBrojTelefona;
	JLabel labelaEmail;
	JLabel labelaAdresaKancelarije;
	JLabel labelaBrLicneKarte;
	JLabel labelaTitula;
	JLabel labelaZvanje;
	
	JTextField poljeIme;
	JTextField poljePrezime;
	JTextField poljeDatumRodjenja;
	JTextField poljeAdresaStanovanja;
	JTextField poljeBrojTelefona;
	JTextField poljeEmail;
	JTextField poljeAdresaKancelarije;
	JTextField poljeBrLicneKarte;
	JComboBox<Titula> comboBoxTitula;
	JComboBox<Zvanje> comboBoxZvanje;
	
	public InformacijeProfesora(Profesor profesor) {
		
		Profesor originalniProfesor = profesor;

		setName("Izmjena profesora");
		labelaIme = new JLabel("Ime*");
		labelaPrezime = new JLabel("Prezime*");
		labelaDatumRodjenja = new JLabel("Datum rodjenja(dd.MM.yyyy.)*");
		labelaAdresaStanovanja = new JLabel("Adresa stanovanja*");
		labelaBrojTelefona = new JLabel("Broj telefona*");
		labelaEmail = new JLabel("Email*");
		labelaAdresaKancelarije = new JLabel("Adresa Kancelarije:");
		labelaBrLicneKarte = new JLabel("Broj licne karte*");
		labelaTitula = new JLabel("Titula*");
		labelaZvanje = new JLabel("Zvanje*");
		
		
		//INICIJALIZOVATI LISTENERE
		//keyListener1 = new KeyListener();
		//...
				
		poljeIme = new JTextField(15);
		poljeIme.setName("Ime");
		poljeIme.setText(originalniProfesor.getIme());
		//poljeIme.addKeyListener1();
				
		poljePrezime = new JTextField(15);
		poljePrezime.setName("Prezime");
		poljePrezime.setText(originalniProfesor.getPrezime());
		//poljeIme.addKeyListener();
				
		poljeDatumRodjenja = new JTextField(15);
		poljeDatumRodjenja.setName("Datum rodjenja(dd-MM-yyyy)");
		//String strDate = spremiString(originalniProfesor.getDatumRodj());
		//poljeDatumRodjenja.setText(strDate);
		//poljeIme.addKeyListener();
				
		poljeAdresaStanovanja = new JTextField(15);
		poljeAdresaStanovanja.setName("Adresa stanovanja");
		poljeAdresaStanovanja.setText(originalniProfesor.getAdresaStanovanja());
		//poljeIme.addKeyListener();
				
		poljeBrojTelefona = new JTextField(15);
		poljeBrojTelefona.setName("Broj telefona");
		poljeBrojTelefona.setText(originalniProfesor.getTelefon());
		//poljeIme.addKeyListener();
				
		poljeEmail = new JTextField(15);
		poljeEmail.setName("Email");
		poljeEmail.setText(originalniProfesor.getMail());
		//poljeIme.addKeyListener();
				
		poljeAdresaKancelarije = new JTextField(15);
		poljeAdresaKancelarije.setName("Adresa kancelarije");
		poljeAdresaKancelarije.setText(originalniProfesor.getAdresaKancelarije());
		//poljeIme.addKeyListener();
				
		poljeBrLicneKarte = new JTextField(15);
		poljeBrLicneKarte.setName("Broj licne karte");
		poljeBrLicneKarte.setText(originalniProfesor.getBrLicneKarte());
		//poljeIme.addKeyListener();
				
		comboBoxTitula = new JComboBox<>();
		comboBoxTitula.setName("Titula");
		DefaultComboBoxModel<Titula> t = new DefaultComboBoxModel<Titula>();
		t.addElement(Titula.dipl);
		t.addElement(Titula.mr);
		t.addElement(Titula.dr);
		comboBoxTitula.setModel(t);
		comboBoxTitula.setSelectedIndex(0);
		comboBoxTitula.setEditable(false);
		comboBoxTitula.setSelectedItem(originalniProfesor.getTitula());
		//add listner
				
		comboBoxZvanje =  new JComboBox<>();
		comboBoxZvanje.setName("Zvanje");
		DefaultComboBoxModel<Zvanje> Model = new DefaultComboBoxModel<Zvanje>();
		Model.addElement(Zvanje.Saradnik_u_nastavi);
		Model.addElement(Zvanje.Asistent);
		Model.addElement(Zvanje.Asistent_sa_doktoratom);
		Model.addElement(Zvanje.Docent);
		Model.addElement(Zvanje.Vanredni_profesor);
		Model.addElement(Zvanje.Redovni_profesor);
		Model.addElement(Zvanje.Profesor_emeritus);
		comboBoxZvanje.setModel(Model);
		comboBoxZvanje.setSelectedIndex(0);
		comboBoxZvanje.setEditable(false);
		comboBoxZvanje.setSelectedItem(originalniProfesor.getZvanje());
				
		
		//listener
				
		JButton btnOK = new JButton("Potvrda");
		JButton btnCancel = new JButton("Odustani");
				
				
		Window parent = SwingUtilities.getWindowAncestor(this);
		btnOK.addActionListener(new ActionListener() {
					
					
					
		@Override
		public void actionPerformed(ActionEvent e) {
		Profesor izmenjenProfesor;
					
		try {
			izmenjenProfesor = collectData();
								
			if(izmenjenProfesor == null) {
								
			JOptionPane.showMessageDialog(parent, "Morate  popuniti sva polja!");
			btnOK.setToolTipText("Morate uneti sva polja!");
									
			}else {
			//VIDJETI DA LI TREBA I PROVJERA ZA LICNU KARTU.....
			//OVDJE GRESKA FALI TI ID STAROG PROFESORA DA BI GA NASLA U izmjeniProfesor
			//nastavak komentara u izmjeniProfesor
			if(!originalniProfesor.getBrLicneKarte().equals(izmenjenProfesor.getBrLicneKarte())) {
					if(ProfesoriController.getInstance().uniqueBrLicneKarte(izmenjenProfesor)) {
						ProfesoriController.getInstance().izmjeniProfesora(izmenjenProfesor);
						SwingUtilities.getWindowAncestor(btnOK).dispose();
					}else {
						btnOK.setToolTipText(" Broj licne karte nije jedinstven!");
						JOptionPane.showMessageDialog(parent, "Broj licne karte nije jedinstven!");
					}
				}else {
					ProfesoriController.getInstance().izmjeniProfesora(izmenjenProfesor);
					//SwingUtilities.getWindowAncestor(btnOK).dispose();
					//sa ovim zakuca nakon licne karte koja nije jedinstvena
					//SwingUtilities.getRoot(btnCancel).setVisible(false);
					//i sa ovim zakuca na istom mjestu....
					
				}
										
			}
		}catch(ParseException pe) {
			pe.printStackTrace();
		}				
	}});
				
		btnCancel.addActionListener(new ActionListener() {
					
			@Override
			public void actionPerformed(ActionEvent e) {
				//dispose();
				//kako da zatvorim dialog odavde?
				SwingUtilities.getWindowAncestor(btnCancel).dispose();
				
			}
			});
				
		btnOK.setEnabled(false);		
		FocusListener fl1 = new FocusListener() {
					
			@Override
			public void focusLost(FocusEvent e) {
						// TODO Auto-generated method stub
						
			}
					
			@Override
			public void focusGained(FocusEvent e) {
				if(!(poljeAdresaKancelarije.getText().isEmpty() || poljeAdresaStanovanja.getText().isEmpty() 
					|| poljeBrLicneKarte.getText().isEmpty() || poljeBrojTelefona.getText().isEmpty() 
					|| poljeDatumRodjenja.getText().isEmpty() || poljeEmail.getText().isEmpty()
					|| poljeIme.getText().isEmpty() || poljePrezime.getText().isEmpty())) {
				btnOK.setEnabled(true);
			}
						
		}
		};
		btnOK.setEnabled(false);		
		poljeAdresaKancelarije.addFocusListener(fl1);
		poljeAdresaStanovanja.addFocusListener(fl1);
		poljeBrLicneKarte.addFocusListener(fl1);
		poljeBrojTelefona.addFocusListener(fl1);
		poljeDatumRodjenja.addFocusListener(fl1);
		poljeEmail.addFocusListener(fl1);
		poljeIme.addFocusListener(fl1);
		poljePrezime.addFocusListener(fl1);
				
		layout(btnOK, btnCancel);	
			
	}
	
	private void layout(JButton btnOK,JButton btnCancel) {
		
		setLayout(new GridBagLayout());
		
		GridBagConstraints gc  = new GridBagConstraints();
		
		
		gc.weightx=0.01;
		gc.weighty=0.01;
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(20, 20, 0, 0);
		gc.anchor=GridBagConstraints.LINE_START;
		add(labelaIme, gc);
		
		//GridBagConstraints gc1 = new GridBagConstraints(1,0,2,1,0.0,0.0,GridBagConstraints.LINE_START,0,new Insets(20, 20, 0, 0),0,0);
		//add(poljeIme,gc1);
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridwidth=2;
		gc.fill=GridBagConstraints.BOTH;
		gc.anchor=GridBagConstraints.LINE_START;
		add(poljeIme, gc);
		
		//--------------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		gc.gridwidth=1;
		gc.gridy = 1;
		gc.gridx = 0;
		gc.insets = new Insets(20, 20, 0, 0);
		gc.anchor = GridBagConstraints.LINE_START;
		add(labelaPrezime,gc);
		

		gc.gridy = 1;
		gc.gridx = 1;
		gc.gridwidth=2;
		gc.anchor = GridBagConstraints.LINE_START;
		add(poljePrezime, gc);
		//----------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		gc.gridy = 2;
		gc.gridx = 0;
		gc.gridwidth=1;
		gc.insets = new Insets(20, 20, 0, 0);
		gc.anchor=GridBagConstraints.LINE_START;
		add(labelaDatumRodjenja,gc);
		

		gc.gridy = 2;
		gc.gridx = 1;
		gc.gridwidth=2;
		gc.anchor=GridBagConstraints.LINE_START;
		add(poljeDatumRodjenja,gc);
		
		//------------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		gc.gridy = 3;
		gc.gridx = 0;
		gc.gridwidth=1;
		gc.insets = new Insets(20, 20, 0, 0);
		gc.anchor=GridBagConstraints.LINE_START;
		add(labelaAdresaStanovanja,gc);
		

		gc.gridy = 3;
		gc.gridx = 1;
		gc.gridwidth=2;
		gc.anchor=GridBagConstraints.LINE_START;
		add(poljeAdresaStanovanja,gc);
		//----------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		gc.gridy = 4;
		gc.gridx = 0;
		gc.gridwidth=1;
		gc.insets = new Insets(20, 20, 0, 0);
		gc.anchor=GridBagConstraints.LINE_START;
		add(labelaBrojTelefona,gc);
		

		gc.gridy = 4;
		gc.gridx = 1;
		gc.gridwidth=2;
		gc.anchor=GridBagConstraints.LINE_START;
		add(poljeBrojTelefona,gc);
		//-----------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		gc.gridy = 5;
		gc.gridx = 0;
		gc.gridwidth=1;
		gc.insets = new Insets(20, 20, 0, 0);
		gc.anchor=GridBagConstraints.LINE_START;
		add(labelaEmail,gc);
		
		gc.gridy = 5;
		gc.gridx = 1;
		gc.gridwidth=2;
		gc.anchor=GridBagConstraints.LINE_START;
		add(poljeEmail,gc);
		
		//--------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		gc.gridy = 6;
		gc.gridx = 0;
		gc.gridwidth=1;
		gc.anchor=GridBagConstraints.LINE_START;
		add(labelaAdresaKancelarije,gc);
		

		gc.gridy = 6;
		gc.gridx = 1;	
		gc.gridwidth=2;
		gc.anchor=GridBagConstraints.LINE_START;
		add(poljeAdresaKancelarije,gc);
		
		
		
		//---------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		gc.gridy = 7;
		gc.gridx = 0;
		gc.gridwidth=1;
		gc.anchor=GridBagConstraints.LINE_START;
		add(labelaBrLicneKarte,gc);
		

		gc.gridy = 7;
		gc.gridx = 1;
		gc.gridwidth=2;
		gc.anchor=GridBagConstraints.LINE_START;
		add(poljeBrLicneKarte,gc);
		//---------------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		gc.gridy = 8;
		gc.gridx = 0;
		gc.gridwidth=1;
		gc.anchor=GridBagConstraints.LINE_START;
		add(labelaTitula,gc);
		

		gc.gridy = 8;
		gc.gridx = 1;	
		gc.anchor=GridBagConstraints.LINE_START;
		add(comboBoxTitula,gc);
		//--------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		gc.gridy = 9;
		gc.gridx = 0;
		gc.anchor=GridBagConstraints.LINE_START;
		add(labelaZvanje,gc);
		

		gc.gridy = 9;
		gc.gridx = 1;	
		gc.anchor=GridBagConstraints.LINE_START;
		add(comboBoxZvanje,gc);
		//---------------
		gc.gridy = 10;
		gc.gridx = 2;
		gc.insets = new Insets(20, 20, 20, 20);
		gc.fill=GridBagConstraints.NONE;
		gc.anchor=GridBagConstraints.SOUTHEAST;
		add(btnOK,gc);
				
		gc.gridy = 10;
		gc.gridx = 3;
		gc.anchor=GridBagConstraints.SOUTHWEST;
		add(btnCancel,gc);	
		
	}


	
	private Profesor collectData() throws ParseException {
		
		Profesor prof;
		prof = null;
		try {
		String prezime1 = poljePrezime.getText();
		String ime1 = poljeIme.getText();
		Date datumRodj1 = spremiDatum(poljeDatumRodjenja.getText());
		String adresaStanovanja1 = poljeAdresaStanovanja.getText();
		String telefon1 = poljeBrojTelefona.getText();
		String mail1 = poljeEmail.getText();
		String adresaKancelarije1 = poljeAdresaKancelarije.getText();
		String brLicneKarte1 = poljeBrLicneKarte.getText();
		
		Titula titula1 = (Titula) comboBoxTitula.getSelectedItem() ;
		Zvanje zvanje1 = (Zvanje) comboBoxZvanje.getSelectedItem() ;
		
		
		
		if(ime1.equals("") || prezime1.equals("") || 
				datumRodj1.equals(null) ||
				adresaStanovanja1.equals("") || telefon1.equals("") || 
				mail1.equals("") || adresaKancelarije1.equals("") || brLicneKarte1.equals("")
				|| titula1.equals(null) || zvanje1.equals(null)) {
			return null;
		}
		
		prof = new Profesor(prezime1, ime1, datumRodj1, adresaStanovanja1, telefon1, mail1, adresaKancelarije1, brLicneKarte1, titula1, zvanje1);
		
				
		}catch (Exception e) {
			e.printStackTrace();
		}
		return prof;
	}
	
	public Date spremiDatum(String date)  {
		
		Date datum = null;
		try {
		String pattern = "dd.MM.yyyy.";
		SimpleDateFormat simpleDatedFormat = new SimpleDateFormat(pattern);
		  datum =  simpleDatedFormat.parse(date);
		}catch(ParseException e) {
			e.printStackTrace();
			return null;
		}
		return datum;
	}
	
	public String spremiString(Date date)  {
			
			String pattern = "dd.MM.yyyy.";
			DateFormat simpleDatedFormat = new SimpleDateFormat(pattern);
			 String datum =  simpleDatedFormat.format(date);
			return datum;
		}
}
