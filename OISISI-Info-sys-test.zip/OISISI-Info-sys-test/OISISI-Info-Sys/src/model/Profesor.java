package model;
import java.util.ArrayList;
import java.util.Date;

public class Profesor {

	public enum Titula{dipl,mr,dr};
	public enum Zvanje{Saradnik_u_nastavi,Asistent,Asistent_sa_doktoratom,Docent,Vanredni_profesor,Redovni_profesor,Profesor_emeritus};
	private String prezime;
	private String ime;
	private Date datumRodj;
	private String adresaStanovanja;
	private String telefon;
	private String mail;
	private String adresaKancelarije;
	private String brLicneKarte;
	private Titula titula;
	private Zvanje zvanje;
	private ArrayList<Predmet> predmetiNaKojimJeProfesor;
	//novo obelezje...lista predmeta koje moze da polaze
	private ArrayList<Predmet> moguciPredmeti;

	
	public ArrayList<Predmet> getMoguciPredmeti() {
		return moguciPredmeti;
	}
	public void setMoguciPredmeti(ArrayList<Predmet> moguciPredmeti) {
		this.moguciPredmeti = moguciPredmeti;
	}
	public Profesor(String prezime, String ime, Date datumRodj, String adresaStanovanja, String telefon, String mail,
			String adresaKancelarije, String brLicneKarte, Titula titula, Zvanje zvanje) {
		super();
		this.prezime = prezime;
		this.ime = ime;
		this.datumRodj = datumRodj;
		this.adresaStanovanja = adresaStanovanja;
		this.telefon = telefon;
		this.mail = mail;
		this.adresaKancelarije = adresaKancelarije;
		this.brLicneKarte = brLicneKarte;
		this.titula = titula;
		this.zvanje = zvanje;
		this.predmetiNaKojimJeProfesor =new ArrayList<Predmet>();
		//ovde listi treba dodadati sve predmete koji postje a na kojima prof ne predaje
		//znaci napraviiti neku metodu za to 
		this.moguciPredmeti =new ArrayList<Predmet>();
	}
	public Profesor(String prezime, String ime, String adresaStanovanja, String telefon, String mail,
			String adresaKancelarije, String brLicneKarte, Titula titula, Zvanje zvanje) {
		super();
		this.prezime = prezime;
		this.ime = ime;
		//this.datumRodj = null;
		this.adresaStanovanja = adresaStanovanja;
		this.telefon = telefon;
		this.mail = mail;
		this.adresaKancelarije = adresaKancelarije;
		this.brLicneKarte = brLicneKarte;
		this.titula = titula;
		this.zvanje = zvanje;
		this.predmetiNaKojimJeProfesor =new ArrayList<Predmet>();
		//ovde listi treba dodadati sve predmete koji postje a na kojima prof ne predaje
				//znaci napraviiti neku metodu za to 
		this.moguciPredmeti =new ArrayList<Predmet>();
	}
	
	public Profesor(Profesor profesor) {
		super();
		this.prezime = profesor.getPrezime();
		this.ime = profesor.getIme();
		this.datumRodj = profesor.getDatumRodj();
		this.adresaStanovanja = profesor.getAdresaStanovanja();
		this.telefon = profesor.getTelefon();
		this.mail = profesor.getMail();
		this.adresaKancelarije = profesor.getAdresaKancelarije();
		this.brLicneKarte = profesor.getBrLicneKarte();
		this.titula = profesor.getTitula();
		this.zvanje = profesor.getZvanje();
		this.predmetiNaKojimJeProfesor = profesor.getPredmetiNaKojimJeProfesor();
	}
	
	public String getPrezime() {
		return prezime;
	}
	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}
	public String getIme() {
		return ime;
	}
	public void setIme(String ime) {
		this.ime = ime;
	}
	public Date getDatumRodj() {
		return datumRodj;
	}
	public void setDatumRodj(Date datumRodj) {
		this.datumRodj = datumRodj;
	}
	public String getAdresaStanovanja() {
		return adresaStanovanja;
	}
	public void setAdresaStanovanja(String adresaStanovanja) {
		this.adresaStanovanja = adresaStanovanja;
	}
	public String getTelefon() {
		return telefon;
	}
	public void setTelefon(String telefon) {
		this.telefon = telefon;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getAdresaKancelarije() {
		return adresaKancelarije;
	}
	public void setAdresaKancelarije(String adresaKancelarije) {
		this.adresaKancelarije = adresaKancelarije;
	}
	public String getBrLicneKarte() {
		return brLicneKarte;
	}
	public void setBrLicneKarte(String brLicneKarte) {
		this.brLicneKarte = brLicneKarte;
	}
	public Titula getTitula() {
		return titula;
	}
	public void setTitula(Titula titula) {
		this.titula = titula;
	}
	public Zvanje getZvanje() {
		return zvanje;
	}
	public void setZvanje(Zvanje zvanje) {
		this.zvanje = zvanje;
	}
	public ArrayList<Predmet> getPredmetiNaKojimJeProfesor() {
		return predmetiNaKojimJeProfesor;
	}
	public void setPredmetiNaKojimJeProfesor(ArrayList<Predmet> predmetiNaKojimJeProfesor) {
		this.predmetiNaKojimJeProfesor = predmetiNaKojimJeProfesor;
	}
	@Override
	public String toString() {
		return "Profesor [prezime=" + prezime + ", ime=" + ime + ", datumRodj=" + datumRodj + ", adresaStanovanja="
				+ adresaStanovanja + ", telefon=" + telefon + ", mail=" + mail + ", adresaKancelarije="
				+ adresaKancelarije + ", brLicneKarte=" + brLicneKarte + ", tutula=" + titula + ", zvanje=" + zvanje
				+ ", predmetiNaKojimJeProfesor=" + predmetiNaKojimJeProfesor + "]";
	}
	
	public String osnovniPodaci() {
		return "Profesor:" + ime + " " + prezime ;
	}
	
	
	
}
