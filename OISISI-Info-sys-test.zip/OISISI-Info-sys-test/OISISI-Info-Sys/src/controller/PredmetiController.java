package controller;

import java.util.ArrayList;

import gui.MainFrame;
import model.BazaPredmeta;
import model.BazaProfesora;
import model.Predmet;
import model.Profesor;


public class PredmetiController {


	private static PredmetiController instance = null;
	
	public static PredmetiController getInstance() {
		if(instance == null) {
			instance = new PredmetiController();
		}
		return instance;
	}
	
	private PredmetiController() {	}
	
	public void dodajPredmet(Predmet predmet) {
		
		//Izborom odgovarajućeg predmeta i klikom na dugme Dodaj , dodaje se novi predmet u tabelu
		//nepoloženih predmeta, koju je ovom prilikom potrebno ažurirati.
		BazaPredmeta.getInstance().dodajPredmet(predmet);
		MainFrame.getInstance().azurirajPrikazPredmet("DODAT PREDMET", -1);
		StudentiController.getInstance().azurirajListuPredmeta(predmet);
		
	}
	
	public boolean uniqueSifraPredmeta(Predmet predmet) {
		return BazaPredmeta.getInstance().uniqueSifraPredmeta(predmet.getSifraPredmeta());
	}
	public void updatePredmet(String sifra, Predmet p) {

	BazaPredmeta.getInstance().izmeniPredmet(sifra, p.getSifraPredmeta(),p.getNazivPredmeta(),p.getSemestar(),p.getGodinaStudija(),p.getPredmetniProfesor(),p.getBrESPBbodova());
	MainFrame.getInstance().azurirajPrikazPredmet(null, -1);	
	}

	public void izbrisiPredmet(Predmet p) {

		BazaPredmeta.getInstance().izbrisPredmet(p.getSifraPredmeta());
		MainFrame.getInstance().azurirajPrikazPredmet("OBRISAN PREDMET", -1);
		//samo azuriram studenta
		StudentiController.getInstance().izbristiPredmet(p);
		
	}

	public void dodajProfesoraNaPredmet(Predmet pr, int selectedIndex) {

		Profesor p=BazaProfesora.getInstance().getProfesori().get(selectedIndex);
		BazaPredmeta.getInstance().dodajProfesoraNaPredmet(pr,p);
		
		MainFrame.getInstance().azurirajPrikazPredmet(null, 0);
		
		
		
	}

	public void obrisiProfesoraSaPredmeta(Profesor profesor) {
		// TODO Auto-generated method stub
		BazaPredmeta.getInstance().obrisiProfesoraSaPredmeta(profesor);
		MainFrame.getInstance().azurirajPrikazPredmet(null, 0);
	}
	
	public ArrayList<Predmet> vratiSvePredmete(){
		
		return (ArrayList<Predmet>) BazaPredmeta.getInstance().getPredmeti();
	}
	
	public void dodajProfesoraPredmetu(Profesor p ,Predmet predmet) {
		BazaPredmeta.getInstance().dodajProfesoraPredmetu(p,predmet);
	}
	
	public void ukloniProfesoraSaPredmeta(Profesor p ,Predmet predmet) {
		BazaPredmeta.getInstance().ukloniProfesoraSaPredmet(p,predmet);
	}
}
