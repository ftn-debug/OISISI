package pop.dialogs;

import java.awt.FlowLayout;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JList;

public class ProfesorJList extends JDialog {

	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProfesorJList() {
		// set flow layout for the frame
        this.getContentPane().setLayout(new FlowLayout());
 
       
	}
	
	
	
}
