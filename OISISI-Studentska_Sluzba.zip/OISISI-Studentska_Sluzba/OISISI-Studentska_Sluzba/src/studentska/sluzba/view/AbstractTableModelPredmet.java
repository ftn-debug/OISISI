package studentska.sluzba.view;



import javax.swing.table.AbstractTableModel;

import studentska.sluzba.model.BazaPredmeta;


public class AbstractTableModelPredmet extends AbstractTableModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public AbstractTableModelPredmet() {
		
		
	}

	@Override
	public int getRowCount() {
		return BazaPredmeta.getInstance().getPredmeti().size();
				
	}

	@Override
	public int getColumnCount() {
		return BazaPredmeta.getInstance().getColumnCount();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return BazaPredmeta.getInstance().getValueAt(rowIndex, columnIndex);
	}
	@Override
	public String getColumnName(int index) {
		return BazaPredmeta.getInstance().getColumnName(index);
	}
	
}
