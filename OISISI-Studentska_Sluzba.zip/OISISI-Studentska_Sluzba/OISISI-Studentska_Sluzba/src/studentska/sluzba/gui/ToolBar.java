package studentska.sluzba.gui;


import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.RowFilter;
import javax.swing.SwingConstants;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;



public class ToolBar extends JToolBar {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public TableRowSorter<TableModel> rowSorter =null;

	public ToolBar() {
		
		super(SwingConstants.HORIZONTAL);	
		ActionNew an = new ActionNew();
		ActionEdit ae = new ActionEdit();
		ActionDelete ad = new ActionDelete();
		ActionSearch as = new ActionSearch();
		TextFieldListener tl = new TextFieldListener();
		
		JPanel boxPan = new JPanel();
		boxPan.setLayout(new BoxLayout(boxPan, BoxLayout.X_AXIS));
		
		//NEW
		JButton btnNew = new JButton(an);
		boxPan.add(btnNew);
				
		//EDIT 	
		JButton btnEdit = new JButton(ae);
		boxPan.add(btnEdit);
		
		//DELETE
		JButton btnDelete = new JButton(ad);
		boxPan.add(btnDelete);
		
		boxPan.add(Box.createHorizontalStrut(500));
	
		boxPan.add(Box.createHorizontalGlue());
		
		JTextField textF = new JTextField();
		textF.setPreferredSize(new Dimension(100,20));	
		textF.addKeyListener(tl);
		boxPan.add(textF);
		
		boxPan.add(Box.createHorizontalStrut(5));
		
		//SEARCH		
		JButton btnSearch = new JButton(as);
		boxPan.add(btnSearch);
		
btnSearch.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
			
					switch(MainFrame.getInstance().selectedTab()) {
					//ovdje se selektovan tab
					//search u tabeli studenata
					case 0:
						 rowSorter = new TableRowSorter<>(MainFrame.getInstance().getTabelaStudenti().getModel());
						MainFrame.getInstance().getTabelaStudenti().setRowSorter(rowSorter);
					//	System.out.print("searchText lenght:"+ searchText.length);

						String[] searchText = textF.getText().split("\\s+");
						if( searchText.length==0) {
							 rowSorter.setRowFilter(null);
						}
						
						if(searchText.length == 1) {
							
							  
							rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText[0],2));
						
						}
						if(searchText.length == 2) {
							java.util.List<RowFilter<Object,Object>> filters = new ArrayList<RowFilter<Object,Object>>(2);
							
							filters.add(RowFilter.regexFilter("(?i)" + searchText[0],2));
							filters.add(RowFilter.regexFilter("(?i)" + searchText[1],1));
							
							RowFilter<Object,Object> andFilters = RowFilter.andFilter(filters);
							rowSorter.setRowFilter(andFilters);
							
						
					}
						if(searchText.length == 3) {
							java.util.List<RowFilter<Object,Object>> filters = new ArrayList<RowFilter<Object,Object>>(3);
							filters.add(RowFilter.regexFilter("(?i)" + searchText[0],2));
							filters.add(RowFilter.regexFilter("(?i)" + searchText[1],1));
							filters.add(RowFilter.regexFilter("(?i)" + searchText[2],0));
							
							RowFilter<Object,Object> andFilters = RowFilter.andFilter(filters);
							rowSorter.setRowFilter(andFilters);
					}
						
						if(searchText.length > 3) {
							JOptionPane.showMessageDialog(null,
									"ERROR: Netacan upit! Upit treba da izgleda : PREZIME* IME INDEKS ",
									"Greska", JOptionPane.ERROR_MESSAGE);
							return;
					}
						
						break;
					//search u tabeli profesora
					case 1:
						
						
						
						
						break;
					//search u tabeli predmeta
					case 2:
						
						
						break;
					default:
							break;
							
					}
					
					
				
			}});
		
		
		
		
		
		
		
		
		
		
		
		
		
		setFloatable(false);
		add(boxPan);
		
		
		
		
		
	}
}
