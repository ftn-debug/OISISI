package pop.dialogs;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

import controller.ProfesoriController;
import gui.MainFrame;
import model.BazaProfesora;
import model.Profesor;



public class DeleteProfesorDialog extends JDialog  implements ActionListener{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DeleteProfesorDialog(Profesor p) {
		
	/*	Object[] options = {"Da",
                "Ne"};
		final JOptionPane optionPane = new JOptionPane(
			    "Da li ste sigurni da �elite da \n "
			    + "obri�ete profesora?",
			    JOptionPane.QUESTION_MESSAGE,
			    JOptionPane.YES_NO_OPTION,
			    null,
			    options,
			    options[1]);
		*/
		Object[] options = { "Da", "Ne" };
		//JOptionPane optionPane = new JOptionPane();
		int opcija = JOptionPane.showOptionDialog(null,"Da li ste sigurni da želite da \n "
			    + "obrišete profesora?", "Brisanje profesora",
		    JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
		    null, options, options[1]);
		
		if(opcija == JOptionPane.YES_OPTION) {
			
			ProfesoriController.getInstance().izbrisiProfesora(p);
			MainFrame.getInstance().azurirajPrikazProfesora("OBRISAN PROFESOR", -1);
		}
		
		
		
		
	
		setSize(new Dimension(250,150));
		setResizable(false);
		setModal(true);
		setLocationRelativeTo(MainFrame.getInstance());
		//setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
		
		//setVisible(true);
		
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	

}
