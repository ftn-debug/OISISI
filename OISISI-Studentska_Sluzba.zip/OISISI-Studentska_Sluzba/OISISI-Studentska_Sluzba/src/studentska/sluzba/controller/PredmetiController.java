package studentska.sluzba.controller;

import java.util.ArrayList;

import studentska.sluzba.gui.MainFrame;
import studentska.sluzba.model.BazaPredmeta;
import studentska.sluzba.model.BazaProfesora;
import studentska.sluzba.model.Predmet;
import studentska.sluzba.model.Profesor;

public class PredmetiController {
private static PredmetiController instance = null;
	
	public static PredmetiController getInstance() {
		if(instance == null) {
			instance = new PredmetiController();
		}
		return instance;
	}

	private PredmetiController() {	}


public void dodajPredmet(Predmet predmet) {
		

	//Izborom odgovarajućeg predmeta i klikom na dugme Dodaj , dodaje se novi predmet u tabelu
	//nepoloženih predmeta, koju je ovom prilikom potrebno ažurirati.	
		BazaPredmeta.getInstance().dodajPredmetEntity(predmet);
		MainFrame.getInstance().azurirajPrikazPredmet("DODAT PREDMET", -1);
		StudentiController.getInstance().azurirajListuPredmeta(predmet);
		
	}

public boolean uniqueSifraPredmeta(Predmet predmet) {

	return BazaPredmeta.getInstance().uniqueSifraPredmeta(predmet.getSifraPredmeta());
}


public void izbrisiPredmet(Predmet p) {

	BazaPredmeta.getInstance().izbrisPredmet(p.getSifraPredmeta());
	//A mozemo ga brisati i iz lista studenata koji jesu/nisu polozili predmet
	//ali ne znam da li to da radim
	//to se nigdje ne prikazuje i nije pomenuto u specifikaciji
	MainFrame.getInstance().azurirajPrikazPredmet("OBRISAN PREDMET", -1);
	//samo azuriram studenta
	StudentiController.getInstance().izbristiPredmet(p);
	
}

public void updatePredmet(String sifraPredmeta, Predmet p) {

	
	BazaPredmeta.getInstance().izmeniPredmet(sifraPredmeta,p.getSifraPredmeta(),p.getNazivPredmeta(),p.getSemestar(),p.getGodinaStudija(),p.getPredmetniProfesor(),p.getBrESPBbodova());
	MainFrame.getInstance().azurirajPrikazPredmet(null, -1);	
}

public void obrisiProfesoraSaPredmeta(Profesor p) {

	BazaPredmeta.getInstance().obrisiProfesoraSaPredmeta(p);
	MainFrame.getInstance().azurirajPrikazPredmet(null, 0);
}


public void dodajProfesoraPredmetu(Profesor p ,Predmet predmet) {
	BazaPredmeta.getInstance().dodajProfesoraPredmetu(p,predmet);
}



public ArrayList<Predmet> vratiSvePredmete(){
	
	return (ArrayList<Predmet>) BazaPredmeta.getInstance().getPredmeti();
}

public void dodajProfesoraNaPredmet(Predmet pr, int selectedIndex) {

	Profesor p= BazaProfesora.getInstance().getProfesori().get(selectedIndex);
	BazaPredmeta.getInstance().dodajProfesoraNaPredmet(pr,p);
	
	MainFrame.getInstance().azurirajPrikazPredmet(null, 0);
	
	
}


}
