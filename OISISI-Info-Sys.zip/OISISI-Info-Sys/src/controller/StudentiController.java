package controller;

import gui.MainFrame;
import model.BazaStudenata;
import model.Student;

public class StudentiController {
	
	private static StudentiController instance=null;
	
	public static StudentiController getInstance() {
		
		if(instance == null ) {
			instance= new StudentiController();
		}
		return instance;
		
	}
	private StudentiController() {}
	public void dodajStudenta(Student entity) {
		BazaStudenata.getInstance().dodajStudenta(entity);
		MainFrame.getInstance().azurirajPrikazStudenta("DODAT", -1);
	}
	
	
	
	
	

}
