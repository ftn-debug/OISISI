package studentska.sluzba.model;

import java.util.Date;

public class Ocena {

	public enum vOcjene{ pet ,sest,sedam,osam,devet,deset};
	//save for later
	/*public enum vOcene {
		pet(5),sest(6),sedam(7),osam(8),devet(9),deset(10);
		private final int o;
		vOcene(int o){this.o=o;}
		public int getValue() {return o;}
	}
	*/
	
	private Student student;
	private Predmet predmet;
	private vOcjene vijrednostOcene;
	private Date datumPolaganja;
	
	
	public Ocena(Student student, Predmet predmet,vOcjene vijrednostOcene, Date datumPolaganja) {
		super();
		this.student = student;
		this.predmet = predmet;
		this.vijrednostOcene = vijrednostOcene;
		this.datumPolaganja = datumPolaganja;
	}
	public Ocena() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Predmet getPredmet() {
		return predmet;
	}
	public void setPredmet(Predmet predmet) {
		this.predmet = predmet;
	}
	public vOcjene getVijrednostOcene() {
		return vijrednostOcene;
	}
	public void setVijrednostOcene(vOcjene vijrednostOcene) {
		this.vijrednostOcene = vijrednostOcene;
	}
	public Date getDatumPolaganja() {
		return datumPolaganja;
	}
	public void setDatumPolaganja(Date datumPolaganja) {
		this.datumPolaganja = datumPolaganja;
	}
	@Override
	public String toString() {
		return "Ocena [student=" + student + ", predmet=" + predmet + ", vijrednostOcene=" + vijrednostOcene
				+ ", datumPolaganja=" + datumPolaganja + "]";
	}
	public double getVijrednostOceneToInt(vOcjene vijrednostOcene2) {
	
			
			if(	vijrednostOcene ==vOcjene.pet) {
				return 5;
			}
			else if(	vijrednostOcene ==vOcjene.sest) {
				return 6;
			}
			else if(	vijrednostOcene ==vOcjene.sedam) {
				return 7;
			}
			else if(	vijrednostOcene ==vOcjene.osam) {
				return 8;
			}
			else if(	vijrednostOcene ==vOcjene.devet) {
				return 9;
			}
			else if(	vijrednostOcene ==vOcjene.deset) {
				return 10;
			}else {
			return 0;
			}
		}
	
	
}
