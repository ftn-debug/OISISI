package studentska.sluzba.model;


import java.io.Serializable;
import java.util.ArrayList;


public class Predmet implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public enum Semestar{ZIMSKI,LETNJI};
    
    
	private String sifraPredmeta;
	private String nazivPredmeta;
	private Semestar semestar;
	private int godinaStudija; //na kojoj se predmet izvodi
	private Profesor predmetniProfesor;
	private int brESPBbodova;
	private ArrayList<Student> studentiPolozili;
	private ArrayList<Student> studentiNisuPolozili;
	
	public Predmet() {}
	public Predmet(String sifraPredmeta, String nazivPredmeta, Semestar semestar, int godinaStudija,
			Profesor predmetniProfesor, int brESPBbodova) {
		
		this.sifraPredmeta = sifraPredmeta;
		this.nazivPredmeta = nazivPredmeta;
		this.semestar = semestar;
		this.godinaStudija = godinaStudija;
		this.predmetniProfesor = predmetniProfesor;
		this.brESPBbodova = brESPBbodova;
		//this.studentiPolozili = studentiPolozili;
		//this.studentiNisuPolozili = studentiNisuPolozili;
	}
	
	
	public Predmet(String sifraPredmeta, String nazivPredmeta, Semestar semestar, int godinaStudija, int brESPBbodova) {
		
		this.sifraPredmeta = sifraPredmeta;
		this.nazivPredmeta = nazivPredmeta;
		this.semestar = semestar;
		this.godinaStudija = godinaStudija;
		this.brESPBbodova = brESPBbodova;
		studentiNisuPolozili = new ArrayList<Student>();
		studentiPolozili = new ArrayList<Student>();
	}
	
public Predmet(Predmet predmet) {
		
		this.sifraPredmeta = predmet.getSifraPredmeta();
		this.nazivPredmeta = predmet.getNazivPredmeta();
		this.semestar = predmet.getSemestar();
		this.godinaStudija = predmet.getGodinaStudija();
		this.brESPBbodova = predmet.getBrESPBbodova();
		studentiNisuPolozili = predmet.getStudentiNisuPolozili();
		studentiPolozili = predmet.getStudentiPolozili();
	}
	
	public String getSifraPredmeta() {
		return sifraPredmeta;
	}
	public void setSifraPredmeta(String sifraPredmeta) {
		this.sifraPredmeta = sifraPredmeta;
	}
	public String getNazivPredmeta() {
		return nazivPredmeta;
	}
	public void setNazivPredmeta(String nazivPredmeta) {
		this.nazivPredmeta = nazivPredmeta;
	}
	public Semestar getSemestar() {
		return semestar;
	}
	public void setSemestar(Semestar semestar) {
		this.semestar = semestar;
	}
	public int getGodinaStudija() {
		return godinaStudija;
	}
	public void setGodinaStudija(int godinaStudija) {
		this.godinaStudija = godinaStudija;
	}
	public Profesor getPredmetniProfesor() {
		return predmetniProfesor;
	}
	public void setPredmetniProfesor(Profesor predmetniProfesor) {
		this.predmetniProfesor = predmetniProfesor;
	}
	public int getBrESPBbodova() {
		return brESPBbodova;
	}
	public void setBrESPBbodova(int brESPBbodova) {
		this.brESPBbodova = brESPBbodova;
	}
	
	public ArrayList<Student> getStudentiPolozili() {
		return studentiPolozili;
	}
	public void setStudentiPolozili(ArrayList<Student> studentiPolozili) {
		this.studentiPolozili = studentiPolozili;
	}
	public ArrayList<Student> getStudentiNisuPolozili() {
		return studentiNisuPolozili;
	}
	public void setStudentiNisuPolozili(ArrayList<Student> studentiNisuPolozili) {
		this.studentiNisuPolozili = studentiNisuPolozili;
	}
	@Override
	public String toString() {
		return "Predmet [sifraPredmeta=" + sifraPredmeta + ", nazivPredmeta=" + nazivPredmeta + ", semestar=" + semestar
				+ ", godinaStudija=" + godinaStudija + ", predmetniProfesor=" + predmetniProfesor + ", brESPBbodova="
				+ brESPBbodova + ", studentiPolozili=" + studentiPolozili + ", studentiNisuPolozili="
				+ studentiNisuPolozili + "]";
	}
	
	
	
}
