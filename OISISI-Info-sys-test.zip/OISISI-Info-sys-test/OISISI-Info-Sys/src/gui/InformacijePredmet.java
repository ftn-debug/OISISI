package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.LineBorder;

import controller.PredmetiController;
import model.BazaProfesora;
import model.Predmet;
import model.Predmet.Semestar;
import model.Profesor;
import pop.dialogs.EditPredmetDialog;

public class InformacijePredmet extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	static JLabel sifraPredmeta;
	static JLabel nazivPredmeta;
	static JLabel semestar;
	static JLabel godinaNaKojojSeIzvodi;
	static JLabel brESPBbodova;
	static JLabel profesorLabel;
	
	
	static JTextField poljeSifraPredmeta;
	static JTextField poljeNazivPredmeta;
	static JComboBox<Semestar> comboBoxSemestar;
	static JTextField poljeGodinaNaKojojSeIzvodi;
	static JTextField poljeBrESPBbodova;
	static JTextField profesorField;
	public InformacijePredmet(Predmet pr, EditPredmetDialog editPredmetDialog) {
		
		setName("Editovanje predmeta");
		sifraPredmeta = new JLabel("Sifra*");
		nazivPredmeta = new JLabel("Naziv*");
		semestar = new JLabel("Semestar*");

		godinaNaKojojSeIzvodi = new JLabel("Godina na kojoj se izvodi*");
		brESPBbodova = new JLabel("Broj ESPB bodova*");
		profesorLabel= new JLabel("Profesor* ");

		godinaNaKojojSeIzvodi = new JLabel("Godina*");
		brESPBbodova = new JLabel("ESPB*");

		
		poljeSifraPredmeta = new JTextField(15);
		poljeSifraPredmeta.setName("Sifra predmeta*");
		
		poljeNazivPredmeta = new JTextField(15);
		poljeNazivPredmeta.setName("Naziv predmeta*");
		
		poljeGodinaNaKojojSeIzvodi = new JTextField(15);
		poljeGodinaNaKojojSeIzvodi.setName("Godina na kojoj se izvodi*");
		
		poljeBrESPBbodova = new JTextField(15);
		poljeBrESPBbodova.setName("Broj ESPB bodova*");
		
		profesorField= new JTextField(15);
		profesorField.setName("Profesor*");
		if(pr.getPredmetniProfesor() != null) {
		profesorField.setText(pr.getPredmetniProfesor().getIme() + pr.getPredmetniProfesor().getPrezime() );
		}
		
		comboBoxSemestar = new JComboBox<>();
		comboBoxSemestar.setName("Semestar*");
		DefaultComboBoxModel<Semestar> t = new DefaultComboBoxModel<Semestar>();
		t.addElement(Semestar.LETNJI);
		t.addElement(Semestar.ZIMSKI);
		comboBoxSemestar.setModel(t);
		comboBoxSemestar.setSelectedIndex(0);
		comboBoxSemestar.setEditable(false);
		
		
		JButton okButton = new JButton("Potvrdi");
		JButton cancelButton = new JButton("Odustani");
		
		//novi buttoni student 1
		JButton plusButton = new JButton("+");//dodaj image
		JButton minusButton = new JButton("-");
		plusButton.setBorder( new LineBorder(Color.BLACK) );
		plusButton.setPreferredSize(new Dimension(30,30));
		minusButton.setBorder( new LineBorder(Color.BLACK) );
		minusButton.setPreferredSize(new Dimension(30,30));
		Window parent = SwingUtilities.getWindowAncestor(this);
		
		okButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
					//mogu da pozovem editovanje tabele ovdje
				Predmet predmet;
				try {
					predmet = collectData();
					
					if(predmet == null) {
						okButton.setToolTipText("Morate uneti sva polja!");
						okButton.setBackground(Color.RED);
						okButton.setForeground(Color.WHITE);
						
					}else {
						if(predmet.getSifraPredmeta().equals(pr.getSifraPredmeta())) {
							System.out.println("Succes ovdje!");
							PredmetiController.getInstance().updatePredmet(pr.getSifraPredmeta(),predmet);
							// dispose
							Component component = (Component) e.getSource();
					        JDialog dialog = (JDialog) SwingUtilities.getRoot(component);
					        dialog.dispose();
						}
						//ako nije isti a jeste jedinstven
						else if(PredmetiController.getInstance().uniqueSifraPredmeta(predmet)) {
							
							System.out.println("Succes ovdje!");
							PredmetiController.getInstance().updatePredmet(pr.getSifraPredmeta(), predmet);
							 //dispose();
							Component component = (Component) e.getSource();
					        JDialog dialog = (JDialog) SwingUtilities.getRoot(component);
					        dialog.dispose();
							
						}else {
							//ako nije isti a nije ni jedinstven
							JOptionPane.showMessageDialog(parent, "Sifra predmeta nije jedinstvena! ");
							okButton.setToolTipText("Sifra predmeta nije jedinstvena!");
							okButton.setBackground(Color.RED);
							okButton.setForeground(Color.WHITE);
						}
						
					}
				}catch(Exception pe) {
					pe.printStackTrace();
				}				
			}
				
					
				
			});
	
				if(pr.getPredmetniProfesor() == null) {
					plusButton.setEnabled(true);
				}else {
					plusButton.setEnabled(false);
				}

	
				if(pr.getPredmetniProfesor() != null) {
					minusButton.setEnabled(true);
				}else {
					minusButton.setEnabled(false);
				}

		
		
		
		
		
		
		
		

		cancelButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//dispose(); ne mogu ovdje da ga zatvorim
				Component component = (Component) e.getSource();
		        JDialog dialog = (JDialog) SwingUtilities.getRoot(component);
		        dialog.dispose();
				
				//getRootPane().setDefaultButton(cancelButton);
			}
		});
		
		
		
		plusButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				JDialog pd= new JDialog();
				JPanel pan= new JPanel();
				pan.setLayout(new FlowLayout());
		       
		     
		      //  JFrame frame=new ProfesorJList();
				
		//        frame.pack();
		        
		//        frame.setVisible(true);
		       
		  //      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
				List<Profesor> listaProfesora=BazaProfesora.getInstance().getProfesori();
		        DefaultListModel<String> l1 = new DefaultListModel<>(); 
		        
		        for(int i=0; i<listaProfesora.size(); i++) {
		        Profesor p = listaProfesora.get(i);
		        	
		          l1.addElement(p.getIme() + " " + p.getPrezime());  
		          
		        }
		          JList<String> list = new JList<>(l1);  
		          list.setPreferredSize(new Dimension(200, 200));
		          JScrollPane sp = new JScrollPane(list);
		          
		          
		          

					JButton okButton1 = new JButton("Potvrdi");
					JButton cancelButton1 = new JButton("Odustani");
					
					
					okButton1.addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent arg0) {
							//dodajem rpfesora na predmet
							PredmetiController.getInstance().dodajProfesoraNaPredmet(pr,list.getSelectedIndex());
							//postavim da je + disabled
							profesorField.setText(pr.getPredmetniProfesor().getIme() + " " + pr.getPredmetniProfesor().getPrezime());
							
							plusButton.setEnabled(false);
							minusButton.setEnabled(true);
							
						}});
					
					
					
					
					cancelButton1.addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							Component component = (Component) e.getSource();
					        JDialog dialog = (JDialog) SwingUtilities.getRoot(component);
					        dialog.dispose();							
							
							
						}});

					
					
					
					pan.add(okButton1);
					pan.add(cancelButton1);
		          
					
					
		          
			    pd.setTitle("Dodavanje profesora");
				pd.setSize(new Dimension(250,250));
				pd.setResizable(true);
				pd.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				pd.setLocationRelativeTo(editPredmetDialog);
				pd.setVisible(true);
				pd.setLayout(new BorderLayout());	
				pd.getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
				pd.add(pan, BorderLayout.SOUTH);
				pd.add(sp,BorderLayout.CENTER);

				
		        
		        pd.setVisible(true);
				
			}});
			
		
	
		
		
		setLayout(okButton,cancelButton,plusButton, minusButton);
	}


	private void setLayout(JButton okButton, JButton cancelButton, JButton plusButton, JButton minusButton) {
		setLayout(new GridBagLayout());
		
		GridBagConstraints gc1 = new GridBagConstraints(0, 0, 1,
				1, 0, 0,  GridBagConstraints.WEST,  GridBagConstraints.NONE,  new Insets(30, 0, 0, 0),  0, 0);
		add(sifraPredmeta,gc1);
		
		GridBagConstraints gc2 = new GridBagConstraints(1, 0, 3,
				1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(30, 10, 0, 0),  150, 0);
		add(poljeSifraPredmeta,gc2);
		
		
		GridBagConstraints gc3 = new GridBagConstraints(0, 1, 1,
				1, 0, 0,  GridBagConstraints.WEST,  GridBagConstraints.NONE,  new Insets(30, 0, 0, 0), 0, 0);
		add(nazivPredmeta,gc3);
		
		GridBagConstraints gc4 = new GridBagConstraints(1, 1, 3,
				1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(30, 10, 0, 0), 150, 0);
		add(poljeNazivPredmeta,gc4);
		
		GridBagConstraints gc5 = new GridBagConstraints(0, 2, 1,
				1, 0, 0,  GridBagConstraints.WEST,  GridBagConstraints.NONE,  new Insets(30, 0, 0, 0), 0, 0);
		add(semestar,gc5);
		
		
		GridBagConstraints gc6 = new GridBagConstraints(1, 2, 3,
				1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(30, 10, 0, 0), 100, 0);
		add(comboBoxSemestar,gc6);
		
		
		GridBagConstraints gc7 = new GridBagConstraints(0, 3, 1,
				1, 0, 0,  GridBagConstraints.WEST,  GridBagConstraints.NONE,  new Insets(30, 0, 0, 0), 0, 0);
		add(godinaNaKojojSeIzvodi,gc7);
		
		GridBagConstraints gc8 = new GridBagConstraints(1, 3, 3,
				1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(30, 10, 0, 0), 150, 0);
		add(poljeGodinaNaKojojSeIzvodi,gc8);
		
		GridBagConstraints gc9 = new GridBagConstraints(0, 4, 1,
				1, 0, 0,  GridBagConstraints.WEST,  GridBagConstraints.NONE,  new Insets(30, 0, 0, 0), 0, 0);
		add(brESPBbodova,gc9);
		
		
		GridBagConstraints gc10 = new GridBagConstraints(1, 4, 3,
				1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(30, 10, 0, 0), 150, 0);
		add(poljeBrESPBbodova,gc10);
		GridBagConstraints gc11 = new GridBagConstraints(0, 6, 1,
				1, 0, 0,  GridBagConstraints.EAST,  GridBagConstraints.NONE,  new Insets(30, 50, 0, 0), 0, 0);
		add(okButton,gc11);
		
		
		GridBagConstraints gc12 = new GridBagConstraints(1, 6, 1,
				1, 0, 0,  GridBagConstraints.EAST,  GridBagConstraints.NONE,  new Insets(30, 10, 0, 0), 0, 0);
		add(cancelButton,gc12);
		
		
		GridBagConstraints gc13 = new GridBagConstraints(0, 5, 1,
				1, 0, 0,  GridBagConstraints.WEST,  GridBagConstraints.NONE,  new Insets(30, 0, 0, 0), 0, 0);
		add(profesorLabel,gc13);
		
		
		GridBagConstraints gc14 = new GridBagConstraints(1, 5, 2,
				1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(30, 10, 0, 0), 100, 0);
		add(profesorField,gc14);
		GridBagConstraints gc15 = new GridBagConstraints(3, 5, 1,
				1, 0, 0,  GridBagConstraints.WEST,  GridBagConstraints.NONE,  new Insets(30, 10, 0, 0), 10, 0);
		add(plusButton,gc15);
		
		
		GridBagConstraints gc16 = new GridBagConstraints(4, 5, 1,
				1, 0, 0,  GridBagConstraints.EAST,  GridBagConstraints.NONE,  new Insets(30, 0, 0, 0), 10, 0);
		add(minusButton,gc16);

		/*
		//PROVERITI
				gc.gridy = 5;
				gc.gridx = 0;
				gc.anchor=GridBagConstraints.LINE_START;
				add(profesorLabel,gc);
						
				gc.gridy = 5;
				gc.gridx = 1;
				gc.anchor=GridBagConstraints.LINE_START;
				add(profesorField,gc);


				gc.gridy = 5;
				gc.gridx = 2;
				gc.anchor=GridBagConstraints.LINE_START;
				add(plusButton,gc);
						
				gc.gridy = 5;
				gc.gridx = 3;
				gc.anchor=GridBagConstraints.LINE_START;
				add(minusButton,gc);		
		*/		
		
	}
	
	private Predmet collectData() {
		
		Predmet pred;
		pred = null;
		try {
		String sifra = poljeSifraPredmeta.getText();
		String naziv = poljeNazivPredmeta.getText();
		int godina = Integer.parseInt(poljeGodinaNaKojojSeIzvodi.getText());
		int espb = Integer.parseInt(poljeBrESPBbodova.getText());
		
		Semestar seme = (Semestar) comboBoxSemestar.getSelectedItem() ;
		//vrati objekat i onda ga kastujem u semestar
		
		if(sifra.equals("") || naziv.equals("") || 
				seme.equals(null) || poljeGodinaNaKojojSeIzvodi.getText().equals("") 
				|| poljeBrESPBbodova.getText().equals("")) {
			System.out.println("Error imput");
			return null;	
		}
		
		pred = new Predmet(sifra,naziv,seme,godina,espb);
		
				
		}catch (Exception e) {
			e.printStackTrace();
		}
		return pred;
	}
	
}
