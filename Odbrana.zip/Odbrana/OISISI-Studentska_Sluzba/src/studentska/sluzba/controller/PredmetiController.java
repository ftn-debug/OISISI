package studentska.sluzba.controller;

import java.util.ArrayList;

import studentska.sluzba.gui.MainFrame;
import studentska.sluzba.model.BazaPredmeta;
import studentska.sluzba.model.BazaProfesora;
import studentska.sluzba.model.Predmet;
import studentska.sluzba.model.Profesor;
/**
  * Klasa koja poziva na promjene u Bazi Predmeta. Ona sluzi kao posrednik izmedju Baze i Main Frame-a.
 * @author Maja Blagic
 *
 */
public class PredmetiController {
private static PredmetiController instance = null;
/**
 * Klasa je Singleton 
 * @return - vraca instancu Kontrolera Predmeta
 */
	public static PredmetiController getInstance() {
		if(instance == null) {
			instance = new PredmetiController();
		}
		return instance;
	}

	private PredmetiController() {	}

/**
 * Izborom odgovarajućeg predmeta i klikom na dugme Dodaj , dodaje se novi predmet u tabelu
 * nepoloženih predmeta, koju je ovom prilikom potrebno ažurirati.	
 * @param predmet - predmet koji treba dodati 
 */
public void dodajPredmet(Predmet predmet) {
		

	
		BazaPredmeta.getInstance().dodajPredmetEntity(predmet);
		MainFrame.getInstance().azurirajPrikazPredmet("DODAT PREDMET", -1);
		StudentiController.getInstance().azurirajListuPredmeta(predmet);
		
	}
/**
 * Poziva se metoda za provjeravanje jedinstvenosti kljuca/sifre entiteta predmet.
 * @param predmet - predmet za koji se vrsi provjera
 * @return - true ako je sifra jedinstvena, false u suprotnom
 */
public boolean uniqueSifraPredmeta(Predmet predmet) {

	return BazaPredmeta.getInstance().uniqueSifraPredmeta(predmet.getSifraPredmeta());
}


public void izbrisiPredmet(Predmet p) {

	BazaPredmeta.getInstance().izbrisPredmet(p.getSifraPredmeta());
	//A mozemo ga brisati i iz lista studenata koji jesu/nisu polozili predmet
	//ali ne znam da li to da radim
	//to se nigdje ne prikazuje i nije pomenuto u specifikaciji
	MainFrame.getInstance().azurirajPrikazPredmet("OBRISAN PREDMET", -1);
	//samo azuriram studenta
	StudentiController.getInstance().izbristiPredmet(p);
	
}
/**
 * Pozvana je metoda koja ce izmijeniti obiljezja proslijedjenog predmeta u Bazi Predmeta.
 * Nakon promjene baze potrebno je apdejtovati prikaz tabele predmeta u Main Frame- u.
 * @param sifraPredmeta - kljuc predmeta koji treba biti izmijenjen
 * @param p - korisnicki uneseni podaci za izmjenu predmeta
 */
public void updatePredmet(String sifraPredmeta, Predmet p) {

	
	BazaPredmeta.getInstance().izmeniPredmet(sifraPredmeta,p.getSifraPredmeta(),p.getNazivPredmeta(),p.getSemestar(),p.getGodinaStudija(),p.getPredmetniProfesor(),p.getBrESPBbodova());
	MainFrame.getInstance().azurirajPrikazPredmet(null, -1);	
}
/**
 * Metoda koja poziva brisanje profesora sa selektovanog predmeta
 * @param p - proslijedjeni profesor
 */
public void obrisiProfesoraSaPredmeta(Profesor p) {

	BazaPredmeta.getInstance().obrisiProfesoraSaPredmeta(p);
	MainFrame.getInstance().azurirajPrikazPredmet(null, 0);
}

/**
 * Metoda koja poziva dodavanje selektovanog Profesora na selektovani Predmet
 * @param p - profesor kojme ce biti dodjeljen predmet
 * @param predmet - predmet na koji ce biti postavljen profesor
 */
public void dodajProfesoraPredmetu(Profesor p ,Predmet predmet) {
	BazaPredmeta.getInstance().dodajProfesoraPredmetu(p,predmet);
}


/**
 *
 * @return -  vraca listu predmeta iz Baze Predmeta
 */
public ArrayList<Predmet> vratiSvePredmete(){
	
	return (ArrayList<Predmet>) BazaPredmeta.getInstance().getPredmeti();
}
/**
 * Metoda koja poziva dodavanje selektovanog Profesora na selektovani Predmet
 * @param pr - profesor kojme ce biti dodjeljen predmet
 * @param selectedIndex - predmet na koji ce biti postavljen profesor
 */
public void dodajProfesoraNaPredmet(Predmet pr, int selectedIndex) {

	Profesor p= BazaProfesora.getInstance().getProfesori().get(selectedIndex);
	BazaPredmeta.getInstance().dodajProfesoraNaPredmet(pr,p);
	
	MainFrame.getInstance().azurirajPrikazPredmet(null, 0);
	
	
}


}
