package studentska.sluzba.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import studentska.sluzba.model.Predmet;

public class EditPredmetDialog extends JDialog{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	
	public EditPredmetDialog(Predmet pr) {

		
		super();
		//
		Toolkit kit = Toolkit.getDefaultToolkit();
		setTitle("Editovanje Predmeta");
		setSize(new Dimension(400,450));
		setResizable(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
		setLayout(new BorderLayout());	
		setModal(true);
        getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
		 
        createTabbedPane(pr);
		 setResizable(true);
		 setVisible(true);		
	}
	private JPanel Informacije; //klasa sa TableTab metodama
	private JPanel Polozeni;
	private JPanel Nepolozeni;
	private JTabbedPane tabbedPane;
	
	public JTabbedPane getTabbedPane() {
		return tabbedPane;
	}	
	public int selectedTab() {
		return tabbedPane.getSelectedIndex();
	}
	private void createTabbedPane(Predmet pr) {
		tabbedPane = new JTabbedPane();
		Informacije =  new InformacijePredmet(pr,this); 
		

	

		tabbedPane.addTab("Informacije", Informacije);

		
		this.setLocationRelativeTo(rootPane);
		add(tabbedPane,BorderLayout.CENTER);
		
	}
	
}
	
	

