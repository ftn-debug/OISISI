package pop.dialogs;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

import controller.StudentiController;
import gui.MainFrame;
import model.Student;

public class DeleteStudentDialog  extends JDialog  implements ActionListener{

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DeleteStudentDialog(Student s) {
	
	
	Object[] options= {"Da","Ne"};
	int opcija= JOptionPane.showOptionDialog(null, "Da li ste sigrni da želite"
													+ " da obrišete studenta?", 
				"Brisanje studenta.", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
			    null, options, options[1]);
	
	if(opcija == JOptionPane.YES_OPTION) {
	StudentiController.getInstance().obrisiStudenta(s);
	MainFrame.getInstance().azurirajPrikazStudenta("OBRISAN STUDENT", -1);
	}
	
	
	setLocationRelativeTo(null);
	setSize(new Dimension(250,150));
	setResizable(false);
	setModal(true);
	setLocationRelativeTo(MainFrame.getInstance());
	//getDefaultCloseOperation();
	getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
	
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
