package studentska.sluzba.view;

import javax.swing.table.AbstractTableModel;

import studentska.sluzba.model.BazaStudenata;

public class AbstractTableModelStudent extends AbstractTableModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//broj redova
	@Override
	public int getRowCount() {
		return BazaStudenata.getInstance().getStudenti().size();
	}
		//broj kolona
	@Override
	public int getColumnCount() {
		return BazaStudenata.getInstance().getColumnCount();
	}
		//naziv kolone 
	@Override
	public String getColumnName(int column) {
		return BazaStudenata.getInstance().getColumnName(column);
	}
		//vrijednost celije
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return	BazaStudenata.getInstance().getValueAt(rowIndex, columnIndex);
	}

}
