package gui;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

public class ActionEdit extends AbstractAction {

	private static final long serialVersionUID = 1583426086994634757L;

	public ActionEdit() {
		
		putValue(MNEMONIC_KEY, KeyEvent.VK_U);
		putValue(SHORT_DESCRIPTION, "Edit");
		putValue(SMALL_ICON, new ImageIcon("Images/pencil (1).png"));
		putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_U, KeyEvent.CTRL_MASK));
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		System.out.println("editJ");
	}

}
