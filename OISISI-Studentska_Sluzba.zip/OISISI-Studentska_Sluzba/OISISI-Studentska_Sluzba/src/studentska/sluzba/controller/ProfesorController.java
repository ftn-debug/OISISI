package studentska.sluzba.controller;

import studentska.sluzba.gui.MainFrame;
import studentska.sluzba.model.BazaProfesora;
import studentska.sluzba.model.Predmet;
import studentska.sluzba.model.Profesor;
import studentska.sluzba.pop.dialogs.EditProfesorDialog;

public class ProfesorController {

	private static ProfesorController instance = null;
	
	public static ProfesorController getInstance() {
		if(instance == null) {
			instance = new ProfesorController();
		}
		return instance;
	}
	
	private ProfesorController() {	}
	
	public void dodajProfesora(Profesor profesor) {
		BazaProfesora.getInstance().dodajProfesora(profesor);
		MainFrame.getInstance().azurirajPrikazProfesora("DODAT PROFESOR", -1);
	}
	
	public boolean uniqueBrLicneKarte(Profesor profesor) {
		return BazaProfesora.getInstance().uniqueBrLicneKarte(profesor.getBrLicneKarte());
	}
	
	
	public void izmjeniProfesora(Profesor profesor) {
		//ne profesor.getBrLicne karte nego ti treba stari profesor ber licne karte
		//dalje u izmjeni profesora
		BazaProfesora.getInstance().izmjeniProfesora(profesor.getBrLicneKarte(), profesor.getIme(), 
													profesor.getPrezime(), profesor.getDatumRodj(), 
													profesor.getAdresaStanovanja(), profesor.getTelefon(), profesor.getMail(),
													profesor.getAdresaKancelarije(),profesor.getTitula(), profesor.getZvanje());
		MainFrame.getInstance().azurirajPrikazProfesora("IZMJENJEN PROFESOR", -1);
	}

	public void izbrisiProfesora(Profesor p) {

		//treba zaci u predmete i izbrisati profesora iz svih predmeta na kojima je on profesor
		PredmetiController.getInstance().obrisiProfesoraSaPredmeta(p);
				
				//na kraju zaci u prof i obrisati ga
				BazaProfesora.getInstance().izbrisiProfesora(p.getBrLicneKarte());
				MainFrame.getInstance().azurirajPrikazProfesora("OBRISAN PROFESOR", -1);
		
		
	}
	
	public void dodajPredmetProfesoru(Profesor p,Predmet predmet,EditProfesorDialog edp) {
		
		BazaProfesora.getInstance().dodajPredmetProfesoru(p,predmet);
		//dodavanje profesora predmetu
		PredmetiController.getInstance().dodajProfesoraPredmetu(p,predmet);
		edp.azurirajPrikazPredmetaProfesora(null, -1);
		edp.azurirajPrikazPredmetaZaDodati(null, -1);
	}
	

}
