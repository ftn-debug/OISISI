package studentska.sluzba.view;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class StudentiJTable  extends JTable implements TableModel{

	/**
	 * 
	 */
	private AbstractTableModelStudent model;
	private static TableRowSorter<AbstractTableModelStudent> sortiranje;
	private static final long serialVersionUID = 1L;
	
	public StudentiJTable() {

		this.setRowSelectionAllowed(true);
		this.setColumnSelectionAllowed(true);
		this.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);		
		
		this.getTableHeader().setReorderingAllowed(false); // kako bismo iskljucili mogucnost pomeranja kolona levo-desno
		this.model = new AbstractTableModelStudent();		
		sortiranje = new TableRowSorter<AbstractTableModelStudent>(model);
		this.setRowSorter(sortiranje);
		this.setModel(model);	
	}
	

	@Override
	public TableModel getModel() {
		// TODO Auto-generated method stub
		return model;
	}
	public static TableRowSorter<AbstractTableModelStudent> getSortiranje() {
		return sortiranje;
	}
	
	@Override
	public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
		Component c = super.prepareRenderer(renderer, row, column);

		if (isRowSelected(row)) {
			c.setBackground(Color.LIGHT_GRAY);
		} else {
			c.setBackground(Color.WHITE);
		}
		return c;
	
	}


	@Override
	public void addTableModelListener(TableModelListener arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void removeTableModelListener(TableModelListener arg0) {
		// TODO Auto-generated method stub
		
	}

}
