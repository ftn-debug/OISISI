package studentska.sluzba;

import studentska.sluzba.gui.MainFrame;
import studentska.sluzba.model.BazaStudenata;

public class Main {

	public static void main(String[] args) {
		MainFrame.getInstance();
	
		BazaStudenata.getInstance().ispisi();
	}


}
