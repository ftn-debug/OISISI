package studentska.sluzba;

import gui.MainFrame;
import model.BazaPredmeta;
import model.BazaProfesora;
import model.BazaStudenata;

public class Main {

	public static void main(String[] args) {
		MainFrame.getInstance();
		//MainFrame mf = new MainFrame();
		// mf.setVisible(true);
		 //mf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		BazaProfesora.getInstance();
		BazaPredmeta.getInstance();
		BazaStudenata.getInstance();
	}

}
