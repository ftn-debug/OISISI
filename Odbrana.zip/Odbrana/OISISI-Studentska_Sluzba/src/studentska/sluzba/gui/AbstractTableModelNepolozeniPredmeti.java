package studentska.sluzba.gui;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

import studentska.sluzba.model.Predmet;
/**
 * Klasa koja predstavlja tabelu nepolozenih predmeta za entitet Studenta
 * @author Maja Blagic
 *
 */
public class AbstractTableModelNepolozeniPredmeti  extends AbstractTableModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<Predmet> listaPredmeta;
	private String[] kolone;
	
	public AbstractTableModelNepolozeniPredmeti(ArrayList<Predmet> predmeti) {
		super();
		listaPredmeta=predmeti;
		kolone = new String[]{"SIFRA PREDMETA","NAZIV PREDMETA","SEMESTAR",
			"GODINA NA KOJOJ SE PREDMET IZVODI","ESPB"};
	}
	
	public String getColumnName(int column) {
		return kolone[column];
	}
	@Override
	public int getRowCount() {
		return listaPredmeta.size();
	}

	@Override
	public int getColumnCount() {
		return kolone.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Predmet predmet = listaPredmeta.get(rowIndex);
		
		switch (columnIndex) {
		case 0: 
			return predmet.getSifraPredmeta();
		case 1:
			return predmet.getNazivPredmeta();
		case 2:
			return predmet.getSemestar() + "";
		case 3:
			return predmet.getGodinaStudija() + "";
		case 4:
			return predmet.getBrESPBbodova() + "";
		default:
			return null;
		}
	}
	

}
