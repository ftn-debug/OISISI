package pop.dialogs;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class AddStudentDialog extends JDialog implements ActionListener {

	
	static JLabel imeL;
	static JLabel prezimeL;
	static JLabel datumRodjenjaL;
	static JLabel adresaL;
	static JLabel brojTelefonaL;
	static JLabel eMailL;
	static JLabel brIndexaL;
	static JLabel godinaUpisaL;
	static JLabel godinaStudijaL;
	static JLabel statusL;
	
	static JTextField imeF;
	static JTextField prezimeF;
	static JTextField datumRodjenjaF;
	static JTextField adresaF;
	static JTextField brojTelefonaF;
	static JTextField eMailF;
	static JTextField brIndexaF;
	static JTextField godinaUpisaF;
	static JTextField godinaStudijaF;
	static JTextField statusF;
	
	static JComboBox<String> statusBox;
	
	
	public AddStudentDialog() {
		setTitle("Dodavanje studenta");
		imeL=new JLabel("Ime* ");
		prezimeL= new JLabel("Prezime *");
		datumRodjenjaL=new JLabel("Datum rodjenja * ");
	    adresaL=new JLabel("Adresa stanovanja * ");
		brojTelefonaL= new JLabel("Kontakt telefon* ");
		eMailL= new JLabel("E-mail adresa* ");
		brIndexaL= new JLabel("Broj indeksa* ");
		godinaUpisaL=new JLabel("Datum upisa* ");
		godinaStudijaL=new JLabel("Godina studija* ");
		statusL= new JLabel("Nacin finansiranja* ");
		//statusL.add(statusBox);
		statusBox=new JComboBox();
		
		DefaultComboBoxModel statusModel=new DefaultComboBoxModel();
		statusModel.addElement("Samofinansiranje");
		statusModel.addElement("Budzet");
		statusBox.setModel(statusModel);
		statusBox.setSelectedIndex(0);
		statusBox.setEditable(true);

		
		setLocationRelativeTo(null);
		setSize(new Dimension(500,500));
		setResizable(false);
		setModal(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
		setVisible(true);
		
		
	}
	
	
	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

}
