package model;


import java.util.List;

import gui.MainFrame;
import model.Predmet.Semestar;


import java.util.ArrayList;
public class BazaPredmeta {
	
	private static BazaPredmeta instance = null;
	
	public static BazaPredmeta getInstance() {
		if(instance == null) {
			instance = new BazaPredmeta();
		}
		return instance;
	}
	
	
	private List<Predmet> predmeti;
	private List<String> kolone;
	
	
	private BazaPredmeta() {
		initPredmete();
		
		this.kolone = new ArrayList<>();
		this.kolone.add("SIFRA PREDMETA");
		this.kolone.add("NAZIV PREDMETA");
		this.kolone.add("BROJ ESPB BODOVA");
		this.kolone.add("GODINA NA KOJOJ SE PREDMET IZVODI");
		this.kolone.add("SEMESTAR");
		//this.kolone.add("PREDMETNI PROFESOR");
	}
	
	private void initPredmete() {
		
		this.predmeti = new ArrayList<Predmet>();		
		
		dodajPredmet(new Predmet( "PR-1","Analiza", Semestar.LETNJI, 1, 5));
		dodajPredmet(new Predmet( "PR-2","OET", Semestar.LETNJI, 2, 5));
		dodajPredmet(new Predmet( "PR-3","PPR", Semestar.ZIMSKI, 1, 5));
		//System.out.println(predmeti);
	}
	
	public List<Predmet> getPredmeti() {
		return predmeti;
	}


	public void setPredmeti(List<Predmet> predmeti) {
		this.predmeti = predmeti;
	}
	
	
	public int getColumnCount() {
		return 5;
	}
	
	public String getColumnName(int index) {
		return this.kolone.get(index);
	}
	
	public Predmet getRow(int rowIndex) {
		return this.predmeti.get(rowIndex);
	}
	
	public String getValueAt(int row,int column) {
		Predmet predmet = this.predmeti.get(row);
		switch (column) {
		case 0: 
			return predmet.getSifraPredmeta();
		case 1:
			return predmet.getNazivPredmeta();
		case 2:
			return Integer.toString(predmet.getBrESPBbodova());
		case 3:
			return Integer.toString(predmet.getGodinaStudija());
		case 4:
			return predmet.getSemestar() + "";
		default:
				return null;		
		}
	}
	
	public void dodajPredmet(String sifra,String naziv,Semestar semestar,
							int godinaStudija,Profesor predmetniProfesor,int brESPB) {
		if(uniqueSifraPredmeta(sifra)) {
			
			this.predmeti.add(new Predmet(sifra,naziv,semestar,godinaStudija,predmetniProfesor,brESPB));
		}
	}
	
	public void dodajPredmet(Predmet predmet) {
		if(uniqueSifraPredmeta(predmet.getSifraPredmeta())){
			this.predmeti.add(predmet);
		}
	}
	
	@SuppressWarnings("unlikely-arg-type") //PITATI DA LI SIFRA PREDMETA MORA BITI STRING ILI MOZE BITI INT
	public void izbrisPredmet(String id)
	{
		for(Predmet p : predmeti) {
			if(p.getSifraPredmeta().equals(id)) {
				predmeti.remove(p);
				//sto nije this.
				break;
			}
		}
	}
	
	public void izmeniPredmet(String sifra,String sifraPredmeta,String naziv,Semestar semestar,
			int godinaStudija,Profesor predmetniProfesor,int brESPB) {
		for(Predmet p : predmeti) {
			if(p.getSifraPredmeta() == sifra) {
				
				p.setSifraPredmeta(sifraPredmeta);
				p.setNazivPredmeta(naziv);
				p.setSemestar(semestar);
				p.setGodinaStudija(godinaStudija);
				p.setPredmetniProfesor(predmetniProfesor);
				p.setBrESPBbodova(brESPB);
			}
		}
		
	}

	public Boolean uniqueSifraPredmeta(String sifraPredmeta) {
		
		for(Predmet p: predmeti) {
			if(p.getSifraPredmeta().equals(sifraPredmeta)) {
				return false;
			}
		}
		return true;
	}
	public void azurirajStudenta() {
		
		
	}

	public void dodajProfesoraNaPredmet(Predmet pr, Profesor prof) {
		
		for(Predmet p : predmeti) {
			if(p.getSifraPredmeta() == pr.getSifraPredmeta()) {
				p.setPredmetniProfesor(prof);
			
			
			}
			}
		
		
	}

	public void obrisiProfesoraSaPredmeta(Profesor pr) {
//brisem po kljucu

		for(Predmet p : predmeti) {
			
			if(p.getPredmetniProfesor() != null) {//ne mogu da uradim .getBrLicneKarte kad mi vrati null;
			if(p.getPredmetniProfesor().getBrLicneKarte() == pr.getBrLicneKarte()){
				p.setPredmetniProfesor(null);
			
			
			}
		}
		}
		
	}
	
	public void dodajProfesoraPredmetu(Profesor p ,Predmet predmet) {
		
		predmet.setPredmetniProfesor(p);
	}
	
	public void ukloniProfesoraSaPredmet(Profesor p,Predmet predmet) {
		//if(predmet.getPredmetniProfesor().equals(p))
		predmet.setPredmetniProfesor(null);
		
	}
	
	
}
