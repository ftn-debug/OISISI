package model;

import java.util.ArrayList;

import model.Student.Status;

public class BazaStudenata {
	
	private static BazaStudenata instance=null;
	
	public static BazaStudenata getInstance() {
		if(instance==null) {
			instance= new BazaStudenata();
		}
		return instance;
	}

	private ArrayList<Student> studenti;
	private ArrayList<String> kolone;
	
	private BazaStudenata() {
		//ne dodajem nista na pocetku
		
		initStudenti();
		
		this.kolone=new ArrayList<String>();
		this.kolone.add("INDEKS");
		this.kolone.add("IME");
		this.kolone.add("PREZIME");
		this.kolone.add("GODINA STUDIJA");
		this.kolone.add("STATUS");
		this.kolone.add("PROSEK");
	
	}

	private void initStudenti() {
		this.studenti=new ArrayList<Student>();
		
	}

	public ArrayList<Student> getStudenti() {
		return studenti;
	}

	public void setStudenti(ArrayList<Student> studenti) {
		this.studenti = studenti;
	}

	public int getColumnCount() {
		return 6;
	}
	
	public String getColumnName(int index) {
		return this.kolone.get(index);
	}
	
	public Student getRow(int index) {
		return this.studenti.get(index);
	}
	
	public String getValueAt(int row, int column) {
		Student student = this.studenti.get(row);
		
		switch(column) {
		case 0:
			return student.getBrIndeksa();
		case 1:
			return student.getIme();
		case 2:
			return student.getPrezime();
		case 3:
			return student.getTrenutnaGodinaStudija() +"";
		case 4:
			return student.getStatus() +"";
		case 5:
			return student.getProsecnaOcena() + "";
		
		default:
				return  null;
		}
	}
	
	public void dodajStudenta (String prezime, String ime, String datumRodjenja, String adresa, String kontaktTelefon, String eMail,
			String brIndeksa, String godinaUpisa, int trenutnaGodinaStudija, Status status, double prosecnaOcena) {
		
		this.studenti.add(new Student(prezime,ime,datumRodjenja,adresa,kontaktTelefon,eMail,brIndeksa,godinaUpisa,trenutnaGodinaStudija,status,prosecnaOcena));
	
	}
	
	public void izbrisiStudenta(String brIndeksa) {
		for(Student s: studenti) {
			if(s.getBrIndeksa()==brIndeksa) {
				studenti.remove(s);
				break;
			}
		}
	}
	public void izmeniStudenta(String prezime, String ime, String datumRodjenja, String adresa, String kontaktTelefon, String eMail,
			String brIndeksa, String godinaUpisa, int trenutnaGodinaStudija, Status status, double prosecnaOcena) {
		for (Student s: studenti) {
			if(s.getBrIndeksa()==brIndeksa) {
				s.setPrezime(prezime);
				s.setIme(ime);
				s.setDatumRodjenja(datumRodjenja);
				s.setAdresa( adresa);
				s.setKontaktTelefon(kontaktTelefon);
				s.seteMail(eMail);
				s.setGodinaUpisa(godinaUpisa);
				s.setTrenutnaGodinaStudija(trenutnaGodinaStudija);
				s.setStatus(status);
				s.setProsecnaOcena(prosecnaOcena);
		
			
			}
		}
		
	}

	public void dodajStudenta(Student entity) {
		this.studenti.add(entity);		
	}
}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

