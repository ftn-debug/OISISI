package model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import model.Student.Status;

public class BazaStudenata {
	
	private static BazaStudenata instance=null;
	
	public static BazaStudenata getInstance() {
		if(instance==null) {
			instance= new BazaStudenata();
		}
		return instance;
	}

	private ArrayList<Student> studenti;
	private ArrayList<String> kolone;
	
	private BazaStudenata() {
		
		initStudenti();
		
		this.kolone=new ArrayList<String>();
		this.kolone.add("INDEKS");
		this.kolone.add("IME");
		this.kolone.add("PREZIME");
		this.kolone.add("GODINA STUDIJA");
		this.kolone.add("STATUS");
		this.kolone.add("PROSEK");
	
	}
	
	/*import java.text.SimpleDateFormat;
	import java.util.Date;
	public class StringToDateExample1 {
	public static void main(String[] args)throws Exception {
	String sDate1="31/12/1998";
	Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
	System.out.println(sDate1+"\t"+date1);*/
	
		
		private void initStudenti() {
		this.studenti=new ArrayList<Student>();

		try {
			Date date1=new SimpleDateFormat("dd/MM/yyyy").parse("11/12/1999");
			Date date2=new SimpleDateFormat("dd/MM/yyyy").parse("11/12/1999");
			Date date3=new SimpleDateFormat("dd/MM/yyyy").parse("11/12/1999");
			dodajStudenta("Matkovski","Marko",date1, "ZelenaPijaca,32","065/434/433", "marksec@max.com","RA22-2018",2018, 2,Status.B, 8.01);
			dodajStudenta("Ivkovic","Ranko",date1, "ZelenaPijaca,32","065/434/433", "marksec@max.com","RA22-2018",2018, 2,Status.B, 8.01);
			dodajStudenta("Pavkovic","Nikoleta",date2, "ZelenaPijaca,32","064/252/767", "nicol@max.com","RA21-2018",2018, 2,Status.B, 8.50);
			dodajStudenta("Antonijevic","Filip",date3, "ZelenaPijaca,32","065/434/222", "anton@max.com","RA123-2018",2018, 2,Status.S, 7.0);
			dodajStudenta("Markovic","Bogdan",date3, "ZelenaPijaca,302","064/234/2892", "bogMar@max.com","RA145-2018",2018, 2,Status.S, 10.0);

			
			
			//prvi student
		/*	
			Predmet p1=new Predmet( "PR-11212","miss", Semestar.LETNJI, 1, 5);
			Predmet p2=new Predmet( "PR-11","lprs", Semestar.LETNJI, 2, 5);
			Predmet p3=new Predmet( "PR-212","bp", Semestar.ZIMSKI, 1, 5);
			
			ArrayList<Predmet> spisakNepolozenihIspita =new ArrayList<Predmet>();
			spisakNepolozenihIspita.add(p1);
			spisakNepolozenihIspita.add(p2);
			spisakNepolozenihIspita.add(p3);
			
			studenti.get(1).setSpisakNepolozenihIspita(spisakNepolozenihIspita);
			
			Predmet p11=new Predmet( "PR-1","Analiza", Semestar.LETNJI, 1, 5);
			Predmet p21=new Predmet( "PR-2","OET", Semestar.LETNJI, 2, 5);
			Predmet p31=new Predmet( "PR-3","PPR", Semestar.ZIMSKI, 1, 5);
			Ocena o1= new Ocena(studenti.get(1), p11, vOcjene.deset, null);
			Ocena o2= new Ocena(studenti.get(1), p21, vOcjene.sest, null);
			Ocena o3= new Ocena(studenti.get(1), p31, vOcjene.osam, null);
			
			ArrayList<Ocena> spisakPolozenihIspita =new ArrayList<Ocena>();
			spisakPolozenihIspita.add(o1);
			spisakPolozenihIspita.add(o2);
			spisakPolozenihIspita.add(o3);
			studenti.get(1).setSpisakPolozenihIspita(spisakPolozenihIspita);
			//drugi student
			
			Predmet p4=new Predmet( "PR-11212","miss", Semestar.LETNJI, 1, 5);
			Predmet p5=new Predmet( "PR-11","lprs", Semestar.LETNJI, 2, 5);
			Predmet p6=new Predmet( "PR-212","bp", Semestar.ZIMSKI, 1, 5);
			
			ArrayList<Predmet> spisakNepolozenihIspita1 =new ArrayList<Predmet>();
			spisakNepolozenihIspita1.add(p4);
			spisakNepolozenihIspita1.add(p5);
			spisakNepolozenihIspita1.add(p6);
			
			studenti.get(2).setSpisakNepolozenihIspita(spisakNepolozenihIspita1);
			
			Predmet p7=new Predmet( "PR-112","MO", Semestar.LETNJI, 1, 10);
			Predmet p9=new Predmet( "PR-333","PP", Semestar.ZIMSKI, 1, 8);
			Ocena o11= new Ocena(studenti.get(2), p7, vOcjene.deset, null);
			Ocena o22= new Ocena(studenti.get(2), p9, vOcjene.sest, null);
			
			ArrayList<Ocena> spisakPolozenihIspita1 =new ArrayList<Ocena>();
			spisakPolozenihIspita1.add(o11);
			spisakPolozenihIspita1.add(o22);
			
			studenti.get(2).setSpisakPolozenihIspita(spisakPolozenihIspita1);*/
		} catch (ParseException e) {
		
			e.printStackTrace();
		}
	}

	public ArrayList<Student> getStudenti() {
		return studenti;
	}

	public void setStudenti(ArrayList<Student> studenti) {
		this.studenti = studenti;
	}

	public int getColumnCount() {
		return 6;
	}
	
	public String getColumnName(int index) {
		return this.kolone.get(index);
	}
	
	public Student getRow(int index) {
		return this.studenti.get(index);
	}
	
	public String getValueAt(int row, int column) {
		Student student = this.studenti.get(row);
		
		switch(column) {
		case 0:
			return student.getBrIndeksa();
		case 1:
			return student.getIme();
		case 2:
			return student.getPrezime();
		case 3:
			return student.getTrenutnaGodinaStudija() +"";
		case 4:
			return student.getStatus() +"";
		case 5:
			return student.getProsecnaOcena() + "";
		
		default:
				return  null;
		}
	}
	
	public void dodajStudenta (String prezime, String ime, Date datumRodjenja, String adresa, String kontaktTelefon, String eMail,
			String brIndeksa, int godinaUpisa, int trenutnaGodinaStudija, Status status, double prosecnaOcena) {
		//ne moze se dodati student sa istim br indeksa
		if(uniqueBrIndexa(brIndeksa)) { 
		this.studenti.add(new Student(ime,prezime,datumRodjenja,adresa,kontaktTelefon,eMail,brIndeksa,godinaUpisa,trenutnaGodinaStudija,status,prosecnaOcena));
		}
	}
	
	public void izbrisiStudenta(String brIndeksa) {
		for(Student s: studenti) {
			if(s.getBrIndeksa()==brIndeksa) {
				studenti.remove(s);
				break;
			}
		}
	}
	public void izmeniStudenta(String index,String prezime, String ime, Date datumRodjenja, String adresa, String kontaktTelefon, String eMail,
			String brIndeksa, int godinaUpisa, int trenutnaGodinaStudija, Status status, double prosecnaOcena) {
		for (Student s: studenti) {
			if(s.getBrIndeksa().equals(index)) {
				//uz pretpostavku da se i indeks moze izmijeniti
				s.setBrIndeksa(brIndeksa);
				s.setPrezime(prezime);
				s.setIme(ime);
				s.setDatumRodjenja(datumRodjenja);
				s.setAdresa( adresa);
				s.setKontaktTelefon(kontaktTelefon);
				s.seteMail(eMail);
				s.setGodinaUpisa(godinaUpisa);
				s.setTrenutnaGodinaStudija(trenutnaGodinaStudija);
				s.setStatus(status);
				s.setProsecnaOcena(prosecnaOcena);
		
			
			}
		}
		
	}

	public void dodajStudenta(Student entity) {
		
		if(uniqueBrIndexa(entity.getBrIndeksa())) { 
			this.studenti.add(entity);		
		}
	}

	public Boolean uniqueBrIndexa(String brIndeksa) {
		
		for(Student s: studenti) {
			if(s.getBrIndeksa().equals(brIndeksa)) {
				return false;
			}
		}
		return true;
	}

	

	public void ponistiOcenu(Student s, int selectedRow) {

		
		Ocena o=s.getSpisakPolozenihIspita().get(selectedRow);
		Predmet p= o.getPredmet();
		s.getSpisakPolozenihIspita().remove(o);
		s.getSpisakNepolozenihIspita().add(p);
		
	}
	public void azurirajPredmete(Predmet p) {
		for(Student s: studenti) {
			s.getSpisakPredmetaDaPolaze().add(p);
			}
		}

	public void azurirajListuPredmeta(Predmet p) {
		for(Student s: studenti) {
			/*Prvi uslov je da se ne nalaze ni u listi poloÅ¾enih, kao ni u listi
nepoloÅ¾enih predmeta oznaÄ�enog studenta. Drugi uslov je da je oznaÄ�eni student na
odgovarajuÄ‡oj godini studija (ista ili viÅ¡a godina studija u odnosu na godinu na kojoj se
predmet izvodi).*/

			if(s.getTrenutnaGodinaStudija() >= p.getGodinaStudija()) {
			s.getSpisakPredmetaDaPolaze().add(p);
			}
		
		
		}
	
	}

	public void azurirajListuNepolozenihPredmeta(Student s, int selectedRow) {
		//uzmi predmet
		Predmet p =s.getSpisakPredmetaDaPolaze().get(selectedRow);
		s.getSpisakNepolozenihIspita().add(p);
		s.getSpisakPredmetaDaPolaze().remove(p);
		
	}

	public void uklanjanjePredmetaSaStudenta(Student s, int selectedRow) {

		Predmet p =s.getSpisakNepolozenihIspita().get(selectedRow);
		s.getSpisakPredmetaDaPolaze().add(p);
		s.getSpisakNepolozenihIspita().remove(p);
		
	}


	public void izbrisiPredmet(Predmet p) {
		
		
		for(Student s: studenti) {
			if(s.getSpisakNepolozenihIspita().contains(p)) {
				s.getSpisakNepolozenihIspita().remove(p);
			}
			
			if(s.getSpisakPolozenihIspita().contains(p)) {
				s.getSpisakPolozenihIspita().remove(p);
			}
			if(s.getSpisakPredmetaDaPolaze().contains(p)) {
				s.getSpisakPredmetaDaPolaze().remove(p);
			}
		
		}
	}

	
	
	public void dodajOcenu(Student s, Ocena o,Predmet p) {
		
		s.getSpisakPolozenihIspita().add(o);
		s.getSpisakNepolozenihIspita().remove(p);

		
	}
	
	}



	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

