package pop.dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;

import controller.StudentiController;
import gui.AbstractTableModelNepolozeniPredmeti;
import gui.AbstractTableModelPolozeniPredmet;
import gui.AbstractTableModelSpisakPredmetaDaPolaze;
import gui.InformacijeStudent;
import gui.MainFrame;
import gui.NepolozeniPredmetiTable;
import gui.PolozeniPredmetiPanel;
import gui.PolozeniPredmetiTable;
import gui.SpisakPredmetaDaPolazeTable;
import model.Predmet;
import model.Student;

public class EditStudentDialog extends JDialog/* implements ActionListener*/{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//treba mi tu neki JFrame=JDialog
		//private JPanel Informacije; 
		//private JPanel Polozeni;
		//private JPanel Nepolozeni;
		//private JTabbedPane tabbedPane;
		//Valjda tabbedPane nema neke metode kao JTabbedPaneCloseButton
		//dobar primjer za layout i MouseListenere
		public JDialog master ;
		public EditStudentDialog( Student s) {

			super();
			master=this;


			@SuppressWarnings("unused")
			Toolkit tk = java.awt.Toolkit.getDefaultToolkit();
			setTitle("Editovanje Studenta");
			setSize(new Dimension(700,500));
			setResizable(false);
			//setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			setLocationRelativeTo(MainFrame.getInstance());
			setVisible(true);
			setLayout(new BorderLayout());
			
			setModal(true);
			getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
			createTabbedPane(s,this);
			setVisible(true);
		}
		
		
		private JPanel Informacije; //klasa sa TableTab metodama
		private JTable Polozeni;
		private JTable spisakNepolozenih;
		private JTable spisakDaPolozi;
		private JPanel Nepolozeni;
		private JTabbedPane tabbedPane;
		
		public JTabbedPane getTabbedPane() {
			return tabbedPane;
		}	
		public int selectedTab() {
			return tabbedPane.getSelectedIndex();
		}

//------Tabela Polozenih--------------------------------------------------------------------------------------------
		private JScrollPane prikaziTabeluPolozenihPredmeta(Student s) {
			
			
			//moram provjeriti da student nema isti predmet vise puta	
			//ODJE KRE
			//tabela polozeni
			//Polozeni = new PolozeniPredmetiTable(MainFrame.getInstance().selectedStudent());// TREBA MI ODABRANI STUDENT
			Polozeni = new PolozeniPredmetiTable(s);
			JScrollPane scrollPane3 = new JScrollPane(Polozeni);
			//pa od nje napravi scrollpane
			this.azurirajPrikazPolozeni(null, -1);
			
			return scrollPane3;
		}

		public void azurirajPrikazPolozeni(Object object, int i) {

			
			AbstractTableModelPolozeniPredmet model = (AbstractTableModelPolozeniPredmet) Polozeni.getModel();
			model.fireTableDataChanged();
			validate();
		}

//------------Tabela Nepolozenih---------------------------------------------------------------------------------------------------------
		private JPanel prikaziTabeluNepolozenihPredmeta(Student s,EditStudentDialog eds) {
			//ovaj prosledjeni student se moze zakomentarisati valjda
			Student prosledjenStudent = s;
			//setLayout(new BorderLayout());
			GridBagLayout gb = new GridBagLayout();
			JPanel panel = new JPanel(gb);
			//panel.setSize(new Dimension(700,500));
			//add(panel,BorderLayout.CENTER);
			//////////////////////////////////////////////////////////////
			
			
		
			/////////////////////////////////////////////////////////////// staticko popunjavanje tabele radi provjere
			
			
			
			spisakNepolozenih = new NepolozeniPredmetiTable(MainFrame.getInstance().selectedStudent());
			//PRAVLJENJE VIZUELNOG PRIKAZA
			//KOMPONENTE
			JScrollPane scrollPane = new JScrollPane(spisakNepolozenih);
			scrollPane.setVisible(true);
			this.azurirajPrikazNepolozenih(null, -1);
					
			//BUTTONS
			JButton dodaj = new JButton();
			dodaj.setText("Dodaj");
			JButton ukloni = new JButton();
			ukloni.setText("Ukloni");
			JButton polaganje = new JButton();
			polaganje.setText("Polaganje");
			
			
			//GRIDBAGLAYOUT 
			GridBagConstraints gc = new GridBagConstraints(0, 0, 1,
					1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(0, 30, 0, 10), 0, 0);
			panel.add(dodaj,gc);
			
			GridBagConstraints gc3 = new GridBagConstraints(1, 0, 1,
					1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(0, 10, 0, 10), 0, 0);
			panel.add(ukloni,gc3);
			
			GridBagConstraints gc4 = new GridBagConstraints(2, 0, 1,
					1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(0, 10, 0, 10), 0, 0);
			panel.add(polaganje,gc4);
			
			
			GridBagConstraints gc1 = new GridBagConstraints(0, 1, 5,
					5, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(15, 30, 30, 30), 600, 270);
			panel.add(scrollPane,gc1);
			Window parent = SwingUtilities.getWindowAncestor(this);
			ActionListener listenerPolaganje = new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					if(spisakNepolozenih.getSelectedRow() <0)
					{
						//JOptionPane.showMessageDialog(parent, "Morate  selektovati nepoloženi predmet!");
					//zasto je ovo zakomentarisano ?
					
					}else {
						//selektovani predmet
						
						Predmet predmet = prosledjenStudent.getSpisakNepolozenihIspita().get(spisakNepolozenih.getSelectedRow());
						UpisOceneDialog u = new UpisOceneDialog(predmet,prosledjenStudent,eds);
						
					}
					
				}
			};
			polaganje.addActionListener(listenerPolaganje);
				//-----------------------------------------------------------------
	
		ActionListener listenerDodaj = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//treba mi ovdje da otvori listu predmeta koji se mogu dodati
				JButton dodaj1 = new JButton();
				dodaj1.setText("Dodaj");
				JButton odustani1 = new JButton();
				odustani1.setText("Odustani");
				
				GridBagLayout gb = new GridBagLayout();
				JPanel panel1 = new JPanel(gb);
				
				JDialog x= new JDialog();
				
				JScrollPane polaganje= prikaziTabeluPredmetaDaPolozi(s);
				
				

				ActionListener listenerDodaj1 = new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						if(spisakDaPolozi.getSelectedRow() <0)
						{
							//Ali mi zatvori dijalog
							JOptionPane.showMessageDialog(x, "Morate  selektovati nepoloženi predmet!");
							
						
						
						}else {
							
							StudentiController.getInstance().azurirajListuNepolozenihPredmeta(s, spisakDaPolozi.getSelectedRow(), eds);
						}
						
					}
				};
				dodaj1.addActionListener(listenerDodaj1);
				
				ActionListener listenerOdustani1 = new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						
					//	dispose(); ovo mi ukine editovanje studenta
						x.dispose();
					}
				};
				odustani1.addActionListener(listenerOdustani1);
				
				
				x.setTitle("Editovanje Studenta");
				x.setSize(new Dimension(400,400));
				x.setLocationRelativeTo(parent);
				x.getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
				
				GridBagConstraints gc = new GridBagConstraints(0, 0, 1,
						1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(0, 30, 0, 10), 0, 0);
				panel1.add(dodaj1,gc);
				GridBagConstraints gc1 = new GridBagConstraints(2, 0, 1,
						1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(0, 10, 0, 10), 0, 0);
				panel1.add(odustani1,gc1);
				
				
				GridBagConstraints gc2 = new GridBagConstraints(0, 1, 5,
						5, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(15, 30, 30, 30), 300, 270);
				panel1.add(polaganje,gc2);
			
				x.add(panel1);
				
				
				
				x.setVisible(true);
				
				
			}
		};
		dodaj.addActionListener(listenerDodaj);

		
		
		ActionListener listenerUkloni = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(spisakNepolozenih.getSelectedRow() <0)
				{
					//JOptionPane.showMessageDialog(parent, "Morate izabrati predmet!");
					
				
				
				}else {
					
					Object[] options = {"Yes, please",
                    "No way!"};
					int n = JOptionPane.showOptionDialog(master,
					    "Would you like green eggs and ham?",
					    "A Silly Question",
					    JOptionPane.YES_NO_OPTION,
					    JOptionPane.QUESTION_MESSAGE,
					    null,     //do not use a custom Icon
					    options,  //the titles of buttons
					    options[0]); //default button title
					
					if(n	== JOptionPane.YES_OPTION) {
						StudentiController.getInstance().uklanjanjePredmetaSaStudenta(s,spisakNepolozenih.getSelectedRow(),eds);
					}else {
					    
					}
					
					
				}
				
			}
		};
		ukloni.addActionListener(listenerUkloni);
		
		
		
		
		
		
		
		
		
		return panel;
	}
		
		
		
		
		
		
	public void azurirajPrikazNepolozenih(Object object, int i) {
				AbstractTableModelNepolozeniPredmeti model = (AbstractTableModelNepolozeniPredmeti) spisakNepolozenih.getModel();
				model.fireTableDataChanged();
				validate();
				
			}
	
	
	
	private JScrollPane prikaziTabeluPredmetaDaPolozi(Student s) {
		
		
		//moram provjeriti da student nema isti predmet vise puta	
		//ODJE KRE
		//tabela polozeni
		//Polozeni = new PolozeniPredmetiTable(MainFrame.getInstance().selectedStudent());// TREBA MI ODABRANI STUDENT
		spisakDaPolozi= new SpisakPredmetaDaPolazeTable(s);
		JScrollPane scrollPane3 = new JScrollPane(spisakDaPolozi);
		//pa od nje napravi scrollpane
		this.azurirajPrikazPredmetaDaPolozi(null, -1);
		
		return scrollPane3;
	}

	public void azurirajPrikazPredmetaDaPolozi(Object object, int i) {

		
		AbstractTableModelSpisakPredmetaDaPolaze model = (AbstractTableModelSpisakPredmetaDaPolaze) spisakDaPolozi.getModel();
		model.fireTableDataChanged();
		validate();
	}

	
	
	
	
	
	
	
	
	
//-----------------------------------------------------------------------------------------------------
		
		private void createTabbedPane(Student s,EditStudentDialog eds) {
			tabbedPane = new JTabbedPane();
			
			//informacije
			Informacije =  new InformacijeStudent(s);
			//polozeni panel
			JScrollPane Polozeni= prikaziTabeluPolozenihPredmeta(s);
			JPanel PolozeniFinal= new PolozeniPredmetiPanel(Polozeni, s,eds);
			//nepolozeni panel
			
			Nepolozeni= prikaziTabeluNepolozenihPredmeta(s,eds);
		
			
			
			
			//dodajem tabove
			tabbedPane.addTab("Informacije", Informacije);
			tabbedPane.addTab("Polozeni", PolozeniFinal);
			tabbedPane.addTab("Nepolozeni", Nepolozeni);
			
			this.setLocationRelativeTo(rootPane);
			add(tabbedPane,BorderLayout.CENTER);
					
}
	
}

