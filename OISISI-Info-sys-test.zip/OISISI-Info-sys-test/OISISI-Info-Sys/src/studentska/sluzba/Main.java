package studentska.sluzba;

import gui.MainFrame;
import model.BazaPredmeta;
import model.BazaProfesora;
import model.BazaStudenata;

public class Main {

	public static void main(String[] args) {
		MainFrame.getInstance();
		//BazaProfesora.getInstance();
	}

}
