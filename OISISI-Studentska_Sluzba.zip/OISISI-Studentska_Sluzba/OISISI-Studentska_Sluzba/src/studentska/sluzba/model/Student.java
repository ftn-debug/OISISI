package studentska.sluzba.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

public class Student implements Serializable {

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public enum Status{ B, S};
	
	private String prezime;
	private String ime;
	private Date datumRodjenja;
	private String adresa;
	private String kontaktTelefon;
	private String eMail;
	private String brIndeksa;
	private int godinaUpisa;
	private int trenutnaGodinaStudija;
	private Status status;
	private double prosecnaOcena;
	private ArrayList<Ocena> spisakPolozenihIspita;
	private ArrayList<Predmet> spisakNepolozenihIspita;
	//Spisak nepolozenih ispita
	//Novo obiljezje
		//lista predmeta koje moze da polaze
	private ArrayList<Predmet> spisakPredmetaDaPolaze;
	
	
	public Student(String ime, String prezime, Date datumRodjenja, String adresa, String kontaktTelefon, String eMail,
			String brIndeksa, int godinaUpisa, int trenutnaGodinaStudija, Status status, double prosecnaOcena) {
		super();
		this.prezime = prezime;
		this.ime = ime;
		this.datumRodjenja = datumRodjenja;
		this.adresa = adresa;
		this.kontaktTelefon = kontaktTelefon;
		this.eMail = eMail;
		this.brIndeksa = brIndeksa;
		this.godinaUpisa = godinaUpisa;
		this.trenutnaGodinaStudija = trenutnaGodinaStudija;
		this.status = status;
		this.prosecnaOcena = prosecnaOcena;
		this.spisakPolozenihIspita = new ArrayList<Ocena>(); 
		this.spisakNepolozenihIspita = new ArrayList<Predmet>(); 
		this.spisakPredmetaDaPolaze = new ArrayList<Predmet>();
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(Student entity) {
		
		this.prezime = entity.prezime;
		this.ime =  entity.ime;
		this.datumRodjenja =  entity.datumRodjenja;
		this.adresa =  entity.adresa;
		this.kontaktTelefon =  entity.kontaktTelefon;
		this.eMail =  entity.eMail;
		this.brIndeksa =  entity.brIndeksa;
		this.godinaUpisa =  entity.godinaUpisa;
		this.trenutnaGodinaStudija =  entity.trenutnaGodinaStudija;
		this.status =  entity.status;
		this.prosecnaOcena =  entity.prosecnaOcena;
		this.spisakPolozenihIspita = new ArrayList<Ocena>(); 
		this.spisakNepolozenihIspita = new ArrayList<Predmet>(); 
		this.spisakPredmetaDaPolaze = new ArrayList<Predmet>();
		
		
	}


	public String getPrezime() {
		return prezime;
	}
	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}
	public String getIme() {
		return ime;
	}
	public void setIme(String ime) {
		this.ime = ime;
	}
	public Date getDatumRodjenja() {
		return datumRodjenja;
	}
	public void setDatumRodjenja(Date datumRodjenja) {
		this.datumRodjenja = datumRodjenja;
	}
	public String getAdresa() {
		return adresa;
	}
	
	public void setAdresa(String adresa) {
		this.adresa = adresa;
	}
	public String getKontaktTelefon() {
		return kontaktTelefon;
	}
	public void setKontaktTelefon(String kontaktTelefon) {
		this.kontaktTelefon = kontaktTelefon;
	}
	public String geteMail() {
		return eMail;
	}
	public void seteMail(String eMail) {
		this.eMail = eMail;
	}
	public String getBrIndeksa() {
		return brIndeksa;
	}
	public void setBrIndeksa(String brIndeksa) {
		this.brIndeksa = brIndeksa;
	}
	public int getGodinaUpisa() {
		return godinaUpisa;
	}
	public void setGodinaUpisa(int godinaUpisa) {
		this.godinaUpisa = godinaUpisa;
	}
	public int getTrenutnaGodinaStudija() {
		return trenutnaGodinaStudija;
	}
	public void setTrenutnaGodinaStudija(int trenutnaGodinaStudija) {
		this.trenutnaGodinaStudija = trenutnaGodinaStudija;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	
	public double getProsecnaOcena() {
		return this.prosecnaOcena;
	}
	public double getProsecnaOcena(Student s) {
		if(s.spisakPolozenihIspita == null) {
			return 0;
		}else {
		return setProsecnaOcenaFunction(s.spisakPolozenihIspita);
	}}
	public void setProsecnaOcena(double prosecnaOcena) {
		this.prosecnaOcena = prosecnaOcena;
	}

	public ArrayList<Ocena> getSpisakPolozenihIspita() {
		
		return spisakPolozenihIspita;
	}
	public void setSpisakPolozenihIspita(ArrayList<Ocena> spisakPolozenihIspita) {
		
		this.spisakPolozenihIspita = spisakPolozenihIspita;
	}
	private double setProsecnaOcenaFunction(ArrayList<Ocena> spisakPolozenihIspita) {
		double s=0;
		double br=0;
		double avg=0;
		for(Ocena o: spisakPolozenihIspita) {
			s+=o.getVijrednostOceneToInt(o.getVijrednostOcene());
			br++;
		}
		if(br>0) {
		avg=s/br;
		
		this.prosecnaOcena=avg;
		return avg;
		}
		return 0;
	}

	public ArrayList<Predmet> getSpisakNepolozenihIspita() {
		return spisakNepolozenihIspita;
	}
	public void setSpisakNepolozenihIspita(ArrayList<Predmet> spisakNepolozenihIspita) {
		
		this.spisakNepolozenihIspita = spisakNepolozenihIspita;
	}

	@Override
	public String toString() {
		return "Student [prezime=" + prezime + ", ime=" + ime + ", datumRodjenja=" + datumRodjenja + ", adresa="
				+ adresa + ", kontaktTelefon=" + kontaktTelefon + ", eMail=" + eMail + ", brIndeksa=" + brIndeksa
				+ ", godinaUpisa=" + godinaUpisa + ", trenutnaGodinaStudija=" + trenutnaGodinaStudija + ", status="
				+ status + ", prosecnaOcena=" + prosecnaOcena + "]";
	}

	public int getEspb(Student s) {
		ArrayList<Ocena> polozeni= s.getSpisakPolozenihIspita();
		int espb=0;
		for(Ocena o: polozeni ) {
			espb+=o.getPredmet().getBrESPBbodova();
		}
		
		return espb;
	}
	public void setSpisakPredmetaDaPolaze(ArrayList<Predmet> spisakPredmetaDaPolaze) {
		
		this.spisakPredmetaDaPolaze = spisakPredmetaDaPolaze;
	}

	public ArrayList<Predmet> getSpisakPredmetaDaPolaze() {
		
	
			return spisakPredmetaDaPolaze;	
		
		
	}

	public double getProsecnaOcenaO() {
		return this.prosecnaOcena;
	}
	
	
	
}
