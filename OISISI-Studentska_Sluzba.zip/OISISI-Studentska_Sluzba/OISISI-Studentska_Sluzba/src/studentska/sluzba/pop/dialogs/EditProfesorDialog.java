package studentska.sluzba.pop.dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;

import studentska.sluzba.controller.ProfesorController;
import studentska.sluzba.gui.AbstractTableModelPredmetiProfesora;
import studentska.sluzba.gui.AbstractTableModelPredmetiZaProfesora;
import studentska.sluzba.gui.InformacijeProfesora;
import studentska.sluzba.gui.MainFrame;
import studentska.sluzba.gui.PredmetiProfesoraTable;
import studentska.sluzba.gui.PredmetiZaProfesoraTable;
import studentska.sluzba.model.Predmet;
import studentska.sluzba.model.Profesor;

public class EditProfesorDialog  extends JDialog{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EditProfesorDialog(Profesor profesor) {
		super();
		Toolkit tk = java.awt.Toolkit.getDefaultToolkit();
		setTitle("Editovanje Profesora");
		setSize(new Dimension(700,500));
		setResizable(false);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(MainFrame.getInstance());
		setVisible(true);
		setLayout(new BorderLayout());
		
		setModal(true);
		getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
		createTabbedPaneProfesor(profesor,this);
		setVisible(true);
		
	}
	private JPanel InformacijeOProfesoru;
	private JPanel ListaPredmetaProfesora;
	private JTabbedPane tabPane;
	private JTable predmetiProfesora;
	private JTable predmetiZaDodati;
	
	public JTabbedPane getTabPane() {
		return tabPane;
	}
	
	public int tabSelectedInProfesor() {
		return tabPane.getSelectedIndex();
	}
	
	
	private JPanel prikaziTabeluPredmetaProfesora(Profesor p,EditProfesorDialog edp ) {
		//Profesor prosledjenProfesor = p;
		GridBagLayout gb = new GridBagLayout();
		JPanel panel = new JPanel(gb);
		
		predmetiProfesora = new PredmetiProfesoraTable(MainFrame.getInstance().selektovaniProfesor());
		
		JScrollPane scrollPane = new JScrollPane(predmetiProfesora);
		scrollPane.setVisible(true);
		this.azurirajPrikazPredmetaProfesora(null, -1);
		
		JButton dodaj = new JButton();
		dodaj.setText("Dodaj predmet");
		JButton ukloni = new JButton();
		ukloni.setText("Ukloni predmet");
		
		GridBagConstraints gc = new GridBagConstraints(0, 0, 1,
				1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(0, 30, 0, 10), 0, 0);
		panel.add(dodaj,gc);
		
		GridBagConstraints gc1 = new GridBagConstraints(1, 0, 1,
				1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(0, 10, 0, 10), 0, 0);
		panel.add(ukloni,gc1);
		
		GridBagConstraints gc2 = new GridBagConstraints(0, 1, 5,
				5, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(15, 30, 30, 30), 600, 270);
		panel.add(scrollPane,gc2);
		
		Window parent = SwingUtilities.getWindowAncestor(this);;
		
		ActionListener dodajListener = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				JButton potvrdi = new JButton();
				potvrdi.setText("Potvrdi");
				JButton odustani = new JButton();
				odustani.setText("Odustani");
				JLabel naslov = new JLabel();
				naslov.setText("Predmeti:");
				
				
				GridBagLayout gb = new GridBagLayout();
				JPanel panel1 = new JPanel(gb);
				//panel1.setVisible(true);
				
				JDialog dodajPred = new JDialog();
				dodajPred.setSize(new Dimension(400,300));
				dodajPred.setLocationRelativeTo(parent);
				dodajPred.setTitle("Dodaj predmet");
				
				JScrollPane scrollPane1 = prikaziTabeluPredmetiZaProfesora(p);
				scrollPane1.setSize(new Dimension(340,200));
				
				GridBagConstraints gc3 = new GridBagConstraints(0, 0, 1,
						1, 0, 0,  GridBagConstraints.WEST,  GridBagConstraints.NONE,  new Insets(0, 30, 0, 0),  0, 0);
				panel1.add(naslov,gc3);
				
				GridBagConstraints gc2 = new GridBagConstraints(0, 1, 5,
						5, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(10, 30, 10, 30),  300, 130);
				panel1.add(scrollPane1,gc2);
				
				
				GridBagConstraints gc = new GridBagConstraints(0, 6, 1,
						1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(0, 182, 0, 10), 0, 0);
				panel1.add(potvrdi,gc);
				
				GridBagConstraints gc1 = new GridBagConstraints(1, 6, 1,
						1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.NONE,  new Insets(0, 0, 0, 10), 0, 0);
				panel1.add(odustani,gc1);
				
				
				ActionListener potvrdiDodavanje = new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						//ako nije selektovan predmet poruka,ako jeste da ga doda na listu predmeta koje predaje u bazi 
						if(predmetiZaDodati.getSelectedRow()<0)
						{
							JOptionPane.showMessageDialog(parent, "Morate  selektovati  predmet!");
						}else {
							//selektovan predmet
							Predmet predmet = p.getMoguciPredmeti().get(predmetiZaDodati.getSelectedRow());
							//prosledjujem ga kontroleru profesora 
							ProfesorController.getInstance().dodajPredmetProfesoru(p,predmet,edp);
							//gde cu da ga pprosledim bazi
							//gde su da ga uklonim sa jedne liste i dodam na drugu 
							edp.azurirajPrikazPredmetaProfesora(null, -1);
							edp.azurirajPrikazPredmetaZaDodati(null, -1);
							dodajPred.dispose();
						}
					}
				};
				
				potvrdi.addActionListener(potvrdiDodavanje);
				
				ActionListener odustaniDodavanje = new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
					dodajPred.dispose();
						
					}
				};
				odustani.addActionListener(odustaniDodavanje);
				
				dodajPred.add(panel1);
				dodajPred.setVisible(true);
			
			}
		};
		dodaj.addActionListener(dodajListener);
		
		ActionListener ukloniListener = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				
			}
		};
		ukloni.addActionListener(ukloniListener);
		
		return panel;
		}
	
	
	
	public void azurirajPrikazPredmetaProfesora(Object object, int i) {
		AbstractTableModelPredmetiProfesora model = (AbstractTableModelPredmetiProfesora) predmetiProfesora.getModel();
		model.fireTableDataChanged();
		validate();
	}
	
	public void createTabbedPaneProfesor(Profesor profesor,EditProfesorDialog edp) {
		tabPane = new JTabbedPane();
		InformacijeOProfesoru = new InformacijeProfesora(profesor);
		ListaPredmetaProfesora =  prikaziTabeluPredmetaProfesora(profesor, edp);
		
		tabPane.addTab("Informacije", InformacijeOProfesoru);
		tabPane.addTab("Predmeti", ListaPredmetaProfesora);
		
		
		this.setLocationRelativeTo(rootPane);
		add(tabPane,BorderLayout.CENTER);
	}
	
	public void close() {
		dispose();
	}
	
	private JScrollPane prikaziTabeluPredmetiZaProfesora(Profesor p) {
		
		predmetiZaDodati = new PredmetiZaProfesoraTable(p);
		//predmetiZaDodati.setSize(new Dimension(340,200));
		JScrollPane sp = new JScrollPane(predmetiZaDodati);
		this.azurirajPrikazPredmetaZaDodati(null, -1);
		return sp;
	}
	
	public void azurirajPrikazPredmetaZaDodati(Object object, int i) {

		
		AbstractTableModelPredmetiZaProfesora model = (AbstractTableModelPredmetiZaProfesora) predmetiZaDodati.getModel();
		model.fireTableDataChanged();
		validate();
	}
	
	
}
