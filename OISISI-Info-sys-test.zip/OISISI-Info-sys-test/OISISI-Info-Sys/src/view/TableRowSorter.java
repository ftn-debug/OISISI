package view;

import javax.swing.DefaultRowSorter;
import javax.swing.table.TableModel;

public class TableRowSorter <M extends TableModel> extends DefaultRowSorter<M,Integer> {

}
