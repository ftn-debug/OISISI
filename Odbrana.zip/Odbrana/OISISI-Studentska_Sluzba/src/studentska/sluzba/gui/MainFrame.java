package studentska.sluzba.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.Serializable;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;

import studentska.sluzba.model.BazaPredmeta;
import studentska.sluzba.model.BazaProfesora;

import studentska.sluzba.model.Predmet;

import studentska.sluzba.model.BazaStudenata;

import studentska.sluzba.model.Profesor;
import studentska.sluzba.model.Student;
import studentska.sluzba.view.AbstractTableModelPredmet;
import studentska.sluzba.view.AbstractTableModelProfesor;
import studentska.sluzba.view.AbstractTableModelStudent;
import studentska.sluzba.view.PredmetiJTable;
import studentska.sluzba.view.ProfesoriJTable;
import studentska.sluzba.view.StudentiJTable;




//import sun.jvm.hotspot.ui.table.SortableTableModel;
/**
 * Singleton klasa koja nasljedjuje klasu JFrame i podloga je za GUI.
 * Sadrzace tabele(JTable) entiteta Student, Predmet i Profesor.
 * @author Maja Blagic
 *
 */
public class MainFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JTable tabelaProfesori;
	private JTable tabelaStudenti;
	private JTable tabelaPredmeti; 
	
	private JTabbedPane tabbedPane;
	
	private static MainFrame instance = null;
	/**
	 * 
	 * @return instanca MainFrame-a
	 */
	public static MainFrame getInstance() {
		if(instance == null) {
			instance = new MainFrame();
		}
		return instance;
	}
	
	
	

	public MainFrame() {
		super();
		//
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize = kit.getScreenSize();
		int screenHeight = screenSize.height;
		int screenWidth =screenSize.width;
		setSize(screenWidth*3/4,screenHeight*3/4);
		setTitle("Studentska sluzba");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
		setLayout(new BorderLayout());
		//
		JPanel panBars=new JPanel();
		panBars.setBackground(Color.LIGHT_GRAY);
		panBars.setPreferredSize(new Dimension(60,60));
		add(panBars,BorderLayout.NORTH);		
		panBars.setLayout(new BorderLayout());
		
		
		ToolBar toolbar =  new ToolBar();
		toolbar.setPreferredSize(new Dimension(this.getWidth(),35));
		panBars.add(toolbar,BorderLayout.SOUTH);
		
		
		MenuBar menuBar =  new MenuBar();
		menuBar.setPreferredSize(new Dimension(25,25));
		panBars.add(menuBar,BorderLayout.NORTH);
		
		StatusBar statusLine =  new StatusBar();
		statusLine.setPreferredSize(new Dimension(this.getWidth(),20));
        add(statusLine,BorderLayout.SOUTH);
        
        //umesto ovog da  napravim objekat klase tabbed pane i dodam na cenntar ??? 
        createTabbedPane();
       
        //***************************************

		
		this.addWindowListener(new WindowListener() {
			
			@Override
			public void windowOpened(WindowEvent e) {

			
				//BazaPredmeta.getInstance().deserijalizacijaPredmeta();
				//BazaStudenata.getInstance().deserijalizacijaStudenta();
				//BazaProfesora.getInstance().deserijalizacijaProfesora();
				//System.out.println("ulazak");
				//azurirajPrikazProfesora(null, -1);
				
			}
			
			@Override
			public void windowIconified(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void windowDeiconified(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void windowDeactivated(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void windowClosing(WindowEvent e) {
				
				// TODO Auto-generated method stub
				BazaProfesora.getInstance().serijalizacijaProfesora();
				BazaPredmeta.getInstance().serijalizacijaPredmeta();
				BazaStudenata.getInstance().serijalizacijaStudenata();
				//azurirajPrikazProfesora(null, -1);
			
				
			}
			
			@Override
			public void windowClosed(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void windowActivated(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		setVisible(true);	
		
		
				
	}
	
	public JTabbedPane getTabbedPane() {
		return tabbedPane;
	}	
	public int selectedTab() {
		return tabbedPane.getSelectedIndex();
	}

	public JTable getTabelaStudenti(){
		 return tabelaStudenti;
	 }
	 public JTable getTabelaPredmeti() {
		return tabelaPredmeti;
	}
	 public JTable getTabelaProfesori() {
		return tabelaProfesori;
	}
	
	/**
	 * Metoda koja pri promjeni Baze Profesora azurira njen prikaz u aplikaciji.
	 * @param akcija - unused
	 * @param vrednost -unused
	 */
	public void azurirajPrikazProfesora(String akcija,int vrednost) {
		AbstractTableModelProfesor model = (AbstractTableModelProfesor) tabelaProfesori.getModel();
		model.fireTableDataChanged();
		validate();
	}
	
	/**
	 * Metoda koja pri promjeni Baze Studenta azurira njen prikaz u aplikaciji.
	 * @param akcija unused
	 * @param vrednost unused
	 */
	public void azurirajPrikazStudenta(String akcija,int vrednost) {
		AbstractTableModelStudent model = (AbstractTableModelStudent) tabelaStudenti.getModel();
		model.fireTableDataChanged();
		validate();
	}
	/**
	 * Metoda koja pri promjeni Baze Prdmeta azurira njen prikaz u aplikaciji.
	 * @param string unused
	 * @param i unused
	 */
	public void azurirajPrikazPredmet(String string, int i) {
		AbstractTableModelPredmet model = (AbstractTableModelPredmet) tabelaPredmeti.getModel();
		model.fireTableDataChanged();
		validate();

		
	}
	
	
	private JScrollPane prikaziTabeluProfesora() {
		tabelaProfesori = new ProfesoriJTable();
		JScrollPane scrollPane2 = new JScrollPane(tabelaProfesori);
		this.azurirajPrikazProfesora(null, -1);
		
		return scrollPane2;
	}
	/**
	 * Metoda koja poziva klasu StudentiJTable . Tako kreira tabelu studenata i smjesta je u ScrollPane
	 * @return ScrollPane koji sadrzi Tabelu Studenta iz Baze Studenata
	 */
	private JScrollPane prikaziTabeluStudenata() {
		tabelaStudenti = new StudentiJTable();
		
		JScrollPane scrollPane1 = new JScrollPane(tabelaStudenti);
		this.azurirajPrikazStudenta(null, -1);
		
		return scrollPane1;
	}
	private JScrollPane prikaziTabeluPredmeta() {

		tabelaPredmeti = new PredmetiJTable();
		JScrollPane scrollPane3 = new JScrollPane(tabelaPredmeti);
		this.azurirajPrikazPredmet(null	, -1);
		
		return scrollPane3;
		
	}


/**
 * Metoda koja na svaki Tab container stavlja odgovarajucu Tabelu. Zauzima centralni dio Main Frame-a.
 * Tabela Studenta/Predmeta/Profesora. 
 */
	private void createTabbedPane() {
		tabbedPane = new JTabbedPane();
		
		JScrollPane profesoriTab = prikaziTabeluProfesora();
		JScrollPane studentiTab = prikaziTabeluStudenata();
		JScrollPane predmetiTab = prikaziTabeluPredmeta();
		
		tabbedPane.addTab("Studenti", studentiTab);
		tabbedPane.addTab("Profesori", profesoriTab);
		tabbedPane.addTab("Predmeti", predmetiTab);
		
		add(tabbedPane,BorderLayout.CENTER);
		
	}

	public Profesor selektovaniProfesor() {
		Profesor prof = null;
		if(tabelaProfesori.getSelectedRow() < 0) {
			return null;
		}
		///Posto mi autosorter samo sortira view ,a ne sortira bazu
		//Ovdje konvertujem iz view u bazu
		//treba konvertovari jer se selektuje tabelaStudenti.getSelectedRow()
		int viewRowIndex= tabelaPredmeti.getSelectedRow();
		int modelRowIndex=tabelaPredmeti.convertRowIndexToModel(viewRowIndex);
		prof = BazaProfesora.getInstance().getRow(tabelaProfesori.getSelectedRow());
		return prof;
	}
	
	public int selectedProfesorRow() {
		
		return tabelaProfesori.getSelectedRow();
	}
	/**
	 * Klasa  koja vraca predmet na osvu selektovanog reda u tabeli.
	 * @return predmet
	 */
	public Predmet selectedPredmet() {
		Predmet p= null;
		if(tabelaPredmeti.getSelectedRow() < 0) {
			return null;
		}
		
		p=BazaPredmeta.getInstance().getRow(tabelaPredmeti.getSelectedRow());
		return p;
	}

	/**
	 * Klasa  koja vraca Studenta na osvu selektovanog reda u tabeli.
	 * U slucaju da se vrse modifikacije nad izgledom tabele potrebno je usloviti bazu da prati te promjene.
	 * Metoda koje sluzi za konvertovanje convertRowIndexToModel
	 * @return entitet student
	 */
	public Student selectedStudent() {

		Student s= null;
		if(tabelaStudenti.getSelectedRow() < 0) {
			return null;
		}
		//Posto mi autosorter samo sortira view ,a ne sortira bazu
		//Ovdje konvertujem iz view u bazu
		//treba konvertovari jer se selektuje tabelaStudenti.getSelectedRow()
		int viewRowIndex= tabelaStudenti.getSelectedRow();
		int modelRowIndex=tabelaStudenti.convertRowIndexToModel(viewRowIndex);
		
		s= BazaStudenata.getInstance().getRow(modelRowIndex);
		
		return s;

	}


	

}
