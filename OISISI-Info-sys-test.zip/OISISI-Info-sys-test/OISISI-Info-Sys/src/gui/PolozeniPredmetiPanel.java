package gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;

import controller.StudentiController;
import model.Student;
import pop.dialogs.EditStudentDialog;

//link:https://stackoverflow.com/questions/5764467/get-component-from-a-jscrollpane

public class PolozeniPredmetiPanel extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	 static JLabel prosjecnaOcjenaL;
	 static JLabel ukupnoEspbL;
	
	
	public PolozeniPredmetiPanel(JScrollPane polozeniScroll,Student s, EditStudentDialog eds) {
	
	
	setName("Editovanje predmeta");
	prosjecnaOcjenaL= new JLabel("Prosjecna ocjena "+" :  "+s.getProsecnaOcena());
	ukupnoEspbL= new JLabel("Ukupno ESPB bodova"+" :  "+s.getEspb(s));
	JButton button= new JButton("Ponisti ocjenu");
	

	
	
	
	

	 Window parent = SwingUtilities.getWindowAncestor(this);
	ActionListener ok = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {

			JViewport viewport = polozeniScroll.getViewport(); //source link
			JTable myTable = (JTable)viewport.getView();
			
			//JTable table= (JTable) polozeniScroll.getAccessibleContext();
			if(myTable.getSelectedRow() == -1) {
				//i ovdje greska
				JOptionPane.showMessageDialog(parent, "Morate  selektovati polozeni predmet!");
				
			}else {
	
			StudentiController.getInstance().ponistiOcenu(s,myTable.getSelectedRow(),eds);
			
			}
			
		}};
	
	button.addActionListener(ok);
	
	
	
/*	
	button.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
		
			
			
			//trebam ovdje da ponisti 
			//Kada se uspešno poništi ocena, predmet se iz tabele položenih predmeta prebacuje u tabelu
			//nepoloženih predmeta
			
			//posto je ovo izmjena u bazi je l te ,treba preko kontrolera
			//izbrisem is polozeni i stavim u nepolozeni
		//	s.getSpisakPolozenihIspita().get(polozeniScroll)
			
			JViewport viewport = polozeniScroll.getViewport(); //source link
			JTable myTable = (JTable)viewport.getView();
			
			//JTable table= (JTable) polozeniScroll.getAccessibleContext();
			if(myTable.getSelectedRow() == -1) {
				//i ovdje greska
			//	JOptionPane.showMessageDialog(MainFrame.getInstance(), "Morate  selektovati polozeni predmet!");
				
			}else {
	
			StudentiController.getInstance().ponistiOcenu(s,myTable.getSelectedRow(),eds);
			
			}
			
			
			
		//	PonistiOcenuDialog dpd= new PonistiOcenuDialog();
		
			//JDialog x= new JDialog();
		/*	Object[] options = { "Da", "Ne" };
			//JOptionPane optionPane = new JOptionPane();
			int opcija = JOptionPane.showOptionDialog(null,"Da li ste sigurni da želite da \n "
				    + "ponistite predmet?", "Brisanje predmeta.",
			    JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
			    null, options, options[1]);
			
			if(opcija == JOptionPane.YES_OPTION) {
				System.out.println("Brisanje predmeta");
			}
			
		
			int opcija=JOptionPane.showConfirmDialog(null,
					"choose one", "choose one", JOptionPane.YES_NO_OPTION);
			if(opcija == JOptionPane.YES_OPTION) {
				//It does write this out on the console
				//but it freezes the program whether I click yes or no!
					System.out.println("Action performed");
				}
			x.setLocationRelativeTo(null);
			x.setSize(new Dimension(250,150));
			x.setResizable(false);
			x.setModal(true);
			
			//.setPopupPosition(200, 200).setAutoHideEnabled(true);
			
			x.setLocationRelativeTo(MainFrame.getInstance());
			x.getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
			
			//Component component = (Component) e.getSource();
			///JDialog dialog = (JDialog) SwingUtilities.getRoot(component);
			//dialog.dispose();
			
	
			
		}
	});*/
	

	setLayout(button,polozeniScroll);
	}
	
	
	private void setLayout(JButton button, JScrollPane polozeniScroll) {
	
		setLayout(new GridBagLayout());
		
	
		GridBagConstraints gbc= new GridBagConstraints();
		//gbc.fill= GridBagConstraints.HORIZONTAL;
		gbc.weightx=0.5;
		gbc.weighty=0.5;
		gbc.gridwidth=3;
		gbc.gridx = 0;
		gbc.gridy = 0;
		
		gbc.insets = new Insets(20, 30, 15, 0);
		gbc.anchor=GridBagConstraints.LINE_START;
		add(button,gbc);
	
	/*zauzima tri ćelije gridx=0, gridy=4, weightx=100, weighty=100, fill=both*/
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth=5;
		//gbc.ipady = 40; 
		
		gbc.weightx=100;//
		gbc.weighty=100;
		gbc.fill=GridBagConstraints.BOTH;
		gbc.insets=new Insets(0,30,0,30);
		//gbc.anchor=GridBagConstraints.LINE_START;
		add(polozeniScroll,gbc);		
		
		gbc.ipady = 5;
		gbc.gridx = 20;
        gbc.gridwidth = 1;
		gbc.weightx = 0.25;
		gbc.weighty = 0.25;
        gbc.gridx = 4;
        gbc.gridy = 2;
        gbc.insets = new Insets(10, 0, 0, 30);
		gbc.fill = GridBagConstraints.NONE;
		//gbc.insets = new Insets(20, 20, 0, 0);
		gbc.anchor=GridBagConstraints.EAST;
		add(prosjecnaOcjenaL,gbc);
		
		gbc.ipady = 20;
		gbc.weightx = 0.25;
		gbc.weighty = 0.25;
        gbc.gridx = 4;
        gbc.gridy = 3;
        gbc.insets = new Insets(0, 0, 0, 30);
		//gbc.insets = new Insets(20, 20, 0, 0);
		gbc.anchor=GridBagConstraints.EAST;
		add(ukupnoEspbL,gbc);
		}


	
	}

