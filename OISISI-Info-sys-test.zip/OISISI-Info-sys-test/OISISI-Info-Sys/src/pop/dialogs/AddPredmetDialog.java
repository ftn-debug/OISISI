package pop.dialogs;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

import controller.PredmetiController;
import model.Predmet;
import model.Profesor;
import model.Student;
import model.Predmet.Semestar;
import model.Student.Status;

public class AddPredmetDialog extends JDialog implements ActionListener{

	/**
	 * 
	 */
	
	/*public enum Semestar{ZIMSKI,LETNJI};
	 * private String sifraPredmeta;
	private String nazivPredmeta;
	private Semestar semestar;
	private int godinaStudija; //na kojoj se predmet izvodi
	private Profesor predmetniProfesor;
	private int brESPBbodova;
	private ArrayList<Student> studentiPolozili;
	private ArrayList<Student> studentiNisuPolozili;*/
	
	private static final long serialVersionUID = 1L;
	static JLabel sifraPredmeta;
	static JLabel nazivPredmeta;
	static JLabel semestar;
	static JLabel godinaNaKojojSeIzvodi;
	static JLabel brESPBbodova;
	
	static JTextField poljeSifraPredmeta;
	static JTextField poljeNazivPredmeta;
	static JComboBox<Semestar> comboBoxSemestar;
	static JTextField poljeGodinaNaKojojSeIzvodi;
	static JTextField poljeBrESPBbodova;
	
	public AddPredmetDialog() {
		
		setTitle("Dodavanje predmeta");
		sifraPredmeta = new JLabel("Sifra predmeta*");
		nazivPredmeta = new JLabel("Naziv predmeta*");
		semestar = new JLabel("Semestar*");
		godinaNaKojojSeIzvodi = new JLabel("Godina na kojoj se izvodi*");
		brESPBbodova = new JLabel("Broj ESPB bodova*");
		
		poljeSifraPredmeta = new JTextField(15);
		poljeSifraPredmeta.setName("Sifra predmeta*");
		
		poljeNazivPredmeta = new JTextField(15);
		poljeNazivPredmeta.setName("Naziv predmeta*");
		
		poljeGodinaNaKojojSeIzvodi = new JTextField(15);
		poljeGodinaNaKojojSeIzvodi.setName("Godina na kojoj se izvodi*");
		
		poljeBrESPBbodova = new JTextField(15);
		poljeBrESPBbodova.setName("Broj ESPB bodova*");
		
		comboBoxSemestar = new JComboBox<>();
		comboBoxSemestar.setName("Semestar*");
		DefaultComboBoxModel<Semestar> t = new DefaultComboBoxModel<Semestar>();
		t.addElement(Semestar.LETNJI);
		t.addElement(Semestar.ZIMSKI);
		comboBoxSemestar.setModel(t);
		comboBoxSemestar.setSelectedIndex(0);
		comboBoxSemestar.setEditable(false);
		
		
		JButton okButton = new JButton("Potvrdi");
		JButton cancelButton = new JButton("Odustani");
		
		
		okButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Predmet predmet;
				try {
					predmet = collectData();
					
					if(predmet == null) {
						//JOptionPane.showMessageDialog(btnOK, "Morate validno popuniti sva polja!", "Pogresan unos", JOptionPane.ERROR_MESSAGE);
						okButton.setToolTipText("Morate uneti sva polja!");
						okButton.setBackground(Color.RED);
						okButton.setForeground(Color.WHITE);
						
					}else {
						if(PredmetiController.getInstance().uniqueSifraPredmeta(predmet))
						{
							PredmetiController.getInstance().dodajPredmet(predmet);
							//dispose();
						}else {
							okButton.setToolTipText(" Broj licne karte nije jedinstven!");
							okButton.setBackground(Color.RED);
							okButton.setForeground(Color.WHITE);
						}
						
					}
				}catch(ParseException pe) {
					pe.printStackTrace();
				}				
			}
		});
		
		cancelButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				
			}
		});
		
		
		setLayout(okButton,cancelButton);
		
		setLocationRelativeTo(null);
		setSize(new Dimension(500,500));
		setResizable(false);
		setModal(true);
		setLocationRelativeTo(getParent());
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
		
		setVisible(true);
		
	}
	
	
	private void setLayout(JButton okButton, JButton cancelButton) {
		setLayout(new GridBagLayout());
		
		GridBagConstraints gc=new GridBagConstraints();
		
		gc.weightx=0.01;
		gc.weighty=0.01;
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(20, 20, 0, 0);
		gc.fill=GridBagConstraints.NONE;
		gc.anchor=GridBagConstraints.LINE_START;
		
		add(sifraPredmeta,gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.anchor=GridBagConstraints.LINE_START;

		add(poljeSifraPredmeta,gc);
		//--------------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		
		gc.gridy = 1;
		gc.gridx = 0;
		gc.insets = new Insets(20, 20, 0, 0);
		gc.anchor=GridBagConstraints.LINE_START;
		add(nazivPredmeta,gc);
		

		gc.gridy = 1;
		gc.gridx = 1;
		gc.anchor=GridBagConstraints.LINE_START;
		add(poljeNazivPredmeta,gc);
		//----------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		
		gc.gridy = 2;
		gc.gridx = 0;
		gc.insets = new Insets(20, 20, 0, 0);

		gc.anchor=GridBagConstraints.LINE_START;
		add(semestar,gc);
		

		gc.gridy = 2;
		gc.gridx = 1;
		gc.anchor=GridBagConstraints.LINE_START;

		add(comboBoxSemestar,gc);
		//---------------
		gc.weightx=0.01;
		gc.weighty=0.01;
		
		gc.gridy = 3;
		gc.gridx = 0;
		gc.anchor=GridBagConstraints.LINE_START;
		add(godinaNaKojojSeIzvodi,gc);
				
		gc.gridy = 3;
		gc.gridx = 1;
		gc.anchor=GridBagConstraints.LINE_START;
		add(poljeGodinaNaKojojSeIzvodi,gc);
		
		//PROVERITI
		gc.gridy = 4;
		gc.gridx = 0;
		gc.anchor=GridBagConstraints.LINE_START;
		add(brESPBbodova,gc);
				
		gc.gridy = 4;
		gc.gridx = 1;
		gc.anchor=GridBagConstraints.LINE_START;
		add(poljeBrESPBbodova,gc);
		

		gc.gridy = 5;
		gc.gridx = 1;
		gc.anchor=GridBagConstraints.LINE_START;
		add(okButton,gc);
				
		gc.gridy = 5;
		gc.gridx = 2;
		gc.anchor=GridBagConstraints.LINE_START;
		add(cancelButton,gc);
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	private Predmet collectData() throws ParseException {
			
			Predmet pred;
			pred = null;
			try {
			String sifra = poljeSifraPredmeta.getText();
			String naziv = poljeNazivPredmeta.getText();
			int godina = Integer.parseInt(poljeGodinaNaKojojSeIzvodi.getText());
			int espb = Integer.parseInt(poljeBrESPBbodova.getText());
			
			Semestar seme = (Semestar) comboBoxSemestar.getSelectedItem() ;
			//vrati objekat i onda ga kastujem u semestar
			
			if(sifra.equals("") || naziv.equals("") || 
					seme.equals(null) || poljeGodinaNaKojojSeIzvodi.getText().equals("") 
					|| poljeBrESPBbodova.getText().equals("")) {
				System.out.println("Error imput");
				return null;	
			}
			
			pred = new Predmet(sifra,naziv,seme,godina,espb);
			
					
			}catch (Exception e) {
				e.printStackTrace();
			}
			return pred;
		}
}
