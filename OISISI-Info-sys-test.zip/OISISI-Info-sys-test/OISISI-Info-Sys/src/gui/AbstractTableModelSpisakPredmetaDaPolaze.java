package gui;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

import model.Predmet;

public class AbstractTableModelSpisakPredmetaDaPolaze  extends AbstractTableModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<Predmet> listaPredmeta;
	private String[] kolone;
	
	public AbstractTableModelSpisakPredmetaDaPolaze(ArrayList<Predmet> predmeti) {
		super();
		listaPredmeta=predmeti;
		kolone = new String[]{"SIFRA PREDMETA","NAZIV PREDMETA"};
	}
	
	public String getColumnName(int column) {
		return kolone[column];
	}
	@Override
	public int getRowCount() {
		return listaPredmeta.size();
	}

	@Override
	public int getColumnCount() {
		return kolone.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Predmet predmet = listaPredmeta.get(rowIndex);
		
		switch (columnIndex) {
		case 0: 
			return predmet.getSifraPredmeta();
		case 1:
			return predmet.getNazivPredmeta();
		
		default:
			return null;
		}
	}
	

}


	


