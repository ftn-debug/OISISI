package studentska.sluzba.view;



import javax.swing.table.AbstractTableModel;

import studentska.sluzba.model.BazaProfesora;
/**
 * Metoda nasljedjuje klasu AbstractTable model i omogucava nam da napravimo izgled/model nase tabele.
 * @author majab
 *
 */
public class AbstractTableModelProfesor   extends AbstractTableModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AbstractTableModelProfesor() {
	
}

	@Override
	/**
	 * @return broj redova
	 */
	public int getRowCount() {
		
		return BazaProfesora.getInstance().getProfesori().size();
	}
	

	@Override
	/**
	 *@return  broj kolona
	 */
	public int getColumnCount() {
		return BazaProfesora.getInstance().getColumnCount();
	}

	@Override
	/**
	 *@return vrijednost celije
	 */
	public Object getValueAt(int rowIndex, int columnIndex) {
		return BazaProfesora.getInstance().getValueAt(rowIndex, columnIndex);
	}
	@Override
	/**
	 *@return  naziv kolone 
	 */	public String getColumnName(int index) {
		return BazaProfesora.getInstance().getColumnName(index);
	}
	
}
