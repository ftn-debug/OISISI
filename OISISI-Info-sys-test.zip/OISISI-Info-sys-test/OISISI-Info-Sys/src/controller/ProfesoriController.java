package controller;

import gui.MainFrame;
import model.BazaPredmeta;
import model.BazaProfesora;
import model.Predmet;
import model.Profesor;
import pop.dialogs.EditProfesorDialog;

public class ProfesoriController {

	private static ProfesoriController instance = null;
	
	public static ProfesoriController getInstance() {
		if(instance == null) {
			instance = new ProfesoriController();
		}
		return instance;
	}
	
	private ProfesoriController() {	}
	
	public void dodajProfesora(Profesor profesor) {
		BazaProfesora.getInstance().dodajProfesora(profesor);
		MainFrame.getInstance().azurirajPrikazProfesora("DODAT PROFESOR", -1);
	}
	public void izmjeniProfesora(Profesor profesor) {
		//ne profesor.getBrLicne karte nego ti treba stari profesor ber licne karte
		//dalje u izmjeni profesora
		BazaProfesora.getInstance().izmjeniProfesora(profesor.getBrLicneKarte(), profesor.getIme(), 
													profesor.getPrezime(), profesor.getDatumRodj(), 
													profesor.getAdresaStanovanja(), profesor.getTelefon(), profesor.getMail(),
													profesor.getAdresaKancelarije(),profesor.getTitula(), profesor.getZvanje());
		MainFrame.getInstance().azurirajPrikazProfesora("IZMJENJEN PROFESOR", -1);
	}
	
	public void izbrisiProfesora(Profesor profesor) {
		
		//treba zaci u predmete i izbrisati profesora iz svih predmeta na kojima je on profesor
		PredmetiController.getInstance().obrisiProfesoraSaPredmeta(profesor);
		
		//na kraju zaci u prof i obrisati ga
		BazaProfesora.getInstance().izbrisiProfesora(profesor.getBrLicneKarte());
		MainFrame.getInstance().azurirajPrikazProfesora("OBRISAN PROFESOR", -1);
	}
	
	public boolean uniqueBrLicneKarte(Profesor profesor) {
		return BazaProfesora.getInstance().uniqueBrLicneKarte(profesor.getBrLicneKarte());
	}
	
	public void dodajPredmetProfesoru(Profesor p,Predmet predmet,EditProfesorDialog edp) {
		
		BazaProfesora.getInstance().dodajPredmetProfesoru(p,predmet);
		//dodavanje profesora predmetu
		PredmetiController.getInstance().dodajProfesoraPredmetu(p,predmet);
		edp.azurirajPrikazPredmetaProfesora(null, -1);
		edp.azurirajPrikazPredmetaZaDodati(null, -1);
	}
	
public void ukloniPredmetProfesoru(Profesor p,Predmet predmet,EditProfesorDialog edp) {
		
		BazaProfesora.getInstance().ukloniPredmetProfesoru(p,predmet);
		//dodavanje profesora predmetu
		PredmetiController.getInstance().ukloniProfesoraSaPredmeta(p,predmet);
		edp.azurirajPrikazPredmetaProfesora(null, -1);
		edp.azurirajPrikazPredmetaZaDodati(null, -1);
	}
	
}
