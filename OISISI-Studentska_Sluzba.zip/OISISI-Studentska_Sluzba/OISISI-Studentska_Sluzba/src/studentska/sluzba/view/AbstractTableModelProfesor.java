package studentska.sluzba.view;



import javax.swing.table.AbstractTableModel;

import studentska.sluzba.model.BazaProfesora;

public class AbstractTableModelProfesor   extends AbstractTableModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AbstractTableModelProfesor() {
	
}

	@Override
	public int getRowCount() {
		return BazaProfesora.getInstance().getProfesori().size();
	}
	

	@Override
	public int getColumnCount() {
		return BazaProfesora.getInstance().getColumnCount();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return BazaProfesora.getInstance().getValueAt(rowIndex, columnIndex);
	}
	@Override
	public String getColumnName(int index) {
		return BazaProfesora.getInstance().getColumnName(index);
	}
	
}
