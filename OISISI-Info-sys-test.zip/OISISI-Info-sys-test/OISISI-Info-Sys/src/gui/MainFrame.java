package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;

import model.BazaPredmeta;
import model.BazaProfesora;
import model.BazaStudenata;
import model.Predmet;
import model.Profesor;
import model.Student;
import view.AbstractTableModelPredmet;
import view.AbstractTableModelProfesor;
import view.AbstractTableModelStudent;
import view.PredmetiJTable;
import view.ProfesoriJTable;
import view.StudentJTable;



//import sun.jvm.hotspot.ui.table.SortableTableModel;

public class MainFrame extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private JTable tabelaPredmeti; 
	private JTable tabelaProfesori;
	private JTable tabelaStudenti;
	private JTabbedPane tabbedPane;
	
	private static MainFrame instance = null;
	
	public static MainFrame getInstance() {
		if(instance == null) {
			instance = new MainFrame();
		}
		return instance;
	}
	
	
	

	public MainFrame() {
		super();
		//
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize = kit.getScreenSize();
		int screenHeight = screenSize.height;
		int screenWidth =screenSize.width;
		setSize(screenWidth*3/4,screenHeight*3/4);
		setTitle("Studentska sluzba");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
		setLayout(new BorderLayout());
		//
		JPanel panBars=new JPanel();
		panBars.setBackground(Color.LIGHT_GRAY);
		panBars.setPreferredSize(new Dimension(60,60));
		add(panBars,BorderLayout.NORTH);		
		panBars.setLayout(new BorderLayout());
		
		
		ToolBar toolbar =  new ToolBar();
		toolbar.setPreferredSize(new Dimension(this.getWidth(),35));
		panBars.add(toolbar,BorderLayout.SOUTH);
		
		
		MenuBar menuBar =  new MenuBar();
		menuBar.setPreferredSize(new Dimension(25,25));
		panBars.add(menuBar,BorderLayout.NORTH);
		
		StatusBar statusLine =  new StatusBar();
		statusLine.setPreferredSize(new Dimension(this.getWidth(),20));
        add(statusLine,BorderLayout.SOUTH);
        
        //umesto ovog da  napravim objekat klase tabbed pane i dodam na cenntar ??? 
        createTabbedPane();
       
        //***************************************

		setVisible(true);		
				
	}
	
	public JTabbedPane getTabbedPane() {
		return tabbedPane;
	}	
	public int selectedTab() {
		return tabbedPane.getSelectedIndex();
	}
	
	
	
	
	
	
	public JTable getTabelaStudenti(){
		 return tabelaStudenti;
	 }
	 public JTable getTabelaPredmeti() {
		return tabelaPredmeti;
	}
	 public JTable getTabelaProfesori() {
		return tabelaProfesori;
	}
	
	
	
	
	public void azurirajPrikazPredmet(String akcija,int vrednost) {
		AbstractTableModelPredmet model = (AbstractTableModelPredmet) tabelaPredmeti.getModel();
		model.fireTableDataChanged();
		validate();
	}
	
	public void azurirajPrikazProfesora(String akcija,int vrednost) {
		AbstractTableModelProfesor model = (AbstractTableModelProfesor) tabelaProfesori.getModel();
		model.fireTableDataChanged();
		validate();
	}
	
	public void azurirajPrikazStudenta(String akcija,int vrednost) {
		AbstractTableModelStudent model = (AbstractTableModelStudent) tabelaStudenti.getModel();
		model.fireTableDataChanged();
		validate();
	}
	
	private JScrollPane prikaziTabeluStudenata() {
		tabelaStudenti = new StudentJTable();
		
		JScrollPane scrollPane1 = new JScrollPane(tabelaStudenti);
		this.azurirajPrikazStudenta(null, -1);
		
		return scrollPane1;
	}
	 
	private JScrollPane prikaziTabeluProfesora() {
		tabelaProfesori = new ProfesoriJTable();
		JScrollPane scrollPane2 = new JScrollPane(tabelaProfesori);
		this.azurirajPrikazProfesora(null, -1);
		
		return scrollPane2;
	}

	private JScrollPane prikaziTabeluPredmeta() {
		tabelaPredmeti = new PredmetiJTable();
		JScrollPane scrollPane3 = new JScrollPane(tabelaPredmeti);
		this.azurirajPrikazPredmet(null	, -1);
		
		return scrollPane3;
	}

	private void createTabbedPane() {
		tabbedPane = new JTabbedPane();
		JScrollPane studentiTab = prikaziTabeluStudenata();
		JScrollPane profesoriTab = prikaziTabeluProfesora();
		JScrollPane predmetiTab = prikaziTabeluPredmeta();
		
		tabbedPane.addTab("Studenti", studentiTab);
		tabbedPane.addTab("Profesori", profesoriTab);
		tabbedPane.addTab("Predmeti", predmetiTab);
		
		add(tabbedPane,BorderLayout.CENTER);
		
	}
	
	public Profesor selektovaniProfesor() {
		Profesor prof = null;
		if(tabelaProfesori.getSelectedRow() < 0) {
			return null;
		}
		prof = BazaProfesora.getInstance().getRow(tabelaProfesori.getSelectedRow());
		return prof;
	}

	
	public int selectedProfesorRow() {
		
		return tabelaProfesori.getSelectedRow();
	}

	public Student selectedStudent() {
		Student s= null;
		if(tabelaStudenti.getSelectedRow() < 0) {
			return null;
		}
		//Posto mi autosorter samo sortira view ,a ne sortira bazu
		//Ovdje konvertujem iz view u bazu
		//treba konvertovari jer se selektuje tabelaStudenti.getSelectedRow()
		int viewRowIndex= tabelaStudenti.getSelectedRow();
		int modelRowIndex=tabelaStudenti.convertRowIndexToModel(viewRowIndex);
		
		s= BazaStudenata.getInstance().getRow(modelRowIndex);
		
		return s;
	}
	
	public int selectedStudentRow() {
		if(tabelaStudenti.getSelectedRow() < 0) {
			return 0;
			
		}
		return tabelaStudenti.getSelectedRow();
	}
	//ovo
	public Predmet selectedPredmet() {
		Predmet p= null;
		if(tabelaPredmeti.getSelectedRow() < 0) {
			return null;
		}
		p=BazaPredmeta.getInstance().getRow(tabelaPredmeti.getSelectedRow());
		return p;
	}
	public int selectedPredmetRow() {
		if(tabelaStudenti.getSelectedRow() < 0) {
			return 0;
			
		}
		return tabelaStudenti.getSelectedRow();
	}
}
