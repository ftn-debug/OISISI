package model;
//studenta 1
//#student
//#ocena
//#prikaz_studenata
//#dodavanje_studenta

public class Ocena {
	private Student student;
	private Predmet predmet;
	private int vijrednostOcene;
	private String datumPolaganja;
	
	
	public Ocena(Student student, Predmet predmet, int vijrednostOcene, String datumPolaganja) {
		super();
		this.student = student;
		this.predmet = predmet;
		this.vijrednostOcene = vijrednostOcene;
		this.datumPolaganja = datumPolaganja;
	}
	public Ocena() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Predmet getPredmet() {
		return predmet;
	}
	public void setPredmet(Predmet predmet) {
		this.predmet = predmet;
	}
	public int getVijrednostOcene() {
		return vijrednostOcene;
	}
	public void setVijrednostOcene(int vijrednostOcene) {
		this.vijrednostOcene = vijrednostOcene;
	}
	public String getDatumPolaganja() {
		return datumPolaganja;
	}
	public void setDatumPolaganja(String datumPolaganja) {
		this.datumPolaganja = datumPolaganja;
	}
	@Override
	public String toString() {
		return "Ocena [student=" + student + ", predmet=" + predmet + ", vijrednostOcene=" + vijrednostOcene
				+ ", datumPolaganja=" + datumPolaganja + "]";
	}
	

}
