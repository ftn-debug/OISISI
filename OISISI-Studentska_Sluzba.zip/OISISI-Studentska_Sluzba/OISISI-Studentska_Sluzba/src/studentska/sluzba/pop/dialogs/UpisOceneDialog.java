package studentska.sluzba.pop.dialogs;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import studentska.sluzba.controller.StudentiController;
import studentska.sluzba.gui.PolozeniPredmetiPanel;
import studentska.sluzba.model.Ocena;
import studentska.sluzba.model.Ocena.vOcjene;
import studentska.sluzba.model.Predmet;
import studentska.sluzba.model.Student;

public class UpisOceneDialog extends JDialog{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	JLabel lsifra ;
	JLabel lnaziv;
	JLabel locena;
	JLabel ldatum;
	JTextField poljeSifra;
	JTextField poljeNaziv;
	JComboBox<Integer> comboBoxOcjena;
	JTextField poljeDatum;
	
	
	public UpisOceneDialog(Predmet p,Student s,EditStudentDialog eds) {
		setTitle("Unos ocene");
		lsifra = new JLabel("Sifra");
		lnaziv = new JLabel("Naziv*");
		locena = new JLabel("Ocena*");
		ldatum = new JLabel("Datum*");
		poljeSifra = new JTextField(15);
		poljeSifra.setText(p.getSifraPredmeta());
		poljeSifra.setEditable(false);
		poljeNaziv = new JTextField(15);
		poljeNaziv.setText(p.getNazivPredmeta());
		poljeNaziv.setEditable(false);
		comboBoxOcjena = new JComboBox<>();
		DefaultComboBoxModel<Integer> Model = new DefaultComboBoxModel<Integer>();
		Model.addElement(Integer.parseInt("6"));
		Model.addElement(Integer.parseInt("7"));
		Model.addElement(Integer.parseInt("8"));
		Model.addElement(Integer.parseInt("9"));
		Model.addElement(Integer.parseInt("10"));
		comboBoxOcjena.setModel(Model);
		comboBoxOcjena.setSelectedIndex(0);
		comboBoxOcjena.setEditable(false);
		poljeDatum = new JTextField();
		
		
		JButton btnOK = new JButton("Potvrdi");
		JButton btnCancel = new JButton("Odustani");
		
		 Window parent = SwingUtilities.getWindowAncestor(this);
		ActionListener ok = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Ocena  o;
				try {
					o = collectData(p, s);
					if(o.equals(null)) {
						JOptionPane.showMessageDialog(parent, "Morate  popuniti sva polja!");
					}else {
						
						//ovde samo pozvati funkciju iz kontrolera npr dodajOcenu 
						
						StudentiController.getInstance().dodajOcenuStudentu(s,o,p,eds);
						PolozeniPredmetiPanel.prosjecnaOcjenaL.setText("Prosječna ocjena : " + s.getProsecnaOcena(s));
						PolozeniPredmetiPanel.ukupnoEspbL.setText("Ukupno ESPB bodova : " + s.getEspb(s));
					//s.getSpisakPolozenihIspita().add(o);
					//s.getSpisakNepolozenihIspita().remove(p);
					//ovo ne znam dal moze 
					
				//	eds.azurirajPrikazNepolozenih("UKLONJEN PREDMET", -1);
					//eds.azurirajPrikazPolozeni("DODATA OCENA", -1);
					 dispose();
					}
				}catch(Exception e2) {
					e2.printStackTrace();
				}
				
			}
		};
		
		btnOK.addActionListener(ok);
		
		ActionListener cancel = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				
			}
		};
		
		btnCancel.addActionListener(cancel);
		
		btnOK.setEnabled(false);
		FocusListener fl1 = new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				if(!(poljeSifra.getText().isEmpty() || poljeNaziv.getText().isEmpty()||
						poljeDatum.getText().isEmpty() )) {
					btnOK.setEnabled(true);
				}
				
			}
		};
		
		poljeNaziv.addFocusListener(fl1);
		poljeSifra.addFocusListener(fl1);
		poljeDatum.addFocusListener(fl1);
		
		layout(btnOK,btnCancel);
		setSize(new Dimension(350,350));
		setLocationRelativeTo(this.getParent());
		getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
		setVisible(true);
	}
	
	
	private void layout(JButton btnOK,JButton btnCancel) {
		
		setLayout(new GridBagLayout());
		
		GridBagConstraints gc = new GridBagConstraints(0, 0, 1,
				1, 0, 0,  GridBagConstraints.WEST,  GridBagConstraints.HORIZONTAL,  new Insets(10, 30, 20, 30), 0, 0);
		add(lsifra,gc);
		GridBagConstraints gc1 = new GridBagConstraints(0, 1, 1,
				1, 0, 0,  GridBagConstraints.WEST,  GridBagConstraints.HORIZONTAL,  new Insets(10, 30, 20, 30), 0, 0);
		add(lnaziv,gc1);
		GridBagConstraints gc2 = new GridBagConstraints(0, 2, 1,
				1, 0, 0,  GridBagConstraints.WEST,  GridBagConstraints.HORIZONTAL,  new Insets(10, 30, 20, 30), 0, 0);
		add(locena,gc2);
		GridBagConstraints gc3 = new GridBagConstraints(0, 3, 1,
				1, 0, 0,  GridBagConstraints.WEST,  GridBagConstraints.HORIZONTAL,  new Insets(10, 30, 40, 30), 0, 0);
		add(ldatum,gc3);
		GridBagConstraints gc4 = new GridBagConstraints(1, 0, 1,
				1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.HORIZONTAL,  new Insets(10, 0, 10, 20), 0, 10);
		add(poljeSifra,gc4);
		GridBagConstraints gc5 = new GridBagConstraints(1, 1, 1,
				1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.HORIZONTAL,  new Insets(10, 0, 10, 20), 0, 10);
		add(poljeNaziv,gc5);
		GridBagConstraints gc6 = new GridBagConstraints(1, 2, 1,
				1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.HORIZONTAL,  new Insets(10, 0, 10, 20), 0, 10);
		add(comboBoxOcjena,gc6);
		GridBagConstraints gc7 = new GridBagConstraints(1, 3, 1,
				1, 0, 0,  GridBagConstraints.CENTER,  GridBagConstraints.HORIZONTAL,  new Insets(10, 0, 30, 20), 0, 10);
		add(poljeDatum,gc7);
		GridBagConstraints gc8 = new GridBagConstraints(0, 4, 1,
				1, 0, 0,  GridBagConstraints.EAST,  GridBagConstraints.HORIZONTAL,  new Insets(10, 50, 10, 10), 10, 0);
		add(btnOK,gc8);
		GridBagConstraints gc9 = new GridBagConstraints(1, 4, 1,
				1, 0, 0,  GridBagConstraints.WEST,  GridBagConstraints.HORIZONTAL,  new Insets(10, 10, 10, 50), 0, 0);
		add(btnCancel,gc9);
		
	}

	private Ocena collectData(Predmet p,Student s) throws ParseException {
		
		Ocena ocena;
		ocena = null;
		try {
			Date unetDatum = spremiDatum(poljeDatum.getText());
			int unetaOcena = (int) comboBoxOcjena.getSelectedItem();
			
			vOcjene unetaOcena1 = null;
			if(unetaOcena==6) {
				unetaOcena1 = vOcjene.sest;
			}
			if(unetaOcena==7) {
				 unetaOcena1 = vOcjene.sedam;
			}
			if(unetaOcena==8) {
				 unetaOcena1 = vOcjene.osam;
			}
			if(unetaOcena==9) {
				 unetaOcena1 = vOcjene.devet;
			}
			if(unetaOcena==10) {
				 unetaOcena1 = vOcjene.deset;
			}
			
		if(unetDatum.equals(null) || unetaOcena1.equals(null)) {
			return null;
		}
		
		ocena = new Ocena(s,p,unetaOcena1,unetDatum);
		
				
		}catch (Exception e) {
			e.printStackTrace();
		}
		return ocena;
	}
	public Date spremiDatum(String date)  {
		
		Date datum = null;
		try {
		String pattern = "dd.MM.yyyy.";
		SimpleDateFormat simpleDatedFormat = new SimpleDateFormat(pattern);
		  datum =  simpleDatedFormat.parse(date);
		}catch(ParseException e) {
			e.printStackTrace();
			return null;
		}
		return datum;
	}

}
