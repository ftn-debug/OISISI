package gui;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

import pop.dialogs.AddStudentDialog;

public class ActionNew extends AbstractAction {

	private static final long serialVersionUID = 1583426086994634757L;

	public ActionNew() {
		//putValue(NAME, "New");
		putValue(MNEMONIC_KEY, KeyEvent.VK_K);
		putValue(SHORT_DESCRIPTION, "New");
		putValue(SMALL_ICON, new ImageIcon("Images/add.png"));
		putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_K, KeyEvent.CTRL_MASK));
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		AddStudentDialog a= new AddStudentDialog();
		
		
		
		
	}

}
