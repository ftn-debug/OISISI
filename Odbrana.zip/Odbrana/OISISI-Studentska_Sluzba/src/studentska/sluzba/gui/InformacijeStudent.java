package studentska.sluzba.gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import studentska.sluzba.controller.StudentiController;
import studentska.sluzba.model.Student;
import studentska.sluzba.model.Student.Status;
import studentska.sluzba.pop.dialogs.EditStudentDialog;
/**
 * Klasa koja nasljedjuje JPanel i sadrži panel na kome je prikazana forma za izmenu podataka o studentu.
 * Sadrzi dugmad za potvrdu izmena (“ Potvrdi ”), odnosno odustanak od izmene (“ Odustani ”).
 * Nakon izmjene potrebno je azurirati izgled Studenta .
 * @author Maja Blagic
 *
 */
public class InformacijeStudent extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JLabel imeL;
	static JLabel prezimeL;
	static JLabel datumRodjenjaL;
	static JLabel adresaL;
	static JLabel brojTelefonaL;
	static JLabel eMailL;
	static JLabel brIndexaL;
	static JLabel godinaUpisaL;
	static JLabel godinaStudijaL;
	static JLabel statusL;
	
	static JTextField imeF;
	static JTextField prezimeF;
	static JTextField datumRodjenjaF;
	static JTextField adresaF;
	static JTextField brojTelefonaF;
	static JTextField eMailF;
	static JTextField brIndexaF;
	static JTextField godinaUpisaF;
	static JTextField godinaStudijaF;
	static JTextField statusF;
	
	static JComboBox<String> statusBox;
	static JComboBox<String> godinaBox;
	static JComboBox<String> godStudija;

	static JRadioButtonMenuItem budzet;
	static JRadioButtonMenuItem samofinansiranje;
	static ButtonGroup buttonGroup;
	static JPanel statusPane;
	static JPanel panel;
	
	/**
	 * 
	 * @param s - Student ciji se podaci mijenjaju
	 * @param eds - Referenca na dijalog koji poziva ovu klasu. Nakon izmjene je potrebno azurirati taj dijalog.
	 */
	public InformacijeStudent(Student s, EditStudentDialog eds) {
		setName("Editovanje studenta");
		imeL=new JLabel("Ime* ");
		prezimeL= new JLabel("Prezime *");
		datumRodjenjaL=new JLabel("Datum rodjenja * ");
	    adresaL=new JLabel("Adresa stanovanja * ");
		brojTelefonaL= new JLabel("Broj telefona* ");
		eMailL= new JLabel("E-mail adresa* ");
		brIndexaL= new JLabel("Broj indeksa* ");
		godinaUpisaL=new JLabel("Godina upisa* ");
		godinaStudijaL=new JLabel("Trenutna godina studija* ");
		statusL= new JLabel("Nacin finansiranja* ");
		
		statusBox=new JComboBox<String>();
		godStudija= new JComboBox<String>();
		
		DefaultComboBoxModel<String> statusModel=new DefaultComboBoxModel<String>();
		statusModel.addElement("Samofinansiranje");
		statusModel.addElement("Budzet");
		statusBox.setModel(statusModel);
		statusBox.setSelectedIndex(0);
		statusBox.setEditable(true);

		DefaultComboBoxModel<String> godModel=new DefaultComboBoxModel<String>();
		godModel.addElement("  1(Prva)");
		godModel.addElement("  2(Druga)");
		godModel.addElement("  3(Treca)");
		godModel.addElement("  4(Cetvrta)");
		godModel.addElement("  5(Master)");
		godModel.addElement("  Doktorske");
		
		godStudija.setModel(godModel);
		godStudija.setSelectedIndex(0);
		godStudija.setEditable(true);
		
		
		imeF=new JTextField(15);
		imeF.setName("imeTxt");
		imeF.setText(s.getIme());
		
		
		prezimeF = new JTextField(15);
		prezimeF.setName("prezimeTxt");
		prezimeF.setText(s.getPrezime());
		
		
		datumRodjenjaF = new JTextField(15);
		datumRodjenjaF.setName("datumTxt");
		
		Date datum=s.getDatumRodjenja();
		DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy.");  
        String strDate = dateFormat.format(datum);  
        datumRodjenjaF.setText(strDate);
		
		
		
		adresaF = new JTextField(15);
		adresaF.setName("adresaTxt");
		adresaF.setText(s.getAdresa());
		
		
		brojTelefonaF = new JTextField(15);
		brojTelefonaF.setName("brojTxt");
		brojTelefonaF.setText(s.getKontaktTelefon());
		
		eMailF = new JTextField(15);
		eMailF.setName("EmailTxt");
		eMailF.setText(s.geteMail());

		brIndexaF = new JTextField(15);
		brIndexaF.setName("indeksTxt");
		brIndexaF.setText(s.getBrIndeksa());
		
		godinaUpisaF = new JTextField(15);
		godinaUpisaF.setName("godinaUpisaTxt");
		godinaUpisaF.setText(String.valueOf(s.getGodinaUpisa()));
		

		statusModel.setSelectedItem(s.getStatus());
		godModel.setSelectedItem(s.getTrenutnaGodinaStudija());

	
		JButton okButton= new JButton("Potvrdi");
		Window parent = SwingUtilities.getWindowAncestor(this);
		
		
		
		 //okButton.setEnabled(false);
			FocusListener fl1 = new FocusListener() {

				@Override
				public void focusLost(FocusEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void focusGained(FocusEvent e) {
					if(!(imeF.getText().isEmpty() || prezimeF.getText().isEmpty() 
							|| stringToDate(datumRodjenjaF.getText())==null || adresaF.getText().isEmpty() 
							|| brojTelefonaF.getText().isEmpty() || eMailF.getText().isEmpty()
							|| brIndexaF.getText().isEmpty() || isInteger(godinaUpisaF.getText())==false
							)) {
						okButton.setEnabled(true);
					}else {
						okButton.setEnabled(false);
					}

				}
			};
			
			imeF.addFocusListener(fl1);
			prezimeF.addFocusListener(fl1);
			datumRodjenjaF.addFocusListener(fl1);
			adresaF.addFocusListener(fl1);
			brojTelefonaF.addFocusListener(fl1);
			eMailF.addFocusListener(fl1);
			brIndexaF.addFocusListener(fl1);
			godinaUpisaF.addFocusListener(fl1);
		 
		
	
		
		
		
		okButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
					
				
				Student student;
				student = collectInfo();
				if(student == null) {
					System.out.println("NoSucces!");
					okButton.setToolTipText("Polja nisu popunjena!");
					
					//Zakomentarisane sve verzije JOptionPane dijaloga
					//ni jedna nije htjela da radi!
					
					//JOptionPane.showMessageDialog(eds,"Polja nisu popunjena!");
					//JOptionPane.showMessageDialog(MainFrame.getInstance(),"Polja nisu popunjena!");
					//JOptionPane.showMessageDialog(null,"Polja nisu popunjena!");
				}else {
					//call Controller
					//ako je isti 
						if(student.getBrIndeksa().equals(s.getBrIndeksa())) {
							System.out.println("Success update!");
							StudentiController.getInstance().updateStudenta(s.getBrIndeksa(),student);
							
							//SwingUtilities.getWindowAncestor(okButton).dispose();
						
						}
						//ako nije isti a jeste jedinstven
						else if(StudentiController.getInstance().uniqueBrIndex(student)) {
							
							System.out.println("Succes ovdje!");
							StudentiController.getInstance().updateStudenta(s.getBrIndeksa(),student);

							//SwingUtilities.getWindowAncestor(okButton).dispose();
							
						}else {
							//Zakomentarisane sve verzije JOptionPane dijaloga
							//ni jedna nije htjela da radi!
							//Tacnije sve blokiraju dalji rad aplikacije
							//ako nije isti a nije ni jedinstven
							
							//JOptionPane.showMessageDialog(eds, "Broj indeksa nije jedinstven! ");
							//JOptionPane.showMessageDialog(MainFrame.getInstance(), "Broj indeksa nije jedinstven! ");
							//JOptionPane.showMessageDialog(null,"Polja nisu popunjena!");

						}
				}

			}});
	
		JButton cancelButton = new JButton("Odustani");
		 cancelButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					eds.dispose();
				}
			});
	
		 
		 
		setLayout(okButton, cancelButton);		
	}
	
	
	
	
	
	/**
	 * Metoda koja pravi layout Panela. 
	 * Sadrzi formu za izmenu podataka o studentu kao i dugmadi:
	 * @param okButton - potvrda zeljene izmjene 
	 * @param cancelButton - odustanak od izmjene
	 */
	private void setLayout(JButton okButton, JButton cancelButton) {
		
		setLayout(new GridBagLayout());
		
		
		GridBagConstraints gbc= new GridBagConstraints();
		
		gbc.weightx=0.01;
		gbc.weighty=0.01;
		gbc.gridx = 0;
		gbc.gridy = 0;
		
	//	gbc.insets = new Insets(20, 20, 0, 0);
		gbc.anchor=GridBagConstraints.LINE_START;
		add(imeL, gbc);
		
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.anchor=GridBagConstraints.LINE_START;
		add(imeF, gbc);
		
		//--------------------
		gbc.weightx=0.01;
		gbc.weighty=0.01;
		gbc.gridy = 1;
		gbc.gridx = 0;
	//	gbc.insets = new Insets(20, 20, 0, 0);
		gbc.anchor = GridBagConstraints.LINE_START;
		add(prezimeL,gbc);
		

		gbc.gridy = 1;
		gbc.gridx = 1;
		gbc.anchor = GridBagConstraints.LINE_START;
		add(prezimeF, gbc);
		//----------------
		
		
		gbc.weightx=0.01;
		gbc.weighty=0.01;
		gbc.gridy = 2;
		gbc.gridx = 0;
	//	gbc.insets = new Insets(20, 20, 0, 0);
		gbc.anchor=GridBagConstraints.LINE_START;
		add(datumRodjenjaL,gbc);
		

		gbc.gridy = 2;
		gbc.gridx = 1;
		gbc.anchor=GridBagConstraints.LINE_START;
		add(datumRodjenjaF,gbc);
		
	
		//------------------
		gbc.weightx=0.01;
		gbc.weighty=0.01;
		gbc.gridy = 3;
		gbc.gridx = 0;
	//	gbc.insets = new Insets(20, 20, 0, 0);
		gbc.anchor=GridBagConstraints.LINE_START;
		add(adresaL,gbc);
		

		gbc.gridy = 3;
		gbc.gridx = 1;
		gbc.anchor=GridBagConstraints.LINE_START;
		add(adresaF,gbc);
		
		
		//----------------
		gbc.weightx=0.01;
		gbc.weighty=0.01;
		gbc.gridy = 4;
		gbc.gridx = 0;
	//	gbc.insets = new Insets(20, 20, 0, 0);
		gbc.anchor=GridBagConstraints.LINE_START;
		add(brojTelefonaL,gbc);
		

		gbc.gridy = 4;
		gbc.gridx = 1;
		gbc.anchor=GridBagConstraints.LINE_START;
		add(brojTelefonaF,gbc);
		//-----------------
		//e mail addresa
		gbc.weightx=0.01;
		gbc.weighty=0.01;
		gbc.gridy = 5;
		gbc.gridx = 0;
	//	gbc.insets = new Insets(20, 20, 0, 0);
		gbc.anchor=GridBagConstraints.LINE_START;
		add(eMailL,gbc);
		

		gbc.gridy = 5;
		gbc.gridx = 1;
		gbc.anchor=GridBagConstraints.LINE_START;
		add(eMailF,gbc);
		
		//---------------------
	
		gbc.weightx=0.01;
		gbc.weighty=0.01;
		gbc.gridy = 6;
		gbc.gridx = 0;
	//	gbc.insets = new Insets(20, 20, 0, 0);
		gbc.anchor=GridBagConstraints.LINE_START;
		add(brIndexaL,gbc);
		
		gbc.gridy = 6;
		gbc.gridx = 1;
		gbc.anchor=GridBagConstraints.LINE_START;
		add(brIndexaF,gbc);
		//-----------------------
		gbc.weightx=0.01;
		gbc.weighty=0.01;
		gbc.gridy = 7;
		gbc.gridx = 0;
		gbc.anchor=GridBagConstraints.LINE_START;
		add(godinaUpisaL,gbc);
		

		gbc.gridy = 7;
		gbc.gridx = 1;	
		gbc.anchor=GridBagConstraints.LINE_START;
		add(godinaUpisaF,gbc);
		//----------------------
		
		gbc.weightx=0.01;
		gbc.weighty=0.01;
		gbc.gridy = 8;
		gbc.gridx = 0;
		gbc.anchor=GridBagConstraints.LINE_START;
		add(godinaStudijaL,gbc);
		
		gbc.gridy = 8;
		gbc.gridx = 1;	
		gbc.anchor=GridBagConstraints.LINE_START;
		add(godStudija,gbc);
		
		gbc.weightx=0.01;
		gbc.weighty=0.01;
		gbc.gridy = 9;
		gbc.gridx = 0;
		gbc.anchor=GridBagConstraints.LINE_START;
		add(statusL,gbc);
		
		gbc.gridy = 9;
		gbc.gridx = 1;	
		gbc.anchor=GridBagConstraints.LINE_START;
		add(statusBox,gbc);
		
		

		gbc.gridy = 10;
		gbc.gridx = 1;
		gbc.anchor=GridBagConstraints.LINE_START;
		add(okButton,gbc);
				
		gbc.gridy = 10;
		gbc.gridx = 2;
		gbc.anchor=GridBagConstraints.LINE_START;
		add(cancelButton,gbc);
		
		
		
	}


//poslije toga moram da collect data da bih mogla da upsem u bazu
/**
 * Metoda koja kupi unesene korisnicke podatke putem JFieldova. Konvertuje unesene podatke u odgovarajuce vrijednosti i kreira izmijenjenog Studenta.
 * @return entitet Student.
 */
	private Student collectInfo() {

		String ime= imeF.getText();
		String prezime= prezimeF.getText();
		Date datumRodjenja= stringToDate(datumRodjenjaF.getText());
		
		String adresa = adresaF.getText();
		String brTelefona = brojTelefonaF.getText();
		String email = eMailF.getText();
		String brIndeksa = brIndexaF.getText();
		String godinaUpisa =godinaUpisaF.getText();
		int godinaUpisaInt =stringToInt(godinaUpisa);
	   
		int godina = godStudija.getSelectedIndex();
		int trenutnaGodinaStudija = godina + 1;
		
		Status status;
		if(statusBox.getSelectedIndex() == 1) {
			status = Status.B;
		}else {
			status= Status.S;
		}
		double prosjecnaOcjena=0;
		if(ime.equals("") || prezime.equals("") || adresa.equals("") || datumRodjenja==null|| brTelefona.equals("")
				|| email.equals("") || brIndeksa.equals("") || godinaUpisa.equals("") || godinaUpisaInt == 0  ) {
			System.out.println("ERROR:Nije/Pogresno unijeta vrijednost u polja!");
			return null;
		}
		

		
		Student student= new Student(ime, prezime, datumRodjenja,adresa, brTelefona, email,brIndeksa,godinaUpisaInt,trenutnaGodinaStudija, status,prosjecnaOcjena);
		
		
		return student;
	}
	/**
	 * Metoda koja konvertuje String u int (ex: unesena godina u obliku vrijednosti String u oblik int)
	 * @param string - korisnicki uneseni string
	 * @return - konvertovana vrijednost stringa
	 */
	private int stringToInt(String string) {
		int parsedInt= 0;
		try{
			parsedInt = Integer.parseInt(string); 
		}catch (NumberFormatException e) {
		e.printStackTrace();
		parsedInt=0;
		} 
		return parsedInt;
	}
	/**
	 * Metoda koje konvertuje String u Date(ex: uneseni datum u obliku vrijednosti String u oblik Date)
	 * @param text - korisnicki uneseni string
	 * @return - konvertovana vrijednost stinga
	 */
	private Date stringToDate(String text) {
		
		String sDate=text;
		Date date = null;
		try {
			date = new SimpleDateFormat("dd.MM.yyyy.").parse(sDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} 
		return date;
	}

	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	/**
	 * Metoda koja ukazuje na Exception ako parsiranje Integer vrijednosti nije moguce 
	 * @param s - korisnicki uneseni string
	 * @return - 1 ako je uspjesno odradjeno parsiranje , 0 ako je neuspjesno parsiranje
	 */
	public static boolean isInteger(String s) {
	    try { 
	        Integer.parseInt(s); 
	    } catch(NumberFormatException e) { 
	        return false; 
	    } catch(NullPointerException e) {
	        return false;
	    }
	    // only got here if we didn't return false
	    return true;
	}

}
