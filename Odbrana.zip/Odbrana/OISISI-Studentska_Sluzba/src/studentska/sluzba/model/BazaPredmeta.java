package studentska.sluzba.model;



import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import studentska.sluzba.controller.StudentiController;
import studentska.sluzba.gui.MainFrame;
import studentska.sluzba.model.Predmet.Semestar;
/**
 * Klasa koja cini Bazu predmeta i implementira metode nad tom bazom.
 * @author Maja Blagic
 *
 */
public class BazaPredmeta {
	

	private static BazaPredmeta instance = null;
	/**
	 * 
	 * @return - vraca instancu Baze Predmeta
	 */
	public static BazaPredmeta getInstance() {
		if(instance == null) {
			instance = new BazaPredmeta();
		}
		return instance;
	}
	//Predmet p = new Predmet();
	
	
	private List<Predmet> predmeti;
	private List<String> kolone;
	
	
	private BazaPredmeta() {
		
		predmeti = new ArrayList<Predmet>();		
		initPredmete();
		
		this.kolone = new ArrayList<>();
		this.kolone.add("SIFRA PREDMETA");
		this.kolone.add("NAZIV PREDMETA");
		this.kolone.add("BROJ ESPB BODOVA");
		this.kolone.add("GODINA NA KOJOJ SE PREDMET IZVODI");
		this.kolone.add("SEMESTAR");
		//this.kolone.add("PREDMETNI PROFESOR");
	}
	/**
	 * Meotoda koja inicijalizuje predmete pri pokretanju programa 
	 * tako sto poziva metodu deserijalizacije. 
	 */
	private void initPredmete() {
		
		deserijalizacijaPredmeta();
		

		/*
		dodajPredmet(new Predmet( "PR-1","Analiza", Semestar.LETNJI, 1, 5));
		dodajPredmet(new Predmet( "PR-2","OET", Semestar.LETNJI, 2, 5));
		dodajPredmet(new Predmet( "PR-3","PPR", Semestar.ZIMSKI, 1, 5));
		//predmeti.add(new Predmet("p1", "predmet1", Semestar.LETNJI, 1, 5));
		 * 
		 */

		

	}
	/**
	 * 
	 * @return - vraca listu predmeta
	 */
	public List<Predmet> getPredmeti() {
		return predmeti;
	}


	public void setPredmeti(List<Predmet> predmeti) {
		this.predmeti = predmeti;
	}
	
	
	public int getColumnCount() {
		return 5;
	}
	
	public String getColumnName(int index) {
		return this.kolone.get(index);
	}
	
	public Predmet getRow(int rowIndex) {
		return this.predmeti.get(rowIndex);
	}
	
	public String getValueAt(int row,int column) {
		Predmet predmet = this.predmeti.get(row);
		switch (column) {
		case 0: 
			return predmet.getSifraPredmeta();
		case 1:
			return predmet.getNazivPredmeta();
		case 2:
			return Integer.toString(predmet.getBrESPBbodova());
		case 3:
			return Integer.toString(predmet.getGodinaStudija());
		case 4:
			return predmet.getSemestar() + "";
		default:
				return null;		
		}
	}
	/**
	 * Metoda koja dodaje predmet u Bazu Predmeta. Provjerava da li taj predmet vec postoji
	 * tkao sto poziva metodu uniqueSifraPredmeta . Zatim apdejtuje podatke u drugim bazama
	 * koji su zavisni od ove promjene. 
	 * @param sifra -sifra predmeta
	 * @param naziv - naziv predmeta
	 * @param semestar - semestar predmeta
	 * @param godinaStudija - godina studija na kome se predmet izvodi
	 * @param predmetniProfesor - profesor koji predaje na predmetu 
	 * @param brESPB - broj ESP bodova koje predmet nosi
	 */
	public void dodajPredmet(String sifra,String naziv,Semestar semestar,
							int godinaStudija,Profesor predmetniProfesor,int brESPB) {
		if(uniqueSifraPredmeta(sifra)){
			
		Predmet p=new Predmet(sifra,naziv,semestar,godinaStudija,
				predmetniProfesor,brESPB);
		this.predmeti.add(p);
		StudentiController.getInstance().updatePredmete(p);
		MainFrame.getInstance().azurirajPrikazPredmet("DODAT PREDMET", -1);
		StudentiController.getInstance().azurirajListuPredmeta(p);
		}
	}
	/**
	 * Dodaje predmet ako utvrdi da je jedinstven pozivom funkcije uniqueSifraPredmeta
	 * @param predmet predmet koji dodajemo u Bazu Predmeta
	 */
	public void dodajPredmetEntity(Predmet predmet) {
		if(uniqueSifraPredmeta(predmet.getSifraPredmeta())){
			this.predmeti.add(predmet);
		
		}
	}
	
	@SuppressWarnings("unlikely-arg-type") //PITATI DA LI SIFRA PREDMETA MORA BITI STRING ILI MOZE BITI INT
	public void izbrisPredmet(String id)
	{
		for(Predmet p : predmeti) {
			if(p.getSifraPredmeta().equals(id) ) {
				predmeti.remove(p);
				break;
			}
		}
	}
	/**
	 * Metoda koja pronadje predmet po njegovoj sifri i onda mijenja ostale stribute tog predmeta
	 * Korisnik zadaje parametre:
	* @param sifra -sifra predmeta
	* @param sifraPredmeta - nova sifra predmeta
	 * @param naziv - naziv predmeta
	 * @param semestar - semestar  na kome se predmet predaje
	 * @param godinaStudija - godina studija na kome se predmet izvodi
	 * @param predmetniProfesor - profesor koji predaje na predmetu 
	 * @param brESPB - broj ESP bodova koje predmet nosi
	 */
	public void izmeniPredmet(String sifra,String sifraPredmeta,String naziv,Semestar semestar,
			int godinaStudija,Profesor predmetniProfesor,int brESPB) {
		for(Predmet p : predmeti) {
			if(p.getSifraPredmeta() == sifra) {
				p.setSifraPredmeta(sifraPredmeta);
				p.setNazivPredmeta(naziv);
				p.setSemestar(semestar);
				p.setGodinaStudija(godinaStudija);
				p.setPredmetniProfesor(predmetniProfesor);
				p.setBrESPBbodova(brESPB);
			}
		}
		
	}
	/**
	 * Metoda koja provjerava jedinstvenost kljuca sifraPredmeta
	 * @param sifraPredmeta - proslijedjena sifra predmeta
	 * @return 1 ako ne postoji predmet takvog kljuca u bazi a 0 ako vec postoji
	 */
	public boolean uniqueSifraPredmeta(String sifraPredmeta) {
		for(Predmet p: predmeti) {
			if(p.getSifraPredmeta().equals(sifraPredmeta)) {
				return false;
			}
		}
		return true;
		
		
	}
/**
 * Metoda koja brise proslijedjenog profesora po njegovom kljucu (brojLicneKartet). Prolazi kroz listu
 * predmeta i pronalazi Profesora po broju licne karte.
 * @param pr entitet Profesor
 */
	public void obrisiProfesoraSaPredmeta(Profesor pr) {
//brisanje po kljucu
		
		
for(Predmet p : predmeti) {
			
			if(p.getPredmetniProfesor() != null) {//ne mogu da uradim .getBrLicneKarte kad mi vrati null;
			if(p.getPredmetniProfesor().getBrLicneKarte() == pr.getBrLicneKarte()){
				p.setPredmetniProfesor(null);
			
			
			}
		}
	}
		
	}
	/**
	 * Postavlja Profesora na predmet
	 * @param p entitet Profesor
	 * @param predmet entitet Predmet
	 */
public void dodajProfesoraPredmetu(Profesor p ,Predmet predmet) {
		
		predmet.setPredmetniProfesor(p);
	}
/**
 * Metode uklanja profesora sa predmeta.
 * @param p - profesor koga uklanjamo 
 * @param predmet - predmet sa koga uklanjamo profesora
 */
public void ukloniProfesoraSaPredmet(Profesor p,Predmet predmet) {
	//if(predmet.getPredmetniProfesor().equals(p))
	predmet.setPredmetniProfesor(null);
	
}
/**
 * Serijalizacija predmeta.
 */
public void serijalizacijaPredmeta() {
	ObjectOutputStream out  = null ;
	try {
		out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("predmeti.txt")));
		out.writeObject(predmeti);
	}catch (IOException e) {
		e.printStackTrace();
	}finally {
		if(out != null) {
			try {
				out.close();
			}catch (IOException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}
}
/**
 * Metoda deserijalizacij koja cita podatke iz proslijedjenje datoteke. Ti podaci se ucitavaju 
 * u aplikaciju .
 */
public void deserijalizacijaPredmeta() {
	
	ObjectInputStream in;
	try {
		in= new ObjectInputStream(new BufferedInputStream(new FileInputStream("predmeti.txt")));
		try {
			predmeti = (ArrayList<Predmet>) in.readObject();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	//MainFrame.getInstance().azurirajPrikazPredmet(null, 0);
	
}
/**
 * Postavlja Profesora na predmet
 * @param prof entitet Profesor
 * @param pr entitet Predmet
 */

public void dodajProfesoraNaPredmet(Predmet pr, Profesor prof) {
	for(Predmet p : predmeti) {
		if(p.getSifraPredmeta() == pr.getSifraPredmeta()) {
			p.setPredmetniProfesor(prof);
		}
		}
	
}	
}