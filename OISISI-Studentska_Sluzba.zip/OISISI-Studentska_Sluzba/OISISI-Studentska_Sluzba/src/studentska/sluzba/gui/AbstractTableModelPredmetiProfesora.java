package studentska.sluzba.gui;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

import studentska.sluzba.model.Predmet;

public class AbstractTableModelPredmetiProfesora extends AbstractTableModel{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<Predmet> listaPredmeta;
	private String[] kolone;
	
	public AbstractTableModelPredmetiProfesora(ArrayList<Predmet> predmeti) {
		super();
		listaPredmeta=predmeti;
		kolone = new String[]{"SIFRA PREDMETA","NAZIV PREDMETA",
			"GODINA NA KOJOJ SE PREDMET IZVODI","SEMESTAR"};
				
	}

	public String getColumnName(int column) {
		return kolone[column];
	}
	
	@Override
	public int getRowCount() {
		return listaPredmeta.size();
	}

	@Override
	public int getColumnCount() {
		return kolone.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Predmet predmet = listaPredmeta.get(rowIndex);
		
		switch (columnIndex) {
		case 0: 
			return predmet.getSifraPredmeta();
		case 1:
			return predmet.getNazivPredmeta();
		case 2:
			return predmet.getGodinaStudija() + "";
			
		case 3:
			return predmet.getSemestar() + "";
		
		default:
			return null;
		}
	}
}
