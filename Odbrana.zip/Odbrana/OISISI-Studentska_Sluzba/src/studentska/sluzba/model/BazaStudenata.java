package studentska.sluzba.model;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Date;

import studentska.sluzba.model.Student.Status;
/**
 * Klasa koja modeluje Bazu Studenata i vrsi operacije nad njom.
 * @author Maja Blagic
 *
 */
public class BazaStudenata {
	
	
	
	private static BazaStudenata instance=null;
	/**
	 * 
	 * @return - vraca instancu Baze Studenata
	 */
	
	public static BazaStudenata getInstance() {
		if(instance==null) {
			instance= new BazaStudenata();
		}
		return instance;
	}

	private ArrayList<Student> studenti;
	private ArrayList<String> kolone;
	/**
	 * Konstruktor baze studenata . Inicijalizuje i puni listu studenata tako sto poziva metodu deserijalizacije.
	 * Puni listu kolone .
	 */
	private BazaStudenata() {
		//ne dodajem nista na pocetku
		this.studenti=new ArrayList<Student>();
		initStudenti();
		
		this.kolone=new ArrayList<String>();
		this.kolone.add("INDEKS");
		this.kolone.add("IME");
		this.kolone.add("PREZIME");
		this.kolone.add("GODINA STUDIJA");
		this.kolone.add("STATUS");
		this.kolone.add("PROSEK");
	
	}

	private void initStudenti() {
		
		deserijalizacijaStudenta();
		
	/*
		try {
			Date date1=new SimpleDateFormat("dd/MM/yyyy").parse("11/12/1999");
			Date date2=new SimpleDateFormat("dd/MM/yyyy").parse("11/12/1999");
			Date date3=new SimpleDateFormat("dd/MM/yyyy").parse("11/12/1999");
			dodajStudenta("Matkovski","Marko", date1, "ZelenaPijaca,32","065/434/433", "marksec@max.com","RA22-2018",2018, 2,Status.B, 0.00);
			dodajStudenta("Ivkovic","Ranko", date1, "ZelenaPijaca,32","065/434/433", "marksec@max.com","RA22-2018",2018, 2,Status.B, 0.00);
			dodajStudenta("Pavkovic","Nikoleta", date2, "ZelenaPijaca,32","064/252/767", "nicol@max.com","RA21-2018",2018, 2,Status.B, 0.00);
			dodajStudenta("Antonijevic","Filip",date3, "ZelenaPijaca,32","065/434/222", "anton@max.com","RA123-2018",2018, 2,Status.S, 0.00);
			dodajStudenta("Markovic","Bogdan",date3, "ZelenaPijaca,302","064/234/2892", "bogMar@max.com","RA145-2018",2018, 2,Status.S, 0.00);

			
			//POTREBNO ZA PROVJERU FUNKCIONALNOSTI
		} catch (ParseException e) {
		
			e.printStackTrace();
		}*/
		
	}
	/**
	 * 
	 * @return - lista studenata 
	 */
	public ArrayList<Student> getStudenti() {
		return studenti;
	}
	/**
	 * Postavlja vrijednost liste studenata na vrijesnost proslijedjene liste 
	 * @param studenti - prosljedjena lista
	 */
	public void setStudenti(ArrayList<Student> studenti) {
		this.studenti = studenti;
	}
	/**
	 * Predstavnja fiksan broj kolona
	 * @return 6
	 */
	public int getColumnCount() {
		return 6;
	}
	/**
	 * Vraca ime kolone u zavisnosti od proslijednjenog broja kolone
	 * @param index - broj kolone koju trazimo
	 * @return - vraca ime kolone(String)
	 */
	public String getColumnName(int index) {
		return this.kolone.get(index);
	}
	/**
	 * Vraca red tabele po vrijednosti parametra
	 * @param index - broj kolone koju trazimo
	 * @return - entitet Student koji se nalazi u tom redu tabele
	 */
	public Student getRow(int index) {
		return this.studenti.get(index);
	}
	/**
	 * Vraca vrijednost u presjeku reda i kolone tabele
	 * @param row - trazeni red
	 * @param column - trazena kolona
	 * @return - stribut entiteta koji se nalazi u presjeku kolone i reda
	 */
	public String getValueAt(int row, int column) {
		Student student = this.studenti.get(row);
		
		switch(column) {
		case 0:
			return student.getBrIndeksa();
		case 1:
			return student.getIme();
		case 2:
			return student.getPrezime();
		case 3:
			return student.getTrenutnaGodinaStudija() +"";
		case 4:
			return student.getStatus() +"";
		case 5:
			return student.getProsecnaOcena() + "";
		
		default:
				return  null;
		}
	}
	/**
	 * Metoda koja dodaje dodaje studenta u bazu na osnovu proslijedjenih parametara.
	 * Prije toga pravjerava jedinstvenost kljuca/indeksa sutudenta.
	  
	 * @param prezime - prezime studenta
	 * @param ime - ime studenta  
	 * @param datumRodjenja - datum rodjena studenta
	 * @param adresa - adresa stanovanja sudenta
	 * @param kontaktTelefon - kontakt broj teledona studenta
	 * @param eMail - e mail studenta
	 * @param brIndeksa - broj indeksa studenta
	 * @param godinaUpisa - godina upisa studenta na fakultet
	 * @param trenutnaGodinaStudija - trenutna godina na kojoj studira student
	 * @param status - status studenta 
	 * @param prosecnaOcena - prosjecna ocjena studenta
	 */
	public void dodajStudenta (String prezime, String ime, Date datumRodjenja, String adresa, String kontaktTelefon, String eMail,
			String brIndeksa, int godinaUpisa, int trenutnaGodinaStudija, Status status, double prosecnaOcena) {
		if(uniqueBrIndexa(brIndeksa)) { 
		this.studenti.add(new Student(prezime,ime,datumRodjenja,adresa,kontaktTelefon,eMail,brIndeksa,godinaUpisa,trenutnaGodinaStudija,status,prosecnaOcena));
		}
	}
	/**
	 * Metoda koja brise Studenta iz Baze studenata preko kljuca/broja indeksa
	 * @param brIndeksa - kljuc studenta kojeg zelimo da isbrisemo
	 */
	public void izbrisiStudenta(String brIndeksa) {
		for(Student s: studenti) {
			if(s.getBrIndeksa()==brIndeksa) {
				studenti.remove(s);
				break;
			}
		}
	}
	/**
	 * Metoda koja mijenja obiljezja studenta na osnovu proslijedjenih vrijednosti parametara
	 * @param index - indeks studenta
	 * @param prezime - prezime studenta
	 * @param ime - ime studenta  
	 * @param datumRodjenja - datum rodjena studenta
	 * @param adresa - adresa stanovanja sudenta
	 * @param kontaktTelefon - kontakt broj teledona studenta
	 * @param eMail - e mail studenta
	 * @param brIndeksa - broj indeksa studenta
	 * @param godinaUpisa - godina upisa studenta na fakultet
	 * @param trenutnaGodinaStudija - trenutna godina na kojoj studira student
	 * @param status - status studenta 
	 * @param prosecnaOcena - prosjecna ocjena studenta
	 */
	public void izmeniStudenta(String index,String prezime, String ime, Date datumRodjenja, String adresa, String kontaktTelefon, String eMail,
			String brIndeksa, int godinaUpisa, int trenutnaGodinaStudija, Status status, double prosecnaOcena) {
		for (Student s: studenti) {
			if(s.getBrIndeksa().equals(index)) {
				//uz pretpostavku da se i indeks moze izmijeniti
				s.setBrIndeksa(brIndeksa);
				s.setPrezime(prezime);
				s.setIme(ime);
				s.setDatumRodjenja(datumRodjenja);
				s.setAdresa( adresa);
				s.setKontaktTelefon(kontaktTelefon);
				s.seteMail(eMail);
				s.setGodinaUpisa(godinaUpisa);
				s.setTrenutnaGodinaStudija(trenutnaGodinaStudija);
				s.setStatus(status);
				s.setProsecnaOcena(prosecnaOcena);
		
			
			}
		}
		
	}
	/**
	 * Metoda koja provjerava da li je kljuc/broj indeksa proslijedjenog studenta jedinstven i dodaje ga u Bazu Studenata
	 * @param entity - entitet studenta
	 */
	public void dodajStudenta(Student entity) {
		//provjera jedinstvenosti kljuca
		if(uniqueBrIndexa(entity.getBrIndeksa())) { 
		this.studenti.add(entity);		
	}}
/**
 * Metoda koja provjerava da li je kljuc/br indeksa jedinstven 
 * @param brIndeksa - indeks za koji se provjera vrsi
 * @return - true ako je jedinstven, u suprotnom false
 */
	public Boolean uniqueBrIndexa(String brIndeksa) {
		
		for(Student s: studenti) {
			if(s.getBrIndeksa().equals(brIndeksa)) {
				return false;
			}
		}
		return true;
	}
	/**
	 * Proslijedjeni predmet se brise sa liste svih studenata na kojima se nalazi.
	 * Prolazimo kroz sve tri tabele i ako je predmet pronadjen brisemo ga.
	 * @param p - predmet koji brisemo 
	 */
public void izbrisiPredmet(Predmet p) {
		
		
		for(Student s: studenti) {
			if(s.getSpisakNepolozenihIspita().contains(p)) {
				s.getSpisakNepolozenihIspita().remove(p);
			}
			
			if(s.getSpisakPolozenihIspita().contains(p)) {
				s.getSpisakPolozenihIspita().remove(p);
			}
			if(s.getSpisakPredmetaDaPolaze().contains(p)) {
				s.getSpisakPredmetaDaPolaze().remove(p);
			}
		
		}
	}


/**
 * Metoda koja Studentu dodjeljuje ocjenu za predmet
 * @param s - student koji se ocjenjuje
 * @param o - ocjena koja je dobijena
 * @param p - predmet na kome se student ocjenjuje
 */
	public void dodajOcenu(Student s, Ocena o,Predmet p) {
		
		s.getSpisakPolozenihIspita().add(o);
		s.getSpisakNepolozenihIspita().remove(p);
	
		
	}

/**
 * Metoda koja ponistava ocjenu za studenat
 * @param s - student za koga ponistavamo ocjenu
 * @param selectedRow - selektovani predmet sa liste polozenih ispita proslijedjenog studentta 
 */
	public void ponistiOcenu(Student s, int selectedRow) {

		Ocena o=s.getSpisakPolozenihIspita().get(selectedRow);
		Predmet p= o.getPredmet();
		s.getSpisakPolozenihIspita().remove(o);
		s.getSpisakNepolozenihIspita().add(p);

		
	}
/**
 * Metoda koja predmet skida sa liste predmeta koje student moze polagati i dodaje na listu nepolozenih predmeta.
 * @param s - student 
 * @param selectedRow - indeks predmeta u listi SpisakPredmetaDaPolaze
 */
	public void azurirajListuNepolozenihPredmeta(Student s, int selectedRow) {
		//uzmi predmet
				Predmet p =s.getSpisakPredmetaDaPolaze().get(selectedRow);
				s.getSpisakNepolozenihIspita().add(p);
				s.getSpisakPredmetaDaPolaze().remove(p);
				
		
	}
/**
 * Za vakog studenta se provjeri da li moze da mu se doda predmet na listu predmeta koje on moze da polaze.
 * Uslov je taj da je trenutna godina studija studenta veca ili jednaka godini na kojoj se predmet predaje.
 * Ako je uslov ispunjen predmet se dodaje na spisak predmeta koje student moze da polaze.
 * @param predmet proslijedjeni entitet
 */
	public void azurirajListuPredmeta(Predmet predmet) {
		for(Student s: studenti) {
			

			if(s.getTrenutnaGodinaStudija() >= predmet.getGodinaStudija()) {
			s.getSpisakPredmetaDaPolaze().add(predmet);
			}
		}
	}
/**
 * Proslijedjeni predmet uklanjamo sa spiska predmeta koje student nije polozio i dodajemo na spisak onih koje ima opciju da polaze.
 * @param s - student za koga se vrsi izmjena
 * @param selectedRow - selektovani red predmeta u listi 
 */
	public void uklanjanjePredmetaSaStudenta(Student s, int selectedRow) {

		
		Predmet p =s.getSpisakNepolozenihIspita().get(selectedRow);
		s.getSpisakPredmetaDaPolaze().add(p);
		s.getSpisakNepolozenihIspita().remove(p);
		
	
	}
	
	


	
	
	public void serijalizacijaStudenata() {
	
		ObjectOutputStream out  = null ;
		try {
			out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("studenti.txt")));
			out.writeObject(studenti);
		}catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(out != null) {
				try {
					out.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}
	}
	/**
	 * Metoda deserijalizacij koja cita podatke iz proslijedjenje datoteke. Ti podaci se ucitavaju 
	 * u aplikaciju .
	 */
	public void deserijalizacijaStudenta()  {
		ObjectInputStream in;
		try {
			in= new ObjectInputStream(new BufferedInputStream(new FileInputStream("studenti.txt")));
			try {
				studenti = (ArrayList<Student>) in.readObject();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	//	MainFrame.getInstance().azurirajPrikazStudenta(null, 0);
	}

	public void ispisi() {
for(Student s: studenti) {
			
			System.out.println(s.getBrIndeksa()+" "+ s.getIme());
		}
		
		
	}
	
}
	

