package listeners;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import gui.MainFrame;

public class OptionPaneExample extends JFrame{  
	/*	JFrame f;  
		public OptionPaneExample(){  
		    f=new JFrame();   
		    f.addWindowListener(this);  
		    f.setSize(300, 300);  
		    f.setLayout(null);  
		    f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);  
		    f.setVisible(true);  
		}  
		public void windowClosing(WindowEvent e) {  
		    int a=JOptionPane.showConfirmDialog(f,"Are you sure?");  
		if(a==JOptionPane.YES_OPTION){  
		    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
		}  
		}*/
	public JFrame x=null;
	public OptionPaneExample() {
	x=  new JFrame();
	Object[] options = { "Da", "Ne" };
	//JOptionPane optionPane = new JOptionPane();
	int opcija = JOptionPane.showOptionDialog(null,"Da li ste sigurni da želite da \n "
		    + "ponistite predmet?", "Brisanje predmeta.",
	    JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
	    null, options, options[1]);
	
	if(opcija == JOptionPane.YES_OPTION) {
		System.out.println("Brisanje predmeta");
	}
	

	x.setLocationRelativeTo(null);
	x.setSize(new Dimension(250,150));
	x.setResizable(false);
	
	
	x.setLocationRelativeTo(MainFrame.getInstance());
	x.getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
	
	
	}
	}
	