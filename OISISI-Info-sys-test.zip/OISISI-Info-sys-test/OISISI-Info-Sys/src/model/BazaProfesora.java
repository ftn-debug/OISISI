package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import controller.PredmetiController;
import gui.MainFrame;
import model.Predmet.Semestar;
import model.Profesor.Titula;
import model.Profesor.Zvanje;



public class BazaProfesora {

		private static BazaProfesora instance = null;
		
		public static BazaProfesora getInstance() {
			if(instance == null) {
				instance = new BazaProfesora();
			}
			return instance;
		}
		
		private List<Profesor> profesori;
		private List<String> kolone;
	
		private BazaProfesora() {
				
				
				initProfesore();
				
				this.kolone = new ArrayList<>();
				this.kolone.add("IME");
				this.kolone.add("PREZIME");				
				this.kolone.add("TITULA");
				this.kolone.add("ZVANJE");
				
			}
		
		
	
		private void initProfesore()  {
			
			this.profesori = new ArrayList<Profesor>();		
			
			profesori.add(new Profesor("Markovic", "Marko","Narodnog fronta 4", "021/222-333", "markomarkovic@gmail.com", "Bulevar Oslobodjenja 16", "7T1577", Titula.dr, Zvanje.Redovni_profesor));
			profesori.add(new Profesor("Peric", "Pera","Narodnog fronta 4", "021/222-333", "peraperic@gmail.com", "Bulevar Oslobodjenja 16", "7T1567", Titula.dr, Zvanje.Redovni_profesor));

			profesori.add(new Profesor("Markovic", "Luka","Narodnog fronta 4", "021/222-333", "markomarkovic@gmail.com", "Bulevar Oslobodjenja 16", "T1577", Titula.dr, Zvanje.Redovni_profesor));
			profesori.add(new Profesor("Peric", "Stefan","Narodnog fronta 4", "021/222-333", "peraperic@gmail.com", "Bulevar Oslobodjenja 16", "T1567", Titula.dr, Zvanje.Redovni_profesor));
		    
			//provjera da li dbr ispisuje tabelu predmeti profesora
			Profesor p1 = new Profesor("lukic", "Luka","Narodnog fronta 4", "021/222-333", "markomarkovic@gmail.com", "Bulevar Oslobodjenja 16", "T15000", Titula.dr, Zvanje.Redovni_profesor);
			ArrayList<Predmet> lp1 = new ArrayList<Predmet>();
			lp1.add(new Predmet("pom1", "nazivPOM1", Semestar.LETNJI, 2, 5));
			ArrayList<Predmet> lp2 = new ArrayList<Predmet>();
			lp2.add(new Predmet("pomMoguci1", "nazivPOM1moguci", Semestar.LETNJI, 2, 5));
			
			p1.setPredmetiNaKojimJeProfesor(lp1);
			p1.setMoguciPredmeti(lp2);
			profesori.add(p1);
			//valjda ovo radi 
			napuniMoguceZaDodati();
		}
		
		public List<Profesor> getProfesori() {
			return profesori;
		}
		
		public void setProfesori(List<Profesor> profesori) {
			this.profesori = profesori;
		}
		
		public int getColumnCount() {
			return 4;
		}
	
		public String getColumnName(int index) {
			return this.kolone.get(index);
		}
		
		public Profesor getRow(int rowIndex) {
			return this.profesori.get(rowIndex);
		}
		
		public String getValueAt(int row,int column) {
			Profesor profesor = this.profesori.get(row);
			switch (column) {
			case 0: 
				return profesor.getIme();
			case 1:
				return profesor.getPrezime();
			case 2:
				return  profesor.getTitula().toString();
			case 3:
				return profesor.getZvanje().toString();
			default:
					return null;		
			}
		}
		
		public void dodajProfesora(String ime,String prezime,Date datumRodjenja,
									String adresaStanovanja,String telefon,String mail,
									String adresaKancelarije,String brLicneKarte,
									Titula titula,Zvanje zvanje){
		this.profesori.add(new Profesor(ime,prezime,datumRodjenja,adresaStanovanja,telefon,
										mail,adresaKancelarije,brLicneKarte,titula,zvanje));
}
		
		public void dodajProfesora(Profesor profesor) {
			profesori.add(profesor);
			//napuniMoguceZaDodati();
		}
		
		@SuppressWarnings("unlikely-arg-type") //PITATI DA LI SIFRA PREDMETA MORA BITI STRING ILI MOZE BITI INT
		public void izbrisiProfesora(String brLicneKarte)
		{
			for(Profesor p : profesori) {
				if(p.getBrLicneKarte() == brLicneKarte) {
					profesori.remove(p);
					
					break;
				}
			}
		}
		
		public void izmjeniProfesora(String brLicneKarte,String ime,String prezime,Date datumRodjenja,
									String adresaStanovanja,String telefon,String mail,
									String adresaKancelarije,
									Titula titula,Zvanje zvanje) {
			Profesor prof = profesori.get(MainFrame.getInstance().selectedProfesorRow());
			//for(Profesor p : profesori) {
			//poredis licnu kartu izmjenjeog profeosra
			//sa licnom kartom izmjenjenog profesora
			//a ne onoga staroga
			//kod mene je omoguceno i mijenjanje licne karte(u mom slucaju idenksa)
		
				//if(p.getBrLicneKarte().equals(brLicneKarte)) {
					prof.setBrLicneKarte(brLicneKarte);
					prof.setIme(ime);
					prof.setPrezime(prezime);
					prof.setDatumRodj(datumRodjenja);
					prof.setAdresaStanovanja(adresaStanovanja);
					prof.setTelefon(telefon);
					prof.setMail(mail);
					prof.setAdresaKancelarije(adresaKancelarije);
					prof.setTitula(titula);
					prof.setZvanje(zvanje);
				//}
			//}
			MainFrame.getInstance().azurirajPrikazProfesora(null, -1);
			
		}
		
		
		public Boolean uniqueBrLicneKarte(String brLicneKarte) {
			
			for(Profesor p: profesori) {
				if(p.getBrLicneKarte().equals(brLicneKarte)) {
					return false;
				}
			}
			return true;
		}
		
		
		public void dodajPredmetProfesoru(Profesor p,Predmet predmet) {
			
			p.getPredmetiNaKojimJeProfesor().add(predmet);
			p.getMoguciPredmeti().remove(predmet);
		}
		
		
		public void ukloniPredmetProfesoru(Profesor p,Predmet predmet) {
		
			
			p.getPredmetiNaKojimJeProfesor().remove(predmet);
			p.getMoguciPredmeti().add(predmet);
		}
		
		
		
		//ne znam da li ova funkcija valjda
		public void napuniMoguceZaDodati() {
			ArrayList<Predmet> predm = new ArrayList<Predmet>();
			predm = PredmetiController.getInstance().vratiSvePredmete();
		//iteriram kroz sve predmete iz baze 
			for(Predmet p : predm)
			{
				//za svaki predmet iteriram kroz sve profesore i gledam za svakog
				//profesora da li predaje na tom predmetu i ako ne predaje dodam ga na listu mogucih predmeta za dodavanje profesoru 
				for(Profesor prof  :  profesori ) {
					
					for(Predmet p2 : prof.getPredmetiNaKojimJeProfesor()) {
						if(!p.equals(p2))
						{
							prof.getMoguciPredmeti().add(p);
						}
					}
				}
			}
			
		}
		
}
