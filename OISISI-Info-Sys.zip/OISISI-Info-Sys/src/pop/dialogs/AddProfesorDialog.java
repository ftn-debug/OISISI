package pop.dialogs;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class AddProfesorDialog extends JDialog implements ActionListener {

	static JLabel labelaIme;
	static JLabel labelaPrezime;
	static JLabel labelaDatumRodjenja;
	static JLabel labelaAdresaStanovanja;
	static JLabel labelaBrojTelefona;
	static JLabel labelaEmail;
	static JLabel labelaAdresaKancelarije;
	static JLabel labelaBrLicneKarte;
	static JLabel labelaTitula;
	static JLabel labelaZvanje;
	
	static JTextField poljeIme;
	static JTextField poljePrezime;
	static JTextField poljeDatumRodjenja;
	static JTextField poljeAdresaStanovanja;
	static JTextField poljeBrojTelefona;
	static JTextField poljeEmail;
	static JTextField poljeAdresaKancelarije;
	static JTextField poljeBrLicneKarte;
	static JTextField poljeTitula;
	static JTextField poljeZvanje;
	
	//DODATI LISTENERE
	//private KeyListener1 keyListener 1;
	//....
	public AddProfesorDialog() {
		setTitle("Dodavanje profesora");
		labelaIme = new JLabel("Ime:");
		labelaPrezime = new JLabel("Prezime:");
		labelaDatumRodjenja = new JLabel("Datum rodjenja:");
		labelaAdresaStanovanja = new JLabel("Adresa stanovanja:");
		labelaBrojTelefona = new JLabel("Broj telefona:");
		labelaEmail = new JLabel("Email:");
		labelaAdresaKancelarije = new JLabel("Adresa Kancelarije:");
		labelaBrLicneKarte = new JLabel("Broj licne karte:");
		labelaTitula = new JLabel("Titula:");
		labelaZvanje = new JLabel("Zvanje:");
		
		//INICIJALIZOVATI LISTENERE
		//keyListener1 = new KeyListener();
		//...
		
		poljeIme = new JTextField(15);
		poljeIme.setName("txtIme");
		//poljeIme.addKeyListener();
		poljePrezime = new JTextField(15);
		poljePrezime.setName("txtIme");
		//poljeIme.addKeyListener();
		
	}
	
	
	
	
	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
