package studentska.sluzba.gui;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.TableCellRenderer;

import studentska.sluzba.model.Student;
/**
 * Klasa koja kreira Tabelu polozenih predmeta za proslijedjenog studenta.
 * 
 * @author majab
 *
 */
public class PolozeniPredmetiTable extends JTable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
/**
 * U konstruktoru kreiramo Tabelu polozenih predmeta za proslijedjenog studenta.
 * @param s - proslijedjeni student za koga kreiramo tabelu polozenih predmeta.
 * Od spiskaPolozenihPredmeta pravimo AbstractTableModel i postavljamo taj model kao model 
 * naseg konstruktora tj, naseg JTable klase.
 */
public PolozeniPredmetiTable(Student s) {
	
		
		this.setRowSelectionAllowed(true);
		this.setColumnSelectionAllowed(true);
		this.setAutoCreateRowSorter(true);
		this.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		this.setModel(new AbstractTableModelPolozeniPredmet(s.getSpisakPolozenihIspita()));
	}
/**
 * Metoda koja obezbjedjuje da se boja selektovanog reda promijeni u sivu boju i tako poboljsa look and feel nase aplikacije.
 */
	@Override
	public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
		Component c = super.prepareRenderer(renderer, row, column);
		// selektovani red ce imati drugaciju boju od ostalih
		if (isRowSelected(row)) {
			c.setBackground(Color.LIGHT_GRAY);
		} else {
			c.setBackground(Color.WHITE);
		}
		return c;
	}
	
	
	

}


