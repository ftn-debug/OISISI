package studentska.sluzba.model;

import java.util.Date;
/**
 * Klasa koja modeluje entitet Ocena
 * @author Maja Blagic 
 *
 */
public class Ocena {
	/**
	 * Enumeracija vrijednosti ocene . Od 5 do 10.
	 * @author Maja Blagic
	 *
	 */
	public enum vOcjene{ /**5 */pet ,/**6 */sest,/**7 */sedam,/**8 */osam,/**9 */devet,/**10 */deset};
	//save for later
	/*public enum vOcene {
		pet(5),sest(6),sedam(7),osam(8),devet(9),deset(10);
		private final int o;
		vOcene(int o){this.o=o;}
		public int getValue() {return o;}
	}
	*/
	
	private Student student;
	private Predmet predmet;
	private vOcjene vijrednostOcene;
	private Date datumPolaganja;
	
	/**
	 * Konstruktor klase
	
	 * @param student - student koji je dobio ocjenu
	 * @param predmet - predmet za koji je student dobio ocjenu
	 * @param vijrednostOcene - vrijednost ocjene
	 * @param datumPolaganja - datum polaganja predmeta
	 */
	public Ocena(Student student, Predmet predmet,vOcjene vijrednostOcene, Date datumPolaganja) {
		super();
		this.student = student;
		this.predmet = predmet;
		this.vijrednostOcene = vijrednostOcene;
		this.datumPolaganja = datumPolaganja;
	}
	/**
	 * 
	 */
	public Ocena() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * 
	 * @return entitet studenta
	 */
	public Student getStudent() {
		return student;
	}
	/**
	 *  metoda koja postavlja vrijednost atributa entiteta na vrijednost parametra 
	 * @param student student kome se dodjeljuje ocena
	 */
	public void setStudent(Student student) {
		this.student = student;
	}
	/**
	 * 
	 * @return entitet predmet
	 */
	public Predmet getPredmet() {
		return predmet;
	}
	/**
	 *  metoda koja postavlja vrijednost atributa entiteta na vrijednost parametra 
	 * @param predmet preddmet za koji se dodjeljuje ocena
	 */
	public void setPredmet(Predmet predmet) {
		this.predmet = predmet;
	}
	/**
	 * 
	 * @return enum vrijednost ocjene
	 */
	public vOcjene getVijrednostOcene() {
		return vijrednostOcene;
	}
	/**
	 *  metoda koja postavlja vrijednost atributa entiteta na vrijednost parametra 
	 * @param vijrednostOcene vrijednost ocjene
	 */
	public void setVijrednostOcene(vOcjene vijrednostOcene) {
		this.vijrednostOcene = vijrednostOcene;
	}
	/**
	 * 
	 * @return datum Polaganja
	 */
	public Date getDatumPolaganja() {
		return datumPolaganja;
	}
	/**
	 *  metoda koja postavlja vrijednost atributa entiteta na vrijednost parametra 
	 * @param datumPolaganja datum polaganja predmeta
	 */
	public void setDatumPolaganja(Date datumPolaganja) {
		this.datumPolaganja = datumPolaganja;
	}
	@Override
	public String toString() {
		return "Ocena [student=" + student + ", predmet=" + predmet + ", vijrednostOcene=" + vijrednostOcene
				+ ", datumPolaganja=" + datumPolaganja + "]";
	}
	/**
	 * 
	 * @param vijrednostOcene2 enum prosliedjena vrijednost ocjene
	 * @return vraca double vrijednost enum Ocjene
	 */
	public double getVijrednostOceneToInt(vOcjene vijrednostOcene2) {
	
			
			if(	vijrednostOcene ==vOcjene.pet) {
				return 5;
			}
			else if(	vijrednostOcene ==vOcjene.sest) {
				return 6;
			}
			else if(	vijrednostOcene ==vOcjene.sedam) {
				return 7;
			}
			else if(	vijrednostOcene ==vOcjene.osam) {
				return 8;
			}
			else if(	vijrednostOcene ==vOcjene.devet) {
				return 9;
			}
			else if(	vijrednostOcene ==vOcjene.deset) {
				return 10;
			}else {
			return 0;
			}
		}
	
	
}
