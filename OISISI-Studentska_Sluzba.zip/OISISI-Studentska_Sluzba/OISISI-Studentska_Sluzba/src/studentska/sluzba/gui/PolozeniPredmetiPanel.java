package studentska.sluzba.gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;

import studentska.sluzba.controller.StudentiController;
import studentska.sluzba.model.Student;
import studentska.sluzba.pop.dialogs.EditStudentDialog;

//link:https://stackoverflow.com/questions/5764467/get-component-from-a-jscrollpane

public class PolozeniPredmetiPanel extends JPanel {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public static JLabel prosjecnaOcjenaL;
	 public static JLabel ukupnoEspbL;
	
	
public PolozeniPredmetiPanel( JScrollPane polozeniScroll,Student s, EditStudentDialog eds) {



	setName("Editovanje studenta");
	prosjecnaOcjenaL= new JLabel("Prosjecna ocjena "+" :  " + s.getProsecnaOcena(s));
	ukupnoEspbL= new JLabel("Ukupno ESPB bodova"+" :  "+s.getEspb(s));
	JButton button= new JButton("Ponisti ocjenu");
	

	 Window parent = SwingUtilities.getWindowAncestor(this);
	ActionListener ok = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {

			JViewport viewport = polozeniScroll.getViewport(); //source link
			JTable myTable = (JTable)viewport.getView();
			
			
			if(myTable.getSelectedRow() == -1) {
				//Ovdje mi pravi problem JOptionPane 
				JOptionPane.showMessageDialog(parent, "Morate  selektovati polozeni predmet!");
			//	JOptionPane.showMessageDialog(eds, "Morate  selektovati polozeni predmet!");
				
			}else {
				//ponistavanje ocene
				//pravi mi problem JOptionPane
				 int n = JOptionPane.showConfirmDialog(
				            eds,
				            "Da li ste sigurni da zelite da ponistite ocjenu?",
				            "Ponistavanje ocjene",
				            JOptionPane.YES_NO_OPTION);

				        if(true){
				        	
							StudentiController.getInstance().ponistiOcenu(s,myTable.getSelectedRow(),eds);
							prosjecnaOcjenaL.setText("Prosjecna ocjena "+" :  " + s.getProsecnaOcena(s));
							ukupnoEspbL.setText("Ukupno ESPB bodova"+" :  "+s.getEspb(s));
							
				        }
				      
				    }
			
		}};
	
	button.addActionListener(ok);
	
	

	

	setLayout(button,polozeniScroll);
	}
	
	
	private void setLayout(JButton button, JScrollPane polozeniScroll) {
	
		setLayout(new GridBagLayout());
		
	
		GridBagConstraints gbc= new GridBagConstraints();
		//gbc.fill= GridBagConstraints.HORIZONTAL;
		gbc.weightx=0.5;
		gbc.weighty=0.5;
		gbc.gridwidth=3;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(20, 30, 15, 0);
		gbc.anchor=GridBagConstraints.LINE_START;
		
		add(button,gbc);
	
	
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth=5;		
		gbc.weightx=100;
		gbc.weighty=100;
		gbc.fill=GridBagConstraints.BOTH;
		gbc.insets=new Insets(0,30,0,30);
		
		add(polozeniScroll,gbc);		
		
		gbc.ipady = 5;
		gbc.gridx = 20;
        gbc.gridwidth = 1;
		gbc.weightx = 0.25;
		gbc.weighty = 0.25;
        gbc.gridx = 4;
        gbc.gridy = 2;
        gbc.insets = new Insets(10, 0, 0, 30);
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor=GridBagConstraints.EAST;
		
		add(prosjecnaOcjenaL,gbc);
		
		gbc.ipady = 20;
		gbc.weightx = 0.25;
		gbc.weighty = 0.25;
        gbc.gridx = 4;
        gbc.gridy = 3;
        gbc.insets = new Insets(0, 0, 0, 30);
		gbc.anchor=GridBagConstraints.EAST;
		
		add(ukupnoEspbL,gbc);



}
}
