

package studentska.sluzba;

import studentska.sluzba.gui.MainFrame;

/**
 * 
 * @author Maja Blagic
 * 
 *
 */
public class Main {
/**
 * Main metoda koja poziva instancu MainFramea
 * @param args - unused
 */
	public static void main(String[] args) {
		
		MainFrame.getInstance();
	
	}


}
