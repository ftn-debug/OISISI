package studentska.sluzba.gui;


import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

public class ActionSearch extends AbstractAction {

	private static final long serialVersionUID = 1583426086994634757L;

	public ActionSearch() {
		
		putValue(MNEMONIC_KEY, KeyEvent.VK_P);
		putValue(SHORT_DESCRIPTION, "Search");
		putValue(SMALL_ICON, new ImageIcon("Images"+ File.separator +"loupe.png"));
		putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_P, KeyEvent.CTRL_MASK));
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		System.out.println("searchJ");
	}

}
